package com.example.penalcodelowbangladesh;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textview.MaterialTextView;

import java.util.ArrayList;

public class MyAdapter_Thirteen extends RecyclerView.Adapter<MyAdapter_Thirteen.MyViewHolder_Thirteen> {
    protected static class MyViewHolder_Thirteen extends RecyclerView.ViewHolder{

        final private MaterialTextView recyclerViewHeaderId, recyclerDescID;
        final private MaterialCardView recyclerCardViewId_Thirteen;

        public MyViewHolder_Thirteen(@NonNull View itemView) {
            super(itemView);
            recyclerViewHeaderId = itemView.findViewById(R.id.recycler_TextViewHeader);
            recyclerDescID = itemView.findViewById(R.id.recycler_TextViewDesc);
            recyclerCardViewId_Thirteen = itemView.findViewById(R.id.recycler_CardView);
        }
    }
    ArrayList<datamodel_One> dataholder_thirteen;

    public MyAdapter_Thirteen(ArrayList<datamodel_One> dataholder_thirteen) {
        this.dataholder_thirteen = dataholder_thirteen;
    }

    @NonNull
    @Override
    public MyViewHolder_Thirteen onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View myView = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_xml_design_one,parent,false);
        return new MyViewHolder_Thirteen(myView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder_Thirteen holder, @SuppressLint("RecyclerView") int position) {
    holder.recyclerDescID.setText(dataholder_thirteen.get(position).getDesc());
    holder.recyclerViewHeaderId.setText(dataholder_thirteen.get(position).getHeader());
    holder.recyclerCardViewId_Thirteen.setOnClickListener(v -> {
        switch (position){
            case 0:
                AppCompatActivity activity = (AppCompatActivity) v.getContext();
                activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_One_Fragment_Twelve()).addToBackStack(null).commit();
                break;
            case 1:
                AppCompatActivity activity1 = (AppCompatActivity) v.getContext();
                activity1.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_two_Fragment_Twelve()).addToBackStack(null).commit();
                break;
            case 2:
                AppCompatActivity activity2 = (AppCompatActivity) v.getContext();
                activity2.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_three_Fragment_Eleven()).addToBackStack(null).commit();
                break;
            case 3:
                AppCompatActivity activity3 = (AppCompatActivity) v.getContext();
                activity3.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_four_Fragment_Twelve()).addToBackStack(null).commit();
                break;
            case 4:
                AppCompatActivity activity4 = (AppCompatActivity) v.getContext();
                activity4.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_five_Fragment_Twelve()).addToBackStack(null).commit();
                break;
            case 5:
                AppCompatActivity activity5 = (AppCompatActivity) v.getContext();
                activity5.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_six_Fragment_Twelve()).addToBackStack(null).commit();
                break;
            case 6:
                AppCompatActivity activity6 = (AppCompatActivity) v.getContext();
                activity6.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_seven_Fragment_Twelve()).addToBackStack(null).commit();
                break;
            case 7:
                AppCompatActivity activity7 = (AppCompatActivity) v.getContext();
                activity7.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_eight_Fragment_Twelve()).addToBackStack(null).commit();
                break;
            case 8:
                AppCompatActivity activity8 = (AppCompatActivity) v.getContext();
                activity8.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_nine_Fragment_Twelve()).addToBackStack(null).commit();
                break;
            case 9:
                AppCompatActivity activity9 = (AppCompatActivity) v.getContext();
                activity9.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_ten_Fragment_Twelve()).addToBackStack(null).commit();
                break;
            case 10:
                AppCompatActivity activity10 = (AppCompatActivity) v.getContext();
                activity10.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_eleven_Fragment_Twelve()).addToBackStack(null).commit();
                break;
            case 11:
                AppCompatActivity activity11 = (AppCompatActivity) v.getContext();
                activity11.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_twelve_Fragment_Twelve()).addToBackStack(null).commit();
                break;
            case 12:
                AppCompatActivity activity12 = (AppCompatActivity) v.getContext();
                activity12.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_thirteen_Fragment_Twelve()).addToBackStack(null).commit();
                break;
            case 13:
                AppCompatActivity activity13 = (AppCompatActivity) v.getContext();
                activity13.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_fourteen_Fragment_Twelve()).addToBackStack(null).commit();
                break;
            case 14:
                AppCompatActivity activity14 = (AppCompatActivity) v.getContext();
                activity14.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_fifteen_Fragment_Twelve()).addToBackStack(null).commit();
                break;
            case 15:
                AppCompatActivity activity15 = (AppCompatActivity) v.getContext();
                activity15.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_sixteen_Fragment_Twelve()).addToBackStack(null).commit();
                break;
            case 16:
                AppCompatActivity activity16 = (AppCompatActivity) v.getContext();
                activity16.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_seventeen_Fragment_Twelve()).addToBackStack(null).commit();
                break;
            case 17:
                AppCompatActivity activity17 = (AppCompatActivity) v.getContext();
                activity17.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_eighteen_Fragment_Twelve()).addToBackStack(null).commit();
                break;
            case 18:
                AppCompatActivity activity18 = (AppCompatActivity) v.getContext();
                activity18.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_nineteen_Fragment_Twelve()).addToBackStack(null).commit();
                break;

        }
    });
    }

    @Override
    public int getItemCount() {
        return 19;
    }
}
