package com.example.penalcodelowbangladesh;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;


public class Fragment_Fourteen extends Fragment {

    private RecyclerView recyclerView_Fourteen;
    private ArrayList<datamodel_One> dataholder_Fourteen = new ArrayList<>();

    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment__fourteen, container, false);
        recyclerView_Fourteen = view.findViewById(R.id.recyclerView_Fourteen);
        recyclerView_Fourteen.setLayoutManager(new LinearLayoutManager(getContext()));

        datamodel_One o1 = new datamodel_One("ধারাঃ ১৯১","মিথ্যা সাক্ষ্যদান");
        dataholder_Fourteen.add(o1);
        datamodel_One o2 = new datamodel_One("ধারাঃ ১৯২","মিথ্যা সাক্ষ্য উদ্ভাবন করা");
        dataholder_Fourteen.add(o2);
        datamodel_One o3 = new datamodel_One("ধারাঃ ১৯৩"," মিথ্যা সাক্ষ্য দেওয়ার শাস্তি");
        dataholder_Fourteen.add(o3);
        datamodel_One o4 = new datamodel_One("ধারাঃ ১৯৪","কোন লোককে মৃত্যুদন্ডে দণ্ডনীয় অপরাধে দন্ডিত করার উদ্দেশ্যে মিথ্যা সাক্ষ্য দেওয়া বা সৃষ্টি করা");
        dataholder_Fourteen.add(o4);
        datamodel_One o5 = new datamodel_One("ধারাঃ ১৯৫","যাবজ্জীবন কারাদণ্ড বা সাত বৎসর বা ততোধিক মেয়াদের কারাদন্ডে দণ্ডনীয় অপরাধে দন্ডিত করার উদ্দেশ্যে মিথ্যা সাক্ষ দেওয়া বা সৃষ্টি করা");
        dataholder_Fourteen.add(o5);
        datamodel_One o6 = new datamodel_One("ধারাঃ ১৯৬","বিচার বিষয়ক কার্যক্রমে মিথ্যা বা বানোয়াট বলিয়া জ্ঞাত বিষয় সাক্ষ্য হিসাবে ব্যবহার করা");
        dataholder_Fourteen.add(o6);
        datamodel_One o7 = new datamodel_One("ধারাঃ ১৯৭","মিথ্যা সার্টিফিকেট দান করা বা উহাতে স্বাক্ষর করা");
        dataholder_Fourteen.add(o7);
        datamodel_One o8 = new datamodel_One("ধারাঃ ১৯৮","মিথ্যা বলিয়া জ্ঞাত কোন সার্টিফিকেট সত্য বলিয়া ব্যবহার করা");
        dataholder_Fourteen.add(o8);
        datamodel_One o9 = new datamodel_One("ধারাঃ ১৯৯","আইনতঃ সাক্ষ্য প্রমানে গ্রহণযোগ্য কোন ঘোষনায় মিথ্যা বিবৃতি দেওয়া");
        dataholder_Fourteen.add(o9);
        datamodel_One o10 = new datamodel_One("ধারাঃ ২০০"," মিথ্যা বলিয়া জানা সত্ত্বেও উক্তরূপে কোন ঘোষনা সত্য বলিয়া ব্যবহার করা");
        dataholder_Fourteen.add(o10);
        datamodel_One o11 = new datamodel_One("ধারাঃ ২০১","অপরাধকারীকে গোপন করিবার জন্য অপরাধের সাক্ষ্য অদৃশ্য করিয়া দেওয়া বা মিথ্যা তথ্য সরবরাহ করা");
        dataholder_Fourteen.add(o11);
        datamodel_One o12 = new datamodel_One("ধারাঃ ২০২","আইনতঃ বাধ্য হওয়া সত্ত্বেও কোন অপরাধ সম্পর্কে ইচ্ছাকৃতভাবে খবর না দেওয়া");
        dataholder_Fourteen.add(o12);
        datamodel_One o13 = new datamodel_One("ধারাঃ ২০৩","সংঘটিত অপরাধ সম্পর্কে মিথ্যা খবর দেওয়া");
        dataholder_Fourteen.add(o13);
        datamodel_One o14 = new datamodel_One("ধারাঃ ২০৪","প্রমাণ হিসাবে পেশ করিতে না দেওয়ার জন্য কোন দলিল গোপন বা বিনষ্ট করা");
        dataholder_Fourteen.add(o14);
        datamodel_One o15 = new datamodel_One("ধারাঃ ২০৫"," কোন কার্য বা দেওয়ানী মোকদ্দমা বা ফৌজদারী মামলার উদ্দেশ্যে বা জামিনদার হওয়ার উদ্দেশ্যে ভূয়া পরিচয় দেওয়া");
        dataholder_Fourteen.add(o15);
        datamodel_One o16 = new datamodel_One("ধারাঃ ২০৬","বাজেয়াফতকরণ বা জরিমানা বা ডিক্রীর অর্থ আদায় করিবার জন্য আটক নিবারণের উদ্দেশ্যে প্রবঞ্চনা-মূলকভাবে সম্পত্তি অপসারণ বা গোপন করা");
        dataholder_Fourteen.add(o16);
        datamodel_One o17 = new datamodel_One("ধারাঃ ২০৭","বাজেয়াফতকরণ বা জরিমানা বা ডিক্রির অর্থ আদায় বাবদ সম্পত্তি লওয়া নিবারণের জন্য বিনা অধিকারে কোন সম্পত্তি দাবি করা বা সম্পত্তির অধিকার সম্পর্কে প্রবঞ্চনা করা");
        dataholder_Fourteen.add(o17);
        datamodel_One o18 = new datamodel_One("ধারাঃ ২০৮"," যে অর্থ পাওনা নয় তাহার জন্য প্রবঞ্চনামূলকভাবে ডিক্রী পাস হইতে দেওয়া বা অর্থ পরিশোধের পর ডিক্রী জারি হইতে দেওয়া");
        dataholder_Fourteen.add(o18);
        datamodel_One o19 = new datamodel_One("ধারা ২০৯","আদালতে মিথ্যা দাবি উত্থাপন করা");
        dataholder_Fourteen.add(o19);
        datamodel_One o20 = new datamodel_One("ধারাঃ ২১০","যে অর্থ পাওনা নয় তাহার জন্য প্রবঞ্চনামূলকভাবে ডিক্রী পাস করিয়া লওয়া, অর্থ পরিশোধের পর ডিক্রী জারি করা");
        dataholder_Fourteen.add(o20);

        datamodel_One o21 = new datamodel_One("ধারাঃ ২১১","ক্ষতি করিবার উদ্দেশ্যে অপরাধের মিথ্যা অভিযোগ");
        dataholder_Fourteen.add(o21);
        datamodel_One o22 = new datamodel_One("ধারাঃ ২১২","অপরাধীকে আশ্রয় দেওয়া, অপরাধটি মৃত্যুদন্ডে দণ্ডনীয় হইলে");
        dataholder_Fourteen.add(o22);
        datamodel_One o23 = new datamodel_One("ধারাঃ ২১৩","অপরাধীকে শাস্তি হইতে বাঁচাইবার জন্য উপহার প্রভৃতি গ্রহণ করা, অপরটি মৃত্যুদন্ডে দণ্ডনীয় হইলে");
        dataholder_Fourteen.add(o23);
        datamodel_One o24 = new datamodel_One("ধারাঃ ২১৪","অপরাধীকে শাস্তি হইতে বাঁচাইবার জন্য উপহার দেওয়ার বা সম্পত্তি ফিরাইয়া দেওয়ার প্রসত্মাব করা অপরাধটি মৃত্যুদন্ডে দণ্ডনীয় হইলে");
        dataholder_Fourteen.add(o24);
        datamodel_One o25 = new datamodel_One("ধারাঃ ২১৫","অপরাধীকে গ্রেফতার না করিয়া তাহার দ্বারা কৃত অপরাধ মারফত কাহাকেও বঞ্চিত করিয়া গৃহীত অস্থাবর সম্পত্তি উদ্ধারে সাহায্য করার জন্য উপহার গ্রহণ করা");
        dataholder_Fourteen.add(o25);
        datamodel_One o26 = new datamodel_One("ধারাঃ ২১৬","হাজত হইতে পলাতক বা গ্রেফতারের আদেশপ্রাপ্ত অপরাধীকে আশ্রয় দেওয়া, অপরাধটি মৃত্যুদন্ডে দণ্ডনীয় হইলে");
        dataholder_Fourteen.add(o26);
        datamodel_One o27 = new datamodel_One("ধারাঃ ২১৬-ক","দস্যু বা ডাকাতকে আশ্রয় দেওয়া");
        dataholder_Fourteen.add(o27);
        datamodel_One o28 = new datamodel_One("ধারাঃ ২১৭"," কোন ব্যক্তিকে শাস্তি হইতে বা কোন সম্পত্তি বাজেয়াফত হওয়া হইতে রক্ষার জন্য সরকারী কর্মচারী কর্তৃক আইনের নির্দেশ লংঘন");
        dataholder_Fourteen.add(o28);
        datamodel_One o29 = new datamodel_One("ধারাঃ ২১৮","কোন ব্যক্তিকে শাস্তি হইতে বা কোন সম্পত্তি বাজেয়াফত হওয়া হইতে রক্ষার জন্য সরকারী কর্মচারী কর্তৃক ভূল দলিল বা লিপি প্রণয়ন");
        dataholder_Fourteen.add(o29);
        datamodel_One o30 = new datamodel_One("ধারাঃ ২১৯","বিচার বিষয়ক কার্যক্রম আইন বিরোধী বলিয়া জানা সত্ত্বেও সরকারী কর্মচারী কর্তৃক দুর্নীতিমূলক উপায়ে আদেশ, রির্পোট, রায় বা সিদ্ধান্ত প্রণয়ন বা ঘোষণা করা");
        dataholder_Fourteen.add(o30);
        datamodel_One o31 = new datamodel_One("ধারাঃ ২২০","আইনের বিপরীত কার্যক্রম করিতেছেন বলিয়া জানা সত্ত্বেও কর্তৃত্বসম্পন্ন ব্যক্তি কর্তৃক কাহাকেও বিচারের জন্য সোপর্দ করা বা আটক রাখা");
        dataholder_Fourteen.add(o31);
        datamodel_One o32 = new datamodel_One("ধারাঃ ২২১","আইনতঃ গ্রেফতার করিতে বাধ্য হওয়া সত্ত্বেও সরকারী কর্মচারী কর্তৃক ইচ্ছাকৃতভাবে অপরাধীকে গ্রেফতার না করা, অপরাধটি মৃত্যুদন্ডে দণ্ডনীয় হইলে");
        dataholder_Fourteen.add(o32);
        datamodel_One o33 = new datamodel_One("ধারাঃ ২২২","আইনতঃ বাধ্য হওয়া সত্ত্বেও সরকারী কর্মচারী কর্তৃক ইচ্ছাকৃতভবে কোন আদালত কর্তৃক দন্ডিত ব্যক্তিকে গ্রেফতার করা, উক্ত ব্যক্তি মৃত্যুদন্ডে দন্ডিত হইলে");
        dataholder_Fourteen.add(o33);
        datamodel_One o34 = new datamodel_One("ধারাঃ ২২৩","সরকারী কর্মচারী কর্তৃক অবহেলা করিয়া কোন ব্যক্তিকে আটকাবস্থা হইতে পলায়ন করিতে দেওয়া");
        dataholder_Fourteen.add(o34);
        datamodel_One o35 = new datamodel_One("ধারাঃ ২২৪","কোন ব্যক্তি কর্তৃক তাহার আইনসঙ্গত গ্রেফতার প্রতিরোধ করা");
        dataholder_Fourteen.add(o35);
        datamodel_One o36 = new datamodel_One("ধারাঃ ২২৫","অপর কোন ব্যক্তির আইনসঙ্গত গ্রেফতার প্রতিরোধ করা বা তাহাকে আইনসঙ্গত হেফাজত হইতে উদ্ধার করা");
        dataholder_Fourteen.add(o36);
        datamodel_One o37 = new datamodel_One("ধারাঃ ২২৫-ক","যে সকল ক্ষেত্রে ভিন্নরূপ বিধান নাই সেই সকল ক্ষেত্রে সরকারী কর্মচারী কর্তৃক গ্রেফতার না করা বা পলায়ন করিতে দেওয়া");
        dataholder_Fourteen.add(o37);
        datamodel_One o38 = new datamodel_One("ধারা ২২৫খ"," যে সমস্ত ক্ষেত্রে ভিন্নরূপ বিধান নাই সেই সমসত্ম ক্ষেত্রে আইনসঙ্গত গ্রেফতার প্রতিরোধ বা পলায়ন বা উদ্ধার করা");
        dataholder_Fourteen.add(o38);
        datamodel_One o39 = new datamodel_One("ধারাঃ ২২৬","বাতিল");
        dataholder_Fourteen.add(o39);
        datamodel_One o40 = new datamodel_One("ধারাঃ ২২৭","দণ্ড মওকুফের শর্ত লংঘন করা");
        dataholder_Fourteen.add(o40);
        datamodel_One o41 = new datamodel_One("ধারাঃ ২২৮","বিচার বিষয়ক কার্যক্রমের কোন পর্যায়ে বিচারকের আসন গ্রহণকারী কোন সরকারী কর্মচারীকে ইচ্ছাকৃতভাবে অপমান করা বা তাহার কার্যে বাধা দেওয়া");
        dataholder_Fourteen.add(o41);
        datamodel_One o42 = new datamodel_One("ধারাঃ ২২৯","জুরি বা এসেসর হিসাবে মিথ্যা পরিচয় দেওয়া");
        dataholder_Fourteen.add(o42);
        datamodel_One o43 = new datamodel_One("ধারাঃ ২৩০","মুদ্রার সংজ্ঞা");
        dataholder_Fourteen.add(o43);


        MyAdapter_Fourteen myAdapter_fourteen = new MyAdapter_Fourteen(dataholder_Fourteen);
        recyclerView_Fourteen.setAdapter(myAdapter_fourteen);

        return view;
    }
}