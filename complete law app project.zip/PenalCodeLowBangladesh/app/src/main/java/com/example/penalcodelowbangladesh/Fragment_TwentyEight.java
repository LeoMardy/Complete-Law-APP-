package com.example.penalcodelowbangladesh;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textview.MaterialTextView;

import java.util.ArrayList;


public class Fragment_TwentyEight extends Fragment {

   RecyclerView recyclerView_28;
   ArrayList<datamodel_One> dataholder_28 = new ArrayList<>();


    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment__twenty_eight, container, false);

        recyclerView_28 = view.findViewById(R.id.recyclerView_28);
        recyclerView_28.setLayoutManager(new LinearLayoutManager(getContext()));


        datamodel_One oj1 = new datamodel_One("ধারাঃ ৩৮৩","বলপূর্বক আদায়");
        dataholder_28.add(oj1);
        datamodel_One oj2 = new datamodel_One("ধারাঃ ৩৮৪","বলপূর্বক গ্রহণের শাস্তি");
        dataholder_28.add(oj2);
        datamodel_One oj3 = new datamodel_One("ধারাঃ ৩৮৫","বলপূর্বক কিছু আদায়ের উদ্দেশ্যে কোন ব্যক্তিকে কোন ক্ষতির ভয় দেখানো");
        dataholder_28.add(oj3);
        datamodel_One oj4 = new datamodel_One("ধারাঃ ৩৮৬","কোন ব্যক্তিকে মৃত্যু বা গুরুতর আঘাতের ভয় দেখাইয়া বলপূর্বক গ্রহণ");
        dataholder_28.add(oj4);
        datamodel_One oj5 = new datamodel_One("ধারাঃ ৩৮৭","বলপূর্বক কিছু আদায় করার উদ্দেশ্যে কোন ব্যক্তিকে মৃত্যু বা মারাত্মক জখমের ভয় দেখানো");
        dataholder_28.add(oj5);
        datamodel_One oj6 = new datamodel_One("ধারাঃ ৩৮৮","মৃত্যুদন্ড বা যাবজ্জীবন কারাদন্ড ইত্যাদিতে দন্ডনীয় অপরাধের অভিযোগের ভয় দেখাইয়া বলপূর্বক গ্রহণ");
        dataholder_28.add(oj6);
        datamodel_One oj7 = new datamodel_One("ধারাঃ ৩৮৯","বলপূর্বক কিছু গ্রহণের উদ্দেশ্যে কোন ব্যক্তিকে অপরাধে অভিযুক্ত করিবার ভয় দেখানো");
        dataholder_28.add(oj7);


MyAdpater_28 m = new MyAdpater_28(dataholder_28);
recyclerView_28.setAdapter(m);

        return view;
    }

    public static class MyAdpater_28 extends RecyclerView.Adapter<MyAdpater_28.MyViewHolder_28>{
        protected static class MyViewHolder_28 extends RecyclerView.ViewHolder{

            MaterialCardView materialCardView_28;
            MaterialTextView materialTextView_Header_28, materialTextView_Desc_28;

            public MyViewHolder_28(@NonNull View itemView) {
                super(itemView);
                materialCardView_28 = itemView.findViewById(R.id.recycler_CardView);
                materialTextView_Header_28 = itemView.findViewById(R.id.recycler_TextViewHeader);
                materialTextView_Desc_28 = itemView.findViewById(R.id.recycler_TextViewDesc);
            }
        }
        ArrayList<datamodel_One> dataholder_28 ;

        public MyAdpater_28(ArrayList<datamodel_One> dataholder_28) {
            this.dataholder_28 = dataholder_28;
        }

        @NonNull
        @Override
        public MyViewHolder_28 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_xml_design_one,parent,false);

            return new MyViewHolder_28(view);
        }

        @Override
        public void onBindViewHolder(@NonNull MyViewHolder_28 holder, int position) {
            holder.materialTextView_Header_28.setText(dataholder_28.get(position).getHeader());
            holder.materialTextView_Desc_28.setText(dataholder_28.get(position).getDesc());
            holder.materialCardView_28.setOnClickListener(v -> {

                if (position == 0) {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_One_Fragment_TwentyEight()).addToBackStack(null).commit();


                } else if (position==1) {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Two_Fragment_TwentyEight()).addToBackStack(null).commit();


                }else if (position==2) {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Three_Fragment_TwentyEight()).addToBackStack(null).commit();


                }else if (position==3) {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Four_Fragment_TwentyEight()).addToBackStack(null).commit();


                }else if (position==4) {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Five_Fragment_TwentyEight()).addToBackStack(null).commit();


                }else if (position==5) {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Six_Fragment_TwentyEight()).addToBackStack(null).commit();


                }else  {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Seven_Fragment_TwentyEight()).addToBackStack(null).commit();


                }


            });

        }

        @Override
        public int getItemCount() {
            return 7;
        }
    }
}