package com.example.penalcodelowbangladesh;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textview.MaterialTextView;

import java.util.ArrayList;

public class Myadpater_Seven extends RecyclerView.Adapter<Myadpater_Seven.MyViewHolder2> {
    protected static class MyViewHolder2 extends RecyclerView.ViewHolder{
       final private MaterialCardView recycler_CardView;
       final private MaterialTextView recycler_TextViewHeader,recycler_TextViewDesc;
        public MyViewHolder2(@NonNull View itemView) {
            super(itemView);
            recycler_CardView = itemView.findViewById(R.id.recycler_CardView);
            recycler_TextViewHeader = itemView.findViewById(R.id.recycler_TextViewHeader);
            recycler_TextViewDesc = itemView.findViewById(R.id.recycler_TextViewDesc);
        }
    }
    ArrayList<datamodel_One> dataholder_seven;

    public Myadpater_Seven(ArrayList<datamodel_One> dataholder_seven) {
        this.dataholder_seven = dataholder_seven;
    }

    @NonNull
    @Override
    public MyViewHolder2 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View myView2 = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_xml_design_one,parent,false);
        return new MyViewHolder2(myView2);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder2 holder, @SuppressLint("RecyclerView") int position) {
        holder.recycler_TextViewHeader.setText(dataholder_seven.get(position).getHeader());
        holder.recycler_TextViewDesc.setText(dataholder_seven.get(position).getDesc());
        holder.recycler_CardView.setOnClickListener(v -> {
            switch (position){
                case 0:
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_One_Fragment_Seven()).addToBackStack(null).commit();
                    break;
                case 1:
                    AppCompatActivity activity1 = (AppCompatActivity) v.getContext();
                    activity1.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_two_Fragment_Seven()).addToBackStack(null).commit();
                    break;
            }
        });
    }

    @Override
    public int getItemCount() {
        return 2;
    }
}
