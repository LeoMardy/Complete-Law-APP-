package com.example.penalcodelowbangladesh;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textview.MaterialTextView;

import java.util.ArrayList;


public class Fragment_FourtyOne extends Fragment {

    RecyclerView recyclerView_FourtyOne;
    ArrayList<datamodel_One> dataholder_41 = new ArrayList<>();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment__fourty_one, container, false);
        recyclerView_FourtyOne = view.findViewById(R.id.recyclerView_FourtyOne);
        recyclerView_FourtyOne.setLayoutManager(new LinearLayoutManager(getContext()));

        datamodel_One k1 = new datamodel_One("ধারাঃ ৪৯৯","মানহানি");
        dataholder_41.add(k1);
        datamodel_One k2 = new datamodel_One("ধারাঃ ৫০০","মানহানির শাস্তি");
        dataholder_41.add(k2);
        datamodel_One k3 = new datamodel_One("ধারাঃ ৫০১","মানহানিকর বলিয়া পরিচিত বিষয় মুদ্রণ বা খোদাইকরণ");
        dataholder_41.add(k3);
        datamodel_One k4 = new datamodel_One("ধারাঃ ৫০২","মানহানির বিষয় সম্বলিত মুদ্রিত বা খোদাইকৃত বস্তু বিক্রয়");
        dataholder_41.add(k4);


        MyAdapter_41 myAdapter_41 = new MyAdapter_41(dataholder_41);
        recyclerView_FourtyOne.setAdapter(myAdapter_41);

        return view;
    }

    public static class MyAdapter_41 extends RecyclerView.Adapter<MyAdapter_41.MyViewHolder_41>{
        protected static class MyViewHolder_41 extends RecyclerView.ViewHolder{

            MaterialCardView materialCardView_41;
            MaterialTextView materialTextView_Header_41, materialTextView_Desc_41;

            public MyViewHolder_41(@NonNull View itemView) {
                super(itemView);

                materialCardView_41 = itemView.findViewById(R.id.recycler_CardView);
                materialTextView_Header_41 = itemView.findViewById(R.id.recycler_TextViewHeader);
                materialTextView_Desc_41 = itemView.findViewById(R.id.recycler_TextViewDesc);

            }
        }

        ArrayList<datamodel_One> dataholder_41;

        public MyAdapter_41(ArrayList<datamodel_One> dataholder_41) {
            this.dataholder_41 = dataholder_41;
        }

        @NonNull
        @Override
        public MyViewHolder_41 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_xml_design_one,parent,false);

            return new MyViewHolder_41(view);
        }

        @Override
        public void onBindViewHolder(@NonNull MyViewHolder_41 holder, int position) {

            holder.materialTextView_Desc_41.setText(dataholder_41.get(position).getDesc());
            holder.materialTextView_Header_41.setText(dataholder_41.get(position).getHeader());
            holder.materialCardView_41.setOnClickListener(v -> {

                if (position == 0) {
                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_One_Fragment_FourtyOne()).addToBackStack(null).commit();


                } else if (position==1) {

                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Two_Fragment_FourtyOne()).addToBackStack(null).commit();

                }else if (position==2) {

                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Three_Fragment_FourtyOne()).addToBackStack(null).commit();

                }else  {

                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Four_Fragment_FourtyOne()).addToBackStack(null).commit();

                }


            });
        }

        @Override
        public int getItemCount() {
            return 4;
        }
    }
}