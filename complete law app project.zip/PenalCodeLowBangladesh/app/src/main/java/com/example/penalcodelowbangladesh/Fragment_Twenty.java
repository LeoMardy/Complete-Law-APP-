package com.example.penalcodelowbangladesh;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textview.MaterialTextView;

import java.util.ArrayList;


public class Fragment_Twenty extends Fragment {

    RecyclerView recyclerView_Twenty;
    ArrayList<datamodel_One> dataholder_Twenty = new ArrayList<>();
    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment__twenty, container, false);
        recyclerView_Twenty = view.findViewById(R.id.recyclerView_20);
        recyclerView_Twenty.setLayoutManager(new LinearLayoutManager(getContext()));

        datamodel_One a1 = new datamodel_One("ধারাঃ ৩১২","গর্ভপাতকরণ");
        dataholder_Twenty.add(a1);
        datamodel_One a2 = new datamodel_One("ধারাঃ ৩১৩","নারীর সম্মতি ব্যতিরেকে গর্ভপাত করান");
        dataholder_Twenty.add(a2);
        datamodel_One a3 = new datamodel_One("ধারাঃ ৩১৪","গর্ভপাত করানোর উদ্দেশ্যে স্মপাদিত কার্যের ফলে মৃত্যু");
        dataholder_Twenty.add(a3);
        datamodel_One a4 = new datamodel_One("ধারাঃ ৩১৫","শিশুর জীবন্ত ভূমিষ্ঠ হওয়ায় বাধাদান করিবার বা জন্মের পর উহার মৃত্যু ঘটাইবার উদ্দেশ্যে কৃত কার্য");
        dataholder_Twenty.add(a4);
        datamodel_One a5= new datamodel_One("ধারাঃ ৩১৬","অপরাধজনক নরহত্যা বলিয়া গণ্য কার্যের সাহায্যে জীবন্ত অজাত শিশুর মৃত্যু সংঘটন");
        dataholder_Twenty.add(a5);
        datamodel_One a6 = new datamodel_One("ধারাঃ ৩১৭","পিতা বা মাতা অথবা তত্ত্ববধায়ক কর্তৃক বার বৎসরের নিম্ন বয়স্কশিশু পরিত্যাগ ও বর্জন");
        dataholder_Twenty.add(a6);
        datamodel_One a7 = new datamodel_One("ধারাঃ ৩১৮","মৃতদেহের গোপন ব্যবস্থার সাহায্যে জন্ম গোপনকরণ");
        dataholder_Twenty.add(a7);




        MyAdapter_twenty myAdapter_twenty = new MyAdapter_twenty(dataholder_Twenty);
        recyclerView_Twenty.setAdapter(myAdapter_twenty);
        return view;
    }
    public static class MyAdapter_twenty extends RecyclerView.Adapter<MyAdapter_twenty.MyViewHolder_twenty>{
        protected static class MyViewHolder_twenty extends RecyclerView.ViewHolder{

            MaterialTextView recycerTextView_Header_20,recycerTextView_Desc_20;
            MaterialCardView recyclerCardView_20;
            public MyViewHolder_twenty(@NonNull View itemView) {
                super(itemView);
                recycerTextView_Header_20 = itemView.findViewById(R.id.recycler_TextViewHeader);
                recycerTextView_Desc_20 = itemView.findViewById(R.id.recycler_TextViewDesc);
                recyclerCardView_20 = itemView.findViewById(R.id.recycler_CardView);

            }
        }
        ArrayList<datamodel_One> dataholder_twenty;

        public MyAdapter_twenty(ArrayList<datamodel_One> dataholder_twenty) {
            this.dataholder_twenty = dataholder_twenty;
        }

        @NonNull
        @Override
        public MyViewHolder_twenty onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_xml_design_one,parent,false);

            return new MyViewHolder_twenty(view);
        }

        @Override
        public void onBindViewHolder(@NonNull MyViewHolder_twenty holder, int position) {
            holder.recycerTextView_Header_20.setText(dataholder_twenty.get(position).getHeader());
            holder.recycerTextView_Desc_20.setText(dataholder_twenty.get(position).getDesc());
            holder.recyclerCardView_20.setOnClickListener(v -> {

                if (position == 0) {
                    AppCompatActivity activity= (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_One_Fragment_Twenty()).addToBackStack(null).commit();


                } else if (position==1) {
                    AppCompatActivity activity1= (AppCompatActivity) v.getContext();
                    activity1.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Two_Fragment_Twenty()).addToBackStack(null).commit();


                } else if (position==2) {
                    AppCompatActivity activity2= (AppCompatActivity) v.getContext();
                    activity2.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Three_Fragment_Twenty()).addToBackStack(null).commit();


                } else if (position==3) {
                    AppCompatActivity activity3= (AppCompatActivity) v.getContext();
                    activity3.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Four_Fragment_Twenty()).addToBackStack(null).commit();


                } else if (position==4) {
                    AppCompatActivity activity4= (AppCompatActivity) v.getContext();
                    activity4.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Five_Fragment_Twenty()).addToBackStack(null).commit();


                } else if (position==5) {
                    AppCompatActivity activity4= (AppCompatActivity) v.getContext();
                    activity4.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Six_Fragment_Twenty()).addToBackStack(null).commit();


                } else  {
                    AppCompatActivity activity5= (AppCompatActivity) v.getContext();
                    activity5.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Seven_Fragment_Twenty()).addToBackStack(null).commit();


                }

            });
        }

        @Override
        public int getItemCount() {
            return 7;
        }

    }
}