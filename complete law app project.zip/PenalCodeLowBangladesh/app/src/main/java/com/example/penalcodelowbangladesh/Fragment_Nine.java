package com.example.penalcodelowbangladesh;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;


public class Fragment_Nine extends Fragment {
    private RecyclerView recyclerViewID;
    private ArrayList<datamodel_One> dataholder_Nine = new ArrayList<>();
    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment__nine, container, false);
        recyclerViewID = view.findViewById(R.id.recyclerViewID);
        recyclerViewID.setLayoutManager(new LinearLayoutManager(getContext()));

        datamodel_One obj1 = new datamodel_One("ধারাঃ ১৩১","বিদ্রোহে উসকানি দেওয়া বা কোন অফিসার, সৈনিক, নাবিক, বা বৈমানিককে তাহার আনুগত্য বা কর্তব্যচ্যুত করার চেষ্টা করা");
        dataholder_Nine.add(obj1);
        datamodel_One obj2 = new datamodel_One("ধারাঃ ১৩২","বিদ্রোহে উসকানি দেওয়া, যদি তাহার ফলে বিদ্রোহ সংঘটিত হয়");
        dataholder_Nine.add(obj2);
        datamodel_One obj3 = new datamodel_One("ধারাঃ ১৩৩","কোন অফিসার, সৈনিক, নাবিক বা বৈমানিক কর্তৃক তাহার ঊর্ধ্বতন অফিসারের উপর কর্তব্যরত থাকাকালে হামলায় উসকানি দেওয়া");
        dataholder_Nine.add(obj3);
        datamodel_One obj4 = new datamodel_One("ধারাঃ ১৩৪", "অনুরূপ আক্রমণে সহায়তাকরণ, আক্রমণ সংঘটিত হইবার ক্ষেত্রে");
        dataholder_Nine.add(obj4);
        datamodel_One obj5 = new datamodel_One("ধারাঃ ১৩৫","সৈনিক, নাবিক বা বৈমানিকের পলায়নে সহায়তাকরণ");
        dataholder_Nine.add(obj5);
        datamodel_One obj6 = new datamodel_One("ধারাঃ ১৩৬","পলাতককে আশ্রয়দান করা");
        dataholder_Nine.add(obj6);
        datamodel_One obj7 = new datamodel_One("ধারাঃ ১৩৭","পোতাধ্যক্ষের অবহেলার দরুন বাণিজ্যপোতে গোপনকৃত পলাতক");
        dataholder_Nine.add(obj7);
        datamodel_One obj8 = new datamodel_One("ধারাঃ ১৩৮", "সৈনিক, নাবিক বা বৈমানিক কর্তৃক অবাধ্যতা প্রদর্শনে সহায়তাকরণ");
        dataholder_Nine.add(obj8);
        datamodel_One obj9 = new datamodel_One("ধারাঃ ১৩৮-ক","বাতিল");
        dataholder_Nine.add(obj9);
        datamodel_One obj10 = new datamodel_One("ধারাঃ ১৩৯","কতিপয় আইনের অধীন ব্যক্তিগণ");
        dataholder_Nine.add(obj10);
        datamodel_One obj11 = new datamodel_One("ধারাঃ ১৪০","সৈনিক, নাবিক বা বৈমানিক কর্তৃক ব্যবহৃত পোশাক পরিধান করা বা প্রতীক ধারণ করা");
        dataholder_Nine.add(obj11);

        MyAdapter_Nine myAdapter_nine = new MyAdapter_Nine(dataholder_Nine);
        recyclerViewID.setAdapter(myAdapter_nine);

        return view;
    }
}