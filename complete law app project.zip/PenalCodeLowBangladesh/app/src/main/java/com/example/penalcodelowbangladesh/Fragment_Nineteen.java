package com.example.penalcodelowbangladesh;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textview.MaterialTextView;

import java.util.ArrayList;


public class Fragment_Nineteen extends Fragment {

 RecyclerView recyclerView_Nineteen;
 ArrayList<datamodel_One> dataholder_nineteen = new ArrayList<>();

    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment__nineteen, container, false);
        recyclerView_Nineteen = view.findViewById(R.id.recyclerView_Nineteen);
        recyclerView_Nineteen.setLayoutManager(new LinearLayoutManager(getContext()));

        datamodel_One ob1 = new datamodel_One("ধারাঃ ২৯৯","অপরাধজনক নরহত্যা");
        dataholder_nineteen.add(ob1);
        datamodel_One ob2 = new datamodel_One("ধারাঃ ৩০০","খুন");
        dataholder_nineteen.add(ob2);
        datamodel_One ob3 = new datamodel_One("ধারাঃ ৩০১","যে ব্যক্তির মৃত্যু অভীষ্ট ছিল সেই ব্যক্তি ভিন্ন অন্য কোন ব্যক্তির মৃত্যু ঘটাইয়া নরহত্যা অনুষ্ঠান");
        dataholder_nineteen.add(ob3);
        datamodel_One ob4 = new datamodel_One("ধারাঃ ৩০২","খুনের শাস্তি");
        dataholder_nineteen.add(ob4);
        datamodel_One ob5 = new datamodel_One("ধারাঃ ৩০৩","যাবজ্জীবন কারাবাসে দন্ডিত ব্যক্তি কর্তৃক অনুষ্ঠিত খুনের শাস্তি");
        dataholder_nineteen.add(ob5);
        datamodel_One ob6 = new datamodel_One("ধারাঃ ৩০৪","খুন বলিয়া গণ্য নহে এইরূপ অপরাধজনক নরহত্যার শাস্তি");
        dataholder_nineteen.add(ob6);
        datamodel_One ob7 = new datamodel_One("ধারাঃ ৩০৪-ক","অবহেলার ফলে ঘটিত মৃত্যু");
        dataholder_nineteen.add(ob7);
        datamodel_One ob8 = new datamodel_One("ধারাঃ ৩০৪-খ","বেপরোয়া যান বা অশ্ব চালনার দ্বারা মৃত্যু ঘটান");
        dataholder_nineteen.add(ob8);
        datamodel_One ob9 = new datamodel_One("ধারাঃ ৩০৫"," শিশু বা উম্মাদ ব্যক্তির আত্মহত্যা সহায়তাকরণ");
        dataholder_nineteen.add(ob9);
        datamodel_One ob10 = new datamodel_One("ধারাঃ ৩০৬","আত্মহত্যায় সহায়তাকরণ");
        dataholder_nineteen.add(ob10);
        datamodel_One ob11 = new datamodel_One("ধারাঃ ৩০৭","খুনের উদ্যোগ");
        dataholder_nineteen.add(ob11);

        datamodel_One ob12 = new datamodel_One("ধারাঃ ৩০৮","অপরাধজনক নরহত্যা অনুষ্ঠানের উদ্যোগ");
        dataholder_nineteen.add(ob12);
        datamodel_One ob13 = new datamodel_One("ধারাঃ ৩০৯","আত্মহত্যা করিবার উদ্যোগ");
        dataholder_nineteen.add(ob13);
        datamodel_One ob14 = new datamodel_One("ধারাঃ ৩১০","ঠগ");
        dataholder_nineteen.add(ob14);
        datamodel_One ob15 = new datamodel_One("ধারাঃ ৩১১","ঠগের শাস্তি");
        dataholder_nineteen.add(ob15);



        MyAdapter_Nineteen myAdapter_nineteen = new MyAdapter_Nineteen(dataholder_nineteen);
        recyclerView_Nineteen.setAdapter(myAdapter_nineteen);

        return view;
    }
    public static class MyAdapter_Nineteen extends RecyclerView.Adapter<MyAdapter_Nineteen.MyViewHolder_Nineteen>{
        protected static class MyViewHolder_Nineteen extends RecyclerView.ViewHolder{

            MaterialTextView recycerTextView_Header_19,recycerTextView_Desc_19;
            MaterialCardView recyclerCardView_19;

            public MyViewHolder_Nineteen(@NonNull View itemView) {
                super(itemView);

                recycerTextView_Header_19 = itemView.findViewById(R.id.recycler_TextViewHeader);
                recycerTextView_Desc_19 = itemView.findViewById(R.id.recycler_TextViewDesc);
                recyclerCardView_19 = itemView.findViewById(R.id.recycler_CardView);

            }
        }
        ArrayList<datamodel_One> dataholder_nineteen;

        public MyAdapter_Nineteen(ArrayList<datamodel_One> dataholder_nineteen) {
            this.dataholder_nineteen = dataholder_nineteen;
        }

        @NonNull
        @Override
        public MyViewHolder_Nineteen onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_xml_design_one,parent,false);

            return new MyViewHolder_Nineteen(view);
        }

        @Override
        public void onBindViewHolder(@NonNull MyViewHolder_Nineteen holder, int position) {
      holder.recycerTextView_Header_19.setText(dataholder_nineteen.get(position).getHeader());
      holder.recycerTextView_Desc_19.setText(dataholder_nineteen.get(position).getDesc());
      holder.recyclerCardView_19.setOnClickListener(v -> {

          if (position == 0) {
              AppCompatActivity activity = (AppCompatActivity) v.getContext();
              activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_One_Fragment_Nineteen()).addToBackStack(null).commit();

          } else if (position==1) {
              AppCompatActivity activity1 = (AppCompatActivity) v.getContext();
              activity1.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Two_Fragment_Nineteen()).addToBackStack(null).commit();


          } else if (position==2) {
              AppCompatActivity activity2 = (AppCompatActivity) v.getContext();
              activity2.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Three_Fragment_Nineteen()).addToBackStack(null).commit();


          } else if (position==3) {
              AppCompatActivity activity3 = (AppCompatActivity) v.getContext();
              activity3.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Four_Fragment_Nineteen()).addToBackStack(null).commit();


          } else if (position==4) {
              AppCompatActivity activity4 = (AppCompatActivity) v.getContext();
              activity4.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Five_Fragment_Nineteen()).addToBackStack(null).commit();


          } else if (position==5) {
              AppCompatActivity activity5 = (AppCompatActivity) v.getContext();
              activity5.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Six_Fragment_Nineteen()).addToBackStack(null).commit();


          } else if (position==6) {
              AppCompatActivity activity6 = (AppCompatActivity) v.getContext();
              activity6.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Seven_Fragment_Nineteen()).addToBackStack(null).commit();


          } else if (position==7) {
              AppCompatActivity activity7 = (AppCompatActivity) v.getContext();
              activity7.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Eight_Fragment_Nineteen()).addToBackStack(null).commit();


          } else if (position==8) {
              AppCompatActivity activity8 = (AppCompatActivity) v.getContext();
              activity8.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Nine_Fragment_Nineteen()).addToBackStack(null).commit();


          } else if (position==9) {
              AppCompatActivity activity9 = (AppCompatActivity) v.getContext();
              activity9.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Ten_Fragment_Nineteen()).addToBackStack(null).commit();


          } else if (position==10) {
              AppCompatActivity activity10 = (AppCompatActivity) v.getContext();
              activity10.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Eleven_Fragment_Nineteen()).addToBackStack(null).commit();


          } else if (position==11) {
              AppCompatActivity activity11 = (AppCompatActivity) v.getContext();
              activity11.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Twelve_Fragment_Nineteen()).addToBackStack(null).commit();


          } else if (position==12) {
              AppCompatActivity activity12 = (AppCompatActivity) v.getContext();
              activity12.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Thirteen_Fragment_Nineteen()).addToBackStack(null).commit();


          } else if (position==13){
              AppCompatActivity activity13 = (AppCompatActivity) v.getContext();
              activity13.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Fourteen_Fragment_Nineteen()).addToBackStack(null).commit();

          } else {
              AppCompatActivity activity14 = (AppCompatActivity) v.getContext();
              activity14.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Fifteen_Fragment_Nineteen()).addToBackStack(null).commit();


          }

      });
        }

        @Override
        public int getItemCount() {
            return 15;
        }
    }
}