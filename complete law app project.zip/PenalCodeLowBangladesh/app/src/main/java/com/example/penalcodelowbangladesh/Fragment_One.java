package com.example.penalcodelowbangladesh;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.appbar.MaterialToolbar;

import java.util.ArrayList;


public class Fragment_One extends Fragment {
  private RecyclerView recyclerView;

  private ArrayList<datamodel_One> dataholder_One = new ArrayList<>();
    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment__one, container, false);
        recyclerView = view.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));



       datamodel_One ob1 = new datamodel_One("ধারা-১","শিরোনাম ও আইনের কার্যকারিতার সীমা");
       dataholder_One.add(ob1);
        datamodel_One ob2 = new datamodel_One("ধারা-২","বাংলাদেশের মধ্যে সংঘটিত অপরাধ এর সাজা");
        dataholder_One.add(ob2);
        datamodel_One ob3 = new datamodel_One("ধারা-৩","বাংলাদেশের বাইরে সংঘটিত কিন্তু আইনবলে বাংলাদেশের মধ্যে বিচারযোগ্য অপরাধ সমূহের সাজা");
        dataholder_One.add(ob3);
        datamodel_One ob4 = new datamodel_One("ধারা-৪","বাংলাদেশের বাইরে সংঘটিত অপরাধের জন্য বিধিটির আওতার সম্প্রসারণ");
        dataholder_One.add(ob4);
        datamodel_One ob5 = new datamodel_One("ধারা-৫","এই বিধি দ্বারা কতিপয় আইন ক্ষুন্ন হবে না");
        dataholder_One.add(ob5);

        MyAdpater_One myAdpater_one = new MyAdpater_One(dataholder_One);
        recyclerView.setAdapter(myAdpater_one);

        return view;
    }
}