package com.example.penalcodelowbangladesh;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textview.MaterialTextView;

import java.util.ArrayList;


public class Fragment_TwentyOne extends Fragment {

    RecyclerView recyclerView_21;
    ArrayList<datamodel_One> dataholder_21 = new ArrayList<>();


    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment__twenty_one, container, false);
        recyclerView_21 = view.findViewById(R.id.recyclerView_21);
        recyclerView_21.setLayoutManager(new LinearLayoutManager(getContext()));

        datamodel_One o0 = new datamodel_One("ধারাঃ ৩১৯","আঘাত");
        dataholder_21.add(o0);
        datamodel_One o1 = new datamodel_One("ধারাঃ ৩২০","গুরুতর অঘাত");
        dataholder_21.add(o1);
        datamodel_One o2 = new datamodel_One("ধারাঃ ৩২১","সেচ্ছাকৃত ভাবে আঘাত দান করা");
        dataholder_21.add(o2);
        datamodel_One o3 = new datamodel_One("ধারাঃ ৩২২"," সেচ্ছাকৃত ভাবে গুরুতর আঘাত দান");
        dataholder_21.add(o3);
        datamodel_One o4 = new datamodel_One("ধারাঃ ৩২৩","স্বেচ্ছাকৃতভাবে আঘাত দানের শাস্তি");
        dataholder_21.add(o4);
        datamodel_One o5 = new datamodel_One("ধারাঃ ৩২৪","স্বেচ্ছাকৃতভাবে মারাত্মক অস্ত্র বা অন্য মাধ্যমের সাহায্যে ");
        dataholder_21.add(o5);
        datamodel_One o6 = new datamodel_One("ধারাঃ ৩২৫","স্বেচ্ছাকৃতভাবে গুরুতর আঘাত দানের শাস্তি");
        dataholder_21.add(o6);
        datamodel_One o7 = new datamodel_One("ধারাঃ ৩২৬","স্বেচ্ছাকৃতভাবে মারাত্মক অস্ত্র বা মাধ্যমের সাহায্যে গুরুতর আধাত দান করা");
        dataholder_21.add(o7);
        datamodel_One o8 = new datamodel_One("ধারাঃ ৩২৬-ক"," স্বেচ্চাকৃতভাবে দু’টি চোখ উপড়াইয়া বা এসিড জাতীয় পদার্থ দ্বারা চোখ দুটির দুষ্টিশক্তি নষ্টকরণ বা মুখমন্ডল বা মস্তক এসিড দ্বারা বিকৃতিকরণ");
        dataholder_21.add(o8);
        datamodel_One o9 = new datamodel_One("ধারাঃ ৩২৭","বলপূর্বক সম্পত্তি ছিনাইয়া লওয়া বা কোন অবৈধ কাজ করিতে বাধ্য করিবার জন্য স্বেচ্ছাকৃতভাবে আঘাত দান করা");
        dataholder_21.add(o9);

        datamodel_One o10 = new datamodel_One("ধারাঃ ৩২৮","কোন অপরাধ অনুষ্ঠানের উদ্দেশ্যে বিষ ইত্যাদি প্রয়োগের মাধ্যমে আঘাত দান করা");
        dataholder_21.add(o10);
        datamodel_One o11 = new datamodel_One("ধারাঃ ৩২৯","বলপূর্বক সম্পত্তি বা মূল্যবান দলিল গ্রহণ বা এমন কোন কাজ করিতে বাধ্য করিবার জন্য স্বেচ্ছাকৃতভাবে গুরুতর আঘাত দান করা");
        dataholder_21.add(o11);
        datamodel_One o12 = new datamodel_One("ধারাঃ ৩৩০","বলপূর্বক সম্পত্তি ছিনাইয়অ লওয়া বা কোন অবৈধ কার্য করিতে বাধ্য করিবার জন্য স্বেচ্ছাকৃতভাবে আঘাত দান করা");
        dataholder_21.add(o12);
        datamodel_One o13 = new datamodel_One("ধারাঃ ৩৩১","বলপূর্বক অপরাধের স্বীকারোক্তি আদায় করা বা সম্পত্তি প্রত্যর্পণে বাধ্য করিবার জন্য স্বেচ্ছাকৃতভাবে গুরুতর আঘাত দান করা");
        dataholder_21.add(o13);
        datamodel_One o14 = new datamodel_One("ধারাঃ ৩৩২","সরকারী কর্মচারীকে তাহার কর্তব্য পালনে বাধাদান করিবার জন্য স্বেচ্ছাকৃতভাবে আঘাত দান করা");
        dataholder_21.add(o14);
        datamodel_One o15 = new datamodel_One("ধারাঃ ৩৩৩","সরকারী কর্মচারীকে তাহার কর্তব্য পালনে বাধাদান করিবার জন্য স্বেচ্ছাকৃতভাবে গুরুতর আঘাত দান করা");
        dataholder_21.add(o15);
        datamodel_One o16 = new datamodel_One("ধারাঃ ৩৩৪","উত্তেজনাবশতঃ স্বেচ্ছাকৃতভাবে আঘাত দান করা");
        dataholder_21.add(o16);
        datamodel_One o17 = new datamodel_One("ধারাঃ ৩৩৫","উত্তেজনাবশতঃ স্বেচ্ছাকৃতভাবে গুরুতর আঘাত দান করা");
        dataholder_21.add(o17);
        datamodel_One o18 = new datamodel_One("ধারাঃ ৩৩৬","অন্যান্য লোকের জীবন বা ব্যক্তিগত নিরাপত্তা বিপন্নকারী কার্য");
        dataholder_21.add(o18);
        datamodel_One o19 = new datamodel_One("ধারাঃ ৩৩৭","অন্যান্য লোকের জীবন বা ব্যক্তিগত নিরাপত্তা বিপন্নকারী কার্যের মাধ্যমে আঘাত দান করা");
        dataholder_21.add(o19);

        datamodel_One o20 = new datamodel_One("ধারাঃ ৩৩৮","অন্যান্য লোকের জীবন বা ব্যক্তিগত নিরাপত্তা বিপন্নকারী কার্যের মাধ্যমে গুরুতর আঘাত দান করা");
        dataholder_21.add(o20);
        datamodel_One o21 = new datamodel_One("ধারাঃ ৩৩৮-ক"," জনপথে বেপরোয়া যান বা অশ্ব চালনা করিয়া গুরুতর আঘাত");
        dataholder_21.add(o21);



        MyAdpater_21 myAdpater_21 = new MyAdpater_21(dataholder_21);
        recyclerView_21.setAdapter(myAdpater_21);

        return view;
    }
    public static class MyAdpater_21 extends RecyclerView.Adapter<MyAdpater_21.MyViewHolder_21>{
        protected static class MyViewHolder_21 extends RecyclerView.ViewHolder{

            MaterialCardView materialCardView_21;
            MaterialTextView materialTextView_Header_21,materialTextView_Desc_21;

            public MyViewHolder_21(@NonNull View itemView) {
                super(itemView);

                materialCardView_21 = itemView.findViewById(R.id.recycler_CardView);
                materialTextView_Header_21 = itemView.findViewById(R.id.recycler_TextViewHeader);
                materialTextView_Desc_21 = itemView.findViewById(R.id.recycler_TextViewDesc);


            }
        }

        ArrayList<datamodel_One> dataholder_21;

        public MyAdpater_21(ArrayList<datamodel_One> dataholder_21) {
            this.dataholder_21 = dataholder_21;
        }

        @NonNull
        @Override
        public MyViewHolder_21 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_xml_design_one,parent,false);

            return new MyViewHolder_21(view);
        }

        @Override
        public void onBindViewHolder(@NonNull MyViewHolder_21 holder, int position) {

            holder.materialTextView_Header_21.setText(dataholder_21.get(position).getHeader());
            holder.materialTextView_Desc_21.setText(dataholder_21.get(position).getDesc());
            holder.materialCardView_21.setOnClickListener(v -> {

                if (position == 0) {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_One_Fragment_TwentyOne()).addToBackStack(null).commit();


                } else if (position==1) {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Two_Fragment_TwentyOne()).addToBackStack(null).commit();


                } else if (position==2) {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Three_Fragment_TwentyOne()).addToBackStack(null).commit();


                }else if (position==3) {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Four_Fragment_TwentyOne()).addToBackStack(null).commit();


                }else if (position==4) {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Five_Fragment_TwentyOne()).addToBackStack(null).commit();


                }else if (position==5) {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Six_Fragment_TwentyOne()).addToBackStack(null).commit();


                }else if (position==6) {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Seven_Fragment_TwentyOne()).addToBackStack(null).commit();


                }else if (position==7) {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Eight_Fragment_TwentyOne()).addToBackStack(null).commit();


                }else if (position==8) {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Nine_Fragment_TwentyOne()).addToBackStack(null).commit();


                }else if (position==9) {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Ten_Fragment_TwentyONe()).addToBackStack(null).commit();


                }else if (position==10) {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Eleven_Fragment_TwentyOne()).addToBackStack(null).commit();


                }else if (position==11) {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Twelve_Fragment_TwentyOne()).addToBackStack(null).commit();


                }else if (position==12) {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Thirteen_Fragment_TwentyOne()).addToBackStack(null).commit();


                }else if (position==13) {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Fourteen_Fragment_TwentyOne()).addToBackStack(null).commit();


                }else if (position==14) {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Fifteen_Fragment_TwentyOne()).addToBackStack(null).commit();


                }else if (position==15) {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Sixteen_Fragment_TwentyOne()).addToBackStack(null).commit();


                }else if (position==16) {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Seventeen_Fragment_TwentyOne()).addToBackStack(null).commit();


                }else if (position==17) {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Eighteen_Fragment_TwentyOne()).addToBackStack(null).commit();


                }else if (position==18) {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Nineteen_Fragment_TwentyOne()).addToBackStack(null).commit();


                }else if (position==19) {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Twenty_Fragment_TwentyOne()).addToBackStack(null).commit();


                }else if (position==20) {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_TwentyOne_Fragment_TwentyOne()).addToBackStack(null).commit();


                }else {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_TwentyTwo_Fragment_TwentyOne()).addToBackStack(null).commit();


                }


            });

        }

        @Override
        public int getItemCount() {
            return 22;
        }
    }
}