package com.example.penalcodelowbangladesh;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textview.MaterialTextView;

import java.util.ArrayList;


public class Fragment_TwentyFour extends Fragment {

    RecyclerView recyclerView_24;
    ArrayList<datamodel_One> dataholder_24 = new ArrayList<>();


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment__twenty_four, container, false);
        recyclerView_24 = view.findViewById(R.id.recycleView_24);
        recyclerView_24.setLayoutManager(new LinearLayoutManager(getContext()));

        datamodel_One ok1 = new datamodel_One("ধারাঃ ৩৫৯","মনুষ্যহরণ");
        dataholder_24.add(ok1);
        datamodel_One ok2 = new datamodel_One("ধারাঃ ৩৬০","বাংলাদেশ হইতে মনুষ্যহরণ");
        dataholder_24.add(ok2);
        datamodel_One ok3 = new datamodel_One("ধারাঃ ৩৬১","আইনানুগ অভিভাবকত্ব হইতে মনুষ্যহরণ");
        dataholder_24.add(ok3);
        datamodel_One ok4 = new datamodel_One("ধারাঃ ৩৬২","অপহরণ");
        dataholder_24.add(ok4);
        datamodel_One ok5 = new datamodel_One("ধারাঃ ৩৬৩","মনুষ্য হরণের শাস্তি");
        dataholder_24.add(ok5);
        datamodel_One ok6 = new datamodel_One("ধারাঃ ৩৬৪","খুন করিবার উদ্দেশ্যে মনুষ্য হরণ কিংবা অপহরণ");
        dataholder_24.add(ok6);
        datamodel_One ok7 = new datamodel_One("ধারাঃ ৩৬৪-ক","দশ বৎসরের কম বয়স্ক কোন ব্যক্তিকে অপহরণ বা হরণ করা");
        dataholder_24.add(ok7);
        datamodel_One ok8 = new datamodel_One("ধারাঃ ৩৬৫","কোন ব্যক্তিকে গোপনভাবে ও অবৈধভাবে অবরোধ করিবার উদ্দেশ্যে অপহরণ বা প্রতারণাপূর্বক হরণ");
        dataholder_24.add(ok8);
        datamodel_One ok9 = new datamodel_One("ধারাঃ ৩৬৬","কোন নারীকে বিবাহ ইত্যাদিতে বাধ্য করিবার নিমিত্তে অপহরণ প্রতারণাপূর্বক হরণ বা প্রলুব্ধকরণ");
        dataholder_24.add(ok9);
        datamodel_One ok10 = new datamodel_One("ধারাঃ ৩৬৬-ক","অপ্রাপ্ত বয়স্কা বালিকা সংগ্রহকরণ");
        dataholder_24.add(ok10);
        datamodel_One ok11 = new datamodel_One("ধারাঃ ৩৬৬-খ","বিদেশ হইতে বালিকা আমদানি");
        dataholder_24.add(ok11);
        datamodel_One ok12 = new datamodel_One("ধারাঃ ৩৬৭","কোন ব্যক্তিকে গুরুতর আঘাত বা দাসত্বাধীন করিবার উদ্দেশ্যে অপহরণ বা প্রতারণাপূর্বক হরণ");
        dataholder_24.add(ok12);
        datamodel_One ok13 = new datamodel_One("ধারাঃ ৩৬৮","অপহৃত বা প্রতারণাপূর্বক হরণকৃত ব্যক্তিকে অবৈধভাবে গোপন বা অবরোধ করা");
        dataholder_24.add(ok13);
        datamodel_One ok14 = new datamodel_One("ধারাঃ ৩৬৯","দেহাবরণ চুরি করিবার অভিপ্রায় দশ বৎসরের কম বয়স্ক শিশু অপহরণ বা প্রতারণাপূর্বক হরণ করা");
        dataholder_24.add(ok14);
        datamodel_One ok15 = new datamodel_One("ধারাঃ ৩৭০","দাসরূপে কোন ব্যক্তিকে ক্রয় বা হস্তান্তর করা");
        dataholder_24.add(ok15);
        datamodel_One ok16 = new datamodel_One("ধারাঃ ৩৭১","অভ্যাসদহ দাস ব্যবসায় পরিচালনা করা");
        dataholder_24.add(ok16);
        datamodel_One ok17 = new datamodel_One("ধারাঃ ৩৭২","বেশ্যাবৃত্তি ইত্যাদির উদ্দেশ্যে অপ্রাপ্ত বয়স্কদের বিক্রয়");
        dataholder_24.add(ok17);
        datamodel_One ok18 = new datamodel_One("ধারাঃ ৩৭৩"," বেশ্যাবৃত্তি ইত্যাদির উদ্দেশ্যে অপ্রাপ্ত বয়স্কদের ক্রয়করণ");
        dataholder_24.add(ok18);
        datamodel_One ok19 = new datamodel_One("ধারাঃ ৩৭৪","বেআইনী শ্রমে বাধ্য করা");
        dataholder_24.add(ok19);



MyAdapter_24 myAdapter_24 = new MyAdapter_24(dataholder_24);
recyclerView_24.setAdapter(myAdapter_24);

        return view;
    }

    public static class MyAdapter_24 extends RecyclerView.Adapter<MyAdapter_24.MyViewHolder_24>{
        protected static class MyViewHolder_24 extends RecyclerView.ViewHolder{

            MaterialCardView materialCardView_24;
            MaterialTextView materialTextView_Header_24, materialTextView_Desc_24;


            public MyViewHolder_24(@NonNull View itemView) {
                super(itemView);

                materialCardView_24 = itemView.findViewById(R.id.recycler_CardView);
                materialTextView_Desc_24 = itemView.findViewById(R.id.recycler_TextViewDesc);
                materialTextView_Header_24 = itemView.findViewById(R.id.recycler_TextViewHeader);

            }
        }
        ArrayList<datamodel_One> dataholder_24;

        public MyAdapter_24(ArrayList<datamodel_One> dataholder_24) {
            this.dataholder_24 = dataholder_24;
        }

        @NonNull
        @Override
        public MyViewHolder_24 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_xml_design_one,parent,false);

            return new MyViewHolder_24(view);
        }

        @Override
        public void onBindViewHolder(@NonNull MyViewHolder_24 holder, int position) {

            holder.materialTextView_Header_24.setText(dataholder_24.get(position).getHeader());
            holder.materialTextView_Desc_24.setText(dataholder_24.get(position).getDesc());
            holder.materialCardView_24.setOnClickListener(v -> {

                if (position == 0) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_One_Fragment_TwentyFour()).addToBackStack(null).commit();


                } else if (position==1) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Two_Fragment_TwentyFour()).addToBackStack(null).commit();

                }else if (position==2) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Three_Fragment_TwentyFour()).addToBackStack(null).commit();

                }else if (position==3) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Four_Fragment_TwentyFour()).addToBackStack(null).commit();

                }else if (position==4) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Five_Fragment_TwentyFour()).addToBackStack(null).commit();

                }else if (position==5) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Six_Fragment_TwentyFour()).addToBackStack(null).commit();

                }else if (position==6) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Seven_Fragment_TwentyFour()).addToBackStack(null).commit();

                }else if (position==7) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Eight_Fragment_TwentyFour()).addToBackStack(null).commit();

                }else if (position==8) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Nine_Fragment_TwentyFour()).addToBackStack(null).commit();

                }else if (position==9) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Ten_Fragment_TwentyFour()).addToBackStack(null).commit();

                }else if (position==10) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Eleven_Fragment_TwentyFour()).addToBackStack(null).commit();

                }else if (position==11) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Twelve_Fragment_TwentyFour()).addToBackStack(null).commit();

                }else if (position==12) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Thirteen_Fragment_TwentyFour()).addToBackStack(null).commit();

                }else if (position==13) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Fourteen_Fragment_TwentyFour()).addToBackStack(null).commit();

                }else if (position==14) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Fifteen_Fragment_TwentyFour()).addToBackStack(null).commit();

                }else if (position==15) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Sixteen_Fragment_TwentyFour()).addToBackStack(null).commit();

                }else if (position==16) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Seventeen_Fragment_TwentyFour()).addToBackStack(null).commit();

                }else if (position==17) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Eighteen_Fragment_TwentyFour()).addToBackStack(null).commit();

                }else  {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Nineteen_Fragment_TwentyFour()).addToBackStack(null).commit();

                }


            });


        }

        @Override
        public int getItemCount() {
            return 19;
        }
    }
}