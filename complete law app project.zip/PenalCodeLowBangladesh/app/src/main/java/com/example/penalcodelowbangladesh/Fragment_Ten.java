package com.example.penalcodelowbangladesh;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;


public class Fragment_Ten extends Fragment {
   private RecyclerView recyclerViewTen;
   private ArrayList<datamodel_One> dataholder_ten = new ArrayList<>();
    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View myView = inflater.inflate(R.layout.fragment__ten, container, false);
        recyclerViewTen = myView.findViewById(R.id.recyclerViewTen);
        recyclerViewTen.setLayoutManager(new LinearLayoutManager(getContext()));

        datamodel_One ob1 = new datamodel_One("ধারাঃ ১৪১","বেআইনী সমাবেশ");
        dataholder_ten.add(ob1);
        datamodel_One ob2 = new datamodel_One("ধারাঃ ১৪২","বেআইনী সমাবেশের সদস্য হওয়া");
        dataholder_ten.add(ob2);
        datamodel_One ob3 = new datamodel_One("ধারাঃ ১৪৩"," বেআইনী সমাবেশের সদস্য হওয়ার শাস্তি");
        dataholder_ten.add(ob3);
        datamodel_One ob4 = new datamodel_One("ধারাঃ ১৪৪","কোন মারাত্মক অস্ত্রসহ বেআইনি সমাবেশে যোগদান করা");
        dataholder_ten.add(ob4);
        datamodel_One ob5 = new datamodel_One("ধারাঃ ১৪৫"," কোন বেআইনী সমাবেশ ভঙ্গ করিবার নির্দেশ দেওয়া হইয়াছে জানিয়াও উহাতে যোগদান করা বা উহাতে অবস্থান করা");
        dataholder_ten.add(ob5);
        datamodel_One ob6 = new datamodel_One("ধারাঃ ১৪৬"," দাঙ্গা");
        dataholder_ten.add(ob6);
        datamodel_One ob7 = new datamodel_One("ধারাঃ ১৪৭","দাঙ্গার শাস্তি");
        dataholder_ten.add(ob7);
        datamodel_One ob8 = new datamodel_One("ধারাঃ ১৪৮","মারাত্মক অস্ত্রে সজ্জিত হইয়া দাঙ্গা অনুষ্ঠানকরণ");
        dataholder_ten.add(ob8);
        datamodel_One ob9 = new datamodel_One("ধারাঃ ১৪৯","সাধারণ উদ্দেশ্যের বাস্তবায়নে অনুষ্ঠিত অপরাধের জন্য বেআইনী সমাবেশের প্রত্যেক সদস্য দোষী");
        dataholder_ten.add(ob9);
        datamodel_One ob10 = new datamodel_One("ধারাঃ ১৫০","বেআইনী সমাবেশে অংশগ্রহণের জন্য লোক ভাড়া করা বা নিয়োগ করা");
        dataholder_ten.add(ob10);

        datamodel_One ob11 = new datamodel_One("ধারাঃ ১৫১","ছত্রভঙ্গ হওয়ার আদেশের জ্ঞাতসারে পাঁচ বা ততোধিক ব্যক্তির সমাবেশে যোগদান করা বা থাকিয়া যাওয়া");
        dataholder_ten.add(ob11);
        datamodel_One ob12 = new datamodel_One("ধারাঃ ১৫২","দাঙ্গা দমনকারী সরকারী কর্মচারীকে আক্রমন করা বা বাধা দেওয়া");
        dataholder_ten.add(ob12);
        datamodel_One ob13 = new datamodel_One("ধারাঃ ১৫৩","দাঙ্গার কারণ ঘটানোর উদ্দেশ্যে উসকানি দেওয়া");
        dataholder_ten.add(ob13);
        datamodel_One ob14 = new datamodel_One("ধারাঃ ১৫৩-ক","বিভিন্ন শ্রেণীর মধ্যে শত্রুতা বর্ধন করা");
        dataholder_ten.add(ob14);
        datamodel_One ob15 = new datamodel_One("ধারাঃ ১৫৩-খ","রাজনৈতিক কার্যকলাপে অংশগ্রহনের জন্য ছাত্রগণকে প্ররোচিত করা");
        dataholder_ten.add(ob15);
        datamodel_One ob16 = new datamodel_One("ধারাঃ ১৫৪","জমির মালিক বা দখলদার কর্তৃক দাঙ্গা প্রভৃতির খবর না দেওয়া");
        dataholder_ten.add(ob16);
        datamodel_One ob17 = new datamodel_One("ধারাঃ ১৫৫","যে ব্যক্তির উপকারার্থে দাঙ্গা অনুষ্ঠিত হয় তাহার দায়িত্ব");
        dataholder_ten.add(ob17);
        datamodel_One ob18 = new datamodel_One("ধারাঃ ১৫৬","যে ব্যক্তির লাভের জন্য দাঙ্গা হয় সেই মালিক বা দখলকারের প্রতিনিধি কর্তৃক উহা প্রতিরোধের সঙ্গত ব্যবস্থা গ্রহণ না করা");
        dataholder_ten.add(ob18);
        datamodel_One ob19 = new datamodel_One("ধারাঃ ১৫৭"," বেআইনী সমাবেশের জন্য ভাড়া করা লোকদের আশ্রয় দেয়া");
        dataholder_ten.add(ob19);
        datamodel_One ob20 = new datamodel_One("ধারাঃ ১৫৮","বেআইনী সমাবেশ বা দাঙ্গায় অংশগ্রহণের জন্য ভাড়াটিয়া হইয়া যাওয়া");
        dataholder_ten.add(ob20);
        datamodel_One ob21 = new datamodel_One("ধারাঃ ১৫৯","মারামারি");
        dataholder_ten.add(ob21);
        datamodel_One ob22 = new datamodel_One("ধারাঃ ১৬০","মারামারির শাস্তি");
        dataholder_ten.add(ob22);

      MyAdpater_Ten myAdpater_ten = new MyAdpater_Ten(dataholder_ten);
      recyclerViewTen.setAdapter(myAdpater_ten);

        return myView;
    }
}