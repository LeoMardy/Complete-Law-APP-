package com.example.penalcodelowbangladesh;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;


public class Fragment_Eight extends Fragment {
    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View viedw = inflater.inflate(R.layout.fragment__eight, container, false);
        RecyclerView recyclerView = viedw.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        ArrayList<datamodel_One> dataholder_Eight = new ArrayList<>();

        datamodel_One obj1 = new datamodel_One("ধারাঃ ১২১","বাংলাদেশের বিরুদ্ধে যুদ্ধ ঘোষণা বা যুদ্ধ ঘোষণার উদ্যোগ করা বা যুদ্ধ ঘোষণার সহায়তা করা");
        dataholder_Eight.add(obj1);
        datamodel_One obj2 = new datamodel_One("ধারাঃ ১২১-ক","১২১ ধারাবলে দন্ডনীয় অপরাধ সমূহ অনুষ্ঠানের ষড়যন্ত্র");
        dataholder_Eight.add(obj2);
        datamodel_One obj3 = new datamodel_One("ধারাঃ ১২২","বাংলাদেশের বিরুদ্ধে যুদ্ধ করিবার উদ্দেশ্যে অস্ত্রশস্ত্র প্রভৃতি সংগ্রহ করণ");
        dataholder_Eight.add(obj3);
        datamodel_One obj4 = new datamodel_One("ধারাঃ ১২৩","যুদ্ধ সুগম করিবার অভিপ্রায়ে ষড়যন্ত্র গোপনকরণ");
        dataholder_Eight.add(obj4);
        datamodel_One obj5 = new datamodel_One("ধারাঃ ১২৩-ক","রাষ্ট্র সৃষ্টি নিন্দাকরণ ও উহার সার্বভৌমত্বের বিলোপ সমর্থন করা");
        dataholder_Eight.add(obj5);
        datamodel_One obj6 = new datamodel_One("ধারাঃ ১২৪","কোন আইনসংগত ক্ষমতা প্রয়োগে বাধ্য করা বা বাধা দেওয়ার উদ্দেশ্যে প্রেসিডেন্ট, গভর্নর প্রভৃতিকে আক্রমনকরণ");
        dataholder_Eight.add(obj6);
        datamodel_One obj7 = new datamodel_One("ধারা ১২৪ক","রাষ্ট্রদ্রোহ");
        dataholder_Eight.add(obj7);
        datamodel_One obj8 = new datamodel_One("ধারাঃ ১২৫","বাংলাদেশের মিত্র বা বাংলাদেশের সহিত শান্তিতে বসবাসকারী কোন এশীয় শক্তির সহিত যুদ্ধ করা বা যুদ্ধের প্ররোচনা দেওয়া");
        dataholder_Eight.add(obj8);
        datamodel_One obj9 = new datamodel_One("ধারাঃ ১২৬","বাংলাদেশের সহিত মিত্রতায় বা শান্তিতে বসবাসকারী কোন দেশের এলাকায় লুটতরাজ করা");
        dataholder_Eight.add(obj9);
        datamodel_One obj10 = new datamodel_One("ধারাঃ ১২৭","ধারা ১২৫ ও ১২৬ এ উল্লিখিত যুদ্ধ বা লুটতরাজ দ্বারা সংগৃহীত সম্পত্তি গ্রহণ করা");
        dataholder_Eight.add(obj10);
        datamodel_One obj11 = new datamodel_One("ধারাঃ ১২৮","সরকারী কর্মচারী কর্তৃক সেচ্ছায় নিজের হেফাজত হইতে রাষ্ট্রীয় বন্দী বা যুদ্ধবন্দীকে পলায়ন করিতে দেওয়া");
        dataholder_Eight.add(obj11);
        datamodel_One obj12 = new datamodel_One("ধারাঃ ১২৯","সরকারী কর্মচারী কর্তৃক অবহেলাবশতঃ নিজের হেফাজত হইতে রাষ্ট্রীয় বন্দী বা যুদ্ধবন্দীকে পলায়ন করিতে দেওয়া");
        dataholder_Eight.add(obj12);
        datamodel_One obj13 = new datamodel_One("ধারা ১৩০","উক্তরূপে বন্দীর পলায়নে সহায়তা করা বা তাহাকে উদ্ধার করা বা আশ্রয় দেওয়া অথবা তাহার পুনঃ গ্রেফতারে বাধা দেওয়া");
        dataholder_Eight.add(obj13);

        MyAdpater_Eight myAdpater_eight = new MyAdpater_Eight(dataholder_Eight);
        recyclerView.setAdapter(myAdpater_eight);
        return viedw;
    }
}