package com.example.penalcodelowbangladesh;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textview.MaterialTextView;

import java.util.ArrayList;


public class Fragment_ThirtySeven extends Fragment {

    RecyclerView recyclerView_37;
    ArrayList<datamodel_One> dataholder_37 = new ArrayList<>();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment__thirty_seven, container, false);
        recyclerView_37 = view.findViewById(R.id.recyclerView_37);
        recyclerView_37.setLayoutManager(new LinearLayoutManager(getContext()));

        datamodel_One k1 = new datamodel_One("ধারাঃ ৪৬৩","জালিয়াতি");
        dataholder_37.add(k1);
        datamodel_One k2 = new datamodel_One("ধারাঃ ৪৬৪","মিথ্যা দলিল প্রণয়ন");
        dataholder_37.add(k2);
        datamodel_One k3 = new datamodel_One("ধারাঃ ৪৬৫","জালিয়াতির শাস্তি");
        dataholder_37.add(k3);
        datamodel_One k4 = new datamodel_One("ধারাঃ ৪৬৬","আদালতের নথিপত্র বা সরকারী রেজিস্টার ইত্যাদি জালকরণ");
        dataholder_37.add(k4);
        datamodel_One k5 = new datamodel_One("ধারাঃ ৪৬৭","মূল্যবান জামানত, উইল ইত্যাদি জালকরণ");
        dataholder_37.add(k5);
        datamodel_One k6 = new datamodel_One("ধারাঃ ৪৬৮","প্রতারণা করিবার উদ্দেশ্যে জালিয়াতি");
        dataholder_37.add(k6);
        datamodel_One k7 = new datamodel_One("ধারাঃ ৪৬৯"," মানহানির উদ্দেশ্যে জালিয়াতি");
        dataholder_37.add(k7);
        datamodel_One k8 = new datamodel_One("ধারাঃ ৪৭০","জাল দলিল");
        dataholder_37.add(k8);
        datamodel_One k9 = new datamodel_One("ধারাঃ ৪৭১","কোন জাল দলিলকে খাটিঁ হিসাবে ব্যবহারকরণ");
        dataholder_37.add(k9);
        datamodel_One k10 = new datamodel_One("ধারাঃ ৪৭২","ধারা ৪৬৭ এ অধীনে দন্ডনীয় জালিয়াতি করিবার উদ্দেশ্যে মেকি মোহর ইত্যাদি নির্মাণ বা দখল");
        dataholder_37.add(k10);
        datamodel_One k11 = new datamodel_One("ধারাঃ ৪৭৩","প্রকারান্তরে দন্ডনীয় জালিয়াতি অনুষ্ঠানের উদ্দেশ্যে মেকি সীলমোহর ইত্যাদি নিমার্ণ বা দখল");
        dataholder_37.add(k11);
        datamodel_One k12 = new datamodel_One("ধারাঃ ৪৭৪","ধারা ৪৬৬ বা ৪৬৭ এ বর্ণিত দলিল, উহা জাল বলিয়া জানিয়া এবং উহা খাটিঁ বলিয়া ব্যবহার করিবার ইচ্ছা করিয়া দখল");
        dataholder_37.add(k12);
        datamodel_One k13 = new datamodel_One("ধারাঃ ৪৭৫","ধারা ৪৬৭ এ বর্ণিত দলিলসমূহ প্রমাণীকৃত করিবার জন্য ব্যবহৃত নক্শা বা চিহ্ন নকলকরণ বা মেকি চিহ্নিত দ্রব্য দখল");
        dataholder_37.add(k13);
        datamodel_One k14 = new datamodel_One("ধারাঃ ৪৭৬","ধারা ৪৬৭ এ বর্ণিত দলিলাদি হইতে ভিন্ন দলিলাদি প্রমাণীকৃত করিবার জন্য ব্যবহৃত নক্শা বা চিহ্নাদি নকলকরণ অথবা মেকি চিহ্ন সম্বলিত দ্রব্য দখল");
        dataholder_37.add(k14);
        datamodel_One k15 = new datamodel_One("ধারাঃ ৪৭৭","উইল দত্তক গ্রহণের অনুমতিপত্র বা কোন মূল্যবান জামানত প্রতারণামূলকভাবে বাতিলকরণ বা বিনষ্টকরণ ইত্যাদি");
        dataholder_37.add(k15);
        datamodel_One k16 = new datamodel_One("ধারাঃ ৪৭৭-ক","হিসাবপত্র বিকৃতকরণ");
        dataholder_37.add(k16);



MyAdapter_37 myAdapter_37 = new MyAdapter_37(dataholder_37);
recyclerView_37.setAdapter(myAdapter_37);

        return view;
    }


    public static class MyAdapter_37 extends RecyclerView.Adapter<MyAdapter_37.MyViewHolder_37>
    {
        protected static class MyViewHolder_37 extends RecyclerView.ViewHolder
        {

            MaterialCardView materialCardView_37;
            MaterialTextView materialTextView_Header_37, materialTextView_Desc_37 ;



            public MyViewHolder_37(@NonNull View itemView)
            {
                super(itemView);

                materialCardView_37= itemView.findViewById(R.id.recycler_CardView);
                materialTextView_Desc_37 = itemView.findViewById(R.id.recycler_TextViewDesc);
                materialTextView_Header_37 = itemView.findViewById(R.id.recycler_TextViewHeader);

            }
        }

        ArrayList<datamodel_One> dataholder_37;

        public MyAdapter_37(ArrayList<datamodel_One> dataholder_37) {
            this.dataholder_37 = dataholder_37;
        }

        @NonNull
        @Override
        public MyViewHolder_37 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_xml_design_one,parent,false);

            return new MyViewHolder_37(view);
        }

        @Override
        public void onBindViewHolder(@NonNull MyViewHolder_37 holder, int position) {

            holder.materialTextView_Header_37.setText(dataholder_37.get(position).getHeader());
            holder.materialTextView_Desc_37.setText(dataholder_37.get(position).getDesc());
            holder.materialCardView_37.setOnClickListener(v -> {

                if (position == 0) {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_One_Fragment_ThirtySeven()).addToBackStack(null).commit();


                } else if (position==1) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Two_Fragment_ThirtySeven()).addToBackStack(null).commit();

                }else if (position==2) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Three_Fragment_ThirtySeven()).addToBackStack(null).commit();

                }else if (position==3) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Four_Fragment_ThirtySeven()).addToBackStack(null).commit();

                }else if (position==4) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Five_Fragment_ThirtySeven()).addToBackStack(null).commit();

                }else if (position==5) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Six_Fragment_ThirtySeven()).addToBackStack(null).commit();

                }else if (position==6) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Seven_Fragment_ThirtySeven()).addToBackStack(null).commit();

                }else if (position==7) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Eight_Fragment_ThirtySeven()).addToBackStack(null).commit();

                }else if (position==8) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Nine_Fragment_ThirtySeven()).addToBackStack(null).commit();

                }else if (position==9) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Ten_Fragment_ThirtySeven()).addToBackStack(null).commit();

                }else if (position==10) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Eleven_Fragment_ThirtySeven()).addToBackStack(null).commit();

                }else if (position==11) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Twelve_Fragment_ThirtySeven()).addToBackStack(null).commit();

                }else if (position==12) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Thirteen_Fragment_ThirtySeven()).addToBackStack(null).commit();

                }else if (position==13) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Fourteen_Fragment_ThirtySeven()).addToBackStack(null).commit();

                }else if (position==14) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Fifteen_Fragment_ThirtySeven()).addToBackStack(null).commit();

                }else  {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Sixteen_Fragment_ThirtySeven()).addToBackStack(null).commit();

                }

            });
        }

        @Override
        public int getItemCount() {
            return 16;
        }
    }
}