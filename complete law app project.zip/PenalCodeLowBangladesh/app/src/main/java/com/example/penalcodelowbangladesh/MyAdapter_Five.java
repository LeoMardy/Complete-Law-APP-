package com.example.penalcodelowbangladesh;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textview.MaterialTextView;

import java.util.ArrayList;

public class MyAdapter_Five extends RecyclerView.Adapter<MyAdapter_Five.MyViewHolder> {
    public static class MyViewHolder extends RecyclerView.ViewHolder{
      final private MaterialTextView recycler_TextViewHeader,recycler_TextViewDesc;
      final private MaterialCardView materialCardView;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            materialCardView = itemView.findViewById(R.id.recycler_CardView);
             recycler_TextViewHeader = itemView.findViewById(R.id.recycler_TextViewHeader);
             recycler_TextViewDesc = itemView.findViewById(R.id.recycler_TextViewDesc);
        }
    }
    ArrayList<datamodel_One> dataholder_Five;

    public MyAdapter_Five(ArrayList<datamodel_One> dataholder_Five) {
        this.dataholder_Five = dataholder_Five;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View myView = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_xml_design_one,parent,false);
        return new MyViewHolder(myView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") int position) {
        holder.recycler_TextViewHeader.setText(dataholder_Five.get(position).getHeader());
        holder.recycler_TextViewDesc.setText(dataholder_Five.get(position).getDesc());
        holder.materialCardView.setOnClickListener(v -> {
            switch (position){
                case 0:
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_One_Fragment_Five()).addToBackStack(null).commit();
                    break;
                case 1:
                    AppCompatActivity activity1 = (AppCompatActivity) v.getContext();
                    activity1.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_two_Fragment_Five()).addToBackStack(null).commit();
                    break;
                case 2:
                    AppCompatActivity activity2 = (AppCompatActivity) v.getContext();
                    activity2.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_three_Fragment_Five()).addToBackStack(null).commit();
                    break;
                case 3:
                    AppCompatActivity activity3 = (AppCompatActivity) v.getContext();
                    activity3.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_four_Fragment_Five()).addToBackStack(null).commit();
                    break;
                case 4:
                    AppCompatActivity activity4 = (AppCompatActivity) v.getContext();
                    activity4.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_five_Fragment_Five()).addToBackStack(null).commit();
                    break;
                case 5:
                    AppCompatActivity activity5 = (AppCompatActivity) v.getContext();
                    activity5.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_six_Fragment_Five()).addToBackStack(null).commit();
                    break;
                case 6:
                    AppCompatActivity activity6 = (AppCompatActivity) v.getContext();
                    activity6.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_seven_Fragment_Five()).addToBackStack(null).commit();
                    break;
                case 7:
                    AppCompatActivity activity7 = (AppCompatActivity) v.getContext();
                    activity7.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_eight_Fragment_Five()).addToBackStack(null).commit();
                    break;
                case 8:
                    AppCompatActivity activity8 = (AppCompatActivity) v.getContext();
                    activity8.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_nine_Fragment_Five()).addToBackStack(null).commit();
                    break;
                case 9:
                    AppCompatActivity activity9 = (AppCompatActivity) v.getContext();
                    activity9.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_ten_Fragment_Five()).addToBackStack(null).commit();
                    break;
                case 10:
                    AppCompatActivity activity10 = (AppCompatActivity) v.getContext();
                    activity10.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_eleven_Fragment_Five()).addToBackStack(null).commit();
                    break;

            }
        });
    }

    @Override
    public int getItemCount() {
        return 11;
    }
}
