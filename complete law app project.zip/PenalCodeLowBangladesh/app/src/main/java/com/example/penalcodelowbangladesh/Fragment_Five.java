package com.example.penalcodelowbangladesh;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

public class Fragment_Five extends Fragment {
    private RecyclerView recyclerView;
    private ArrayList<datamodel_One> dataholder_Five = new ArrayList<>();
    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View myView =  inflater.inflate(R.layout.fragment__five, container, false);
        recyclerView = myView.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        datamodel_One ob1 = new datamodel_One("ধারাঃ ৯৬","ব্যক্তিগত আত্নরক্ষার কৃত বিষয়সমূহ");
        dataholder_Five.add(ob1);
        datamodel_One ob2 = new datamodel_One("ধারাঃ ৯৭","শরীর ও সম্পত্তি সম্পর্কিত ব্যক্তিগত অধিকার");
        dataholder_Five.add(ob2);
        datamodel_One ob3 = new datamodel_One("ধারাঃ ৯৮","অপ্রকৃতিস্থ ইত্যাদি ব্যক্তির কার্যের বিরুদ্ধে ব্যক্তিগত আত্নরক্ষার অধিকার");
        dataholder_Five.add(ob3);
        datamodel_One ob4 = new datamodel_One("ধারাঃ ৯৯","যেসব কর্যের বিরুদ্ধে ব্যক্তিগত আত্নরক্ষার অধিকার নাই");
        dataholder_Five.add(ob4);
        datamodel_One ob5 = new datamodel_One("ধারাঃ ১০০","যেক্ষেত্রে দেহের ব্যক্তিগত আত্নরক্ষার অধিকার মৃত্যু ঘটাইবার ক্ষেত্রেও প্রযোজ্য হয়");
        dataholder_Five.add(ob5);
        datamodel_One ob6 = new datamodel_One("ধারাঃ ১০১"," যেক্ষেত্রে অনুরূপ অধিকার মৃত্যু ব্যতীত অন্য যেকোন ক্ষতির প্রতি প্রযোজ্য হয়");
        dataholder_Five.add(ob6);
        datamodel_One ob7 = new datamodel_One("ধারাঃ ১০২","দেহের ব্যক্তিগত আত্নরক্ষার অধিকারের আরম্ভ ও স্থিতিকাল");
        dataholder_Five.add(ob7);
        datamodel_One ob8 = new datamodel_One("ধারাঃ ১০৩","যেক্ষেত্রে সম্পত্তি সম্পর্কিত ব্যক্তিগত আত্নরক্ষার অধিকার মৃত্যু ঘটাইবার ক্ষেত্রেও প্রযোজ্য হয়");
        dataholder_Five.add(ob8);
        datamodel_One ob9 = new datamodel_One("ধারাঃ ১০৪","যে ক্ষেত্রে অনুরূপ অধিকার মৃত্যু ব্যতীত অন্য কোন ক্ষতি সাধনের প্রতি প্রযোজ্য হয়");
        dataholder_Five.add(ob9);
        datamodel_One ob10 = new datamodel_One("ধারাঃ ১০৫"," সম্পত্তি সম্পর্কিত ব্যক্তিগত আত্নরক্ষার অধিকারের আরম্ভ ও স্থিতিকাল");
        dataholder_Five.add(ob10);
        datamodel_One ob11 = new datamodel_One("ধারাঃ ১০৬","নিরপরাধ ব্যক্তির প্রতি ক্ষতিসাধিত ইবার সম্ভাবনার ক্ষেত্রে মারাত্নক আক্রমণের বিরুদ্ধে ব্যক্তিগত আত্নরক্ষার অধিকার");
        dataholder_Five.add(ob11);

       MyAdapter_Five myAdapter_five = new MyAdapter_Five(dataholder_Five);
       recyclerView.setAdapter(myAdapter_five);
        return myView;
    }
}