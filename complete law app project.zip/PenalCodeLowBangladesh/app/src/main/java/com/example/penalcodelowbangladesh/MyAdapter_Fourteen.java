package com.example.penalcodelowbangladesh;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textview.MaterialTextView;

import java.util.ArrayList;

public  class MyAdapter_Fourteen extends RecyclerView.Adapter<MyAdapter_Fourteen.MyViewHolder_Fourteen> {
    final protected static class MyViewHolder_Fourteen extends RecyclerView.ViewHolder{
  final private MaterialTextView recyclerTextViewHeaderID, recyclerTextViewDescID;
    final private MaterialCardView recyclerCardViewID;
        public MyViewHolder_Fourteen(@NonNull View itemView) {
            super(itemView);
            recyclerTextViewHeaderID = itemView.findViewById(R.id.recycler_TextViewHeader);
            recyclerTextViewDescID = itemView.findViewById(R.id.recycler_TextViewDesc);
            recyclerCardViewID = itemView.findViewById(R.id.recycler_CardView);
        }
    }
    final private ArrayList<datamodel_One> dataholder_fourteen;

    public MyAdapter_Fourteen(ArrayList<datamodel_One> dataholder_fourteen) {
        this.dataholder_fourteen = dataholder_fourteen;
    }

    @NonNull
    @Override
    public MyViewHolder_Fourteen onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_xml_design_one,parent,false);
        return new MyViewHolder_Fourteen(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder_Fourteen holder, int position) {
  holder.recyclerTextViewHeaderID.setText(dataholder_fourteen.get(position).getHeader());
  holder.recyclerTextViewDescID.setText(dataholder_fourteen.get(position).getDesc());
  holder.recyclerCardViewID.setOnClickListener(v -> {
      switch (position){
          case 0:
              AppCompatActivity activity = (AppCompatActivity) v.getContext();
              activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_One_Fragment_Fourteen()).addToBackStack(null).commit();
              break;
          case 1:
              AppCompatActivity activity1 = (AppCompatActivity) v.getContext();
              activity1.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_two_Fragment_Fourteen()).addToBackStack(null).commit();
              break;
          case 2:
              AppCompatActivity activity2 = (AppCompatActivity) v.getContext();
              activity2.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_three_Fragment_Fourteen()).addToBackStack(null).commit();
              break;
          case 3:
              AppCompatActivity activity3 = (AppCompatActivity) v.getContext();
              activity3.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_four_Fragment_Fourteen()).addToBackStack(null).commit();
              break;
          case 4:
              AppCompatActivity activity4 = (AppCompatActivity) v.getContext();
              activity4.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_five_Fragment_Fourteen()).addToBackStack(null).commit();
              break;
          case 5:
              AppCompatActivity activity5 = (AppCompatActivity) v.getContext();
              activity5.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_six_Fragment_Fourteen()).addToBackStack(null).commit();
              break;
          case 6:
              AppCompatActivity activity6 = (AppCompatActivity) v.getContext();
              activity6.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_seven_Fragment_Fourteen()).addToBackStack(null).commit();
              break;
          case 7:
              AppCompatActivity activity7 = (AppCompatActivity) v.getContext();
              activity7.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_eight_Fragment_Fourteen()).addToBackStack(null).commit();
              break;
          case 8:
              AppCompatActivity activity8 = (AppCompatActivity) v.getContext();
              activity8.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_nine_Fragment_Fourteen()).addToBackStack(null).commit();
              break;
          case 9:
              AppCompatActivity activity9 = (AppCompatActivity) v.getContext();
              activity9.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_ten_Fragment_Fourteen()).addToBackStack(null).commit();
              break;
          case 10:
              AppCompatActivity activity10 = (AppCompatActivity) v.getContext();
              activity10.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_eleven_Fragment_Fourteen()).addToBackStack(null).commit();
              break;
          case 11:
              AppCompatActivity activity11 = (AppCompatActivity) v.getContext();
              activity11.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_twelve_Fragment_Fourteen()).addToBackStack(null).commit();
              break;
          case 12:
              AppCompatActivity activity12 = (AppCompatActivity) v.getContext();
              activity12.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_thirteen_Fragment_Fourteen()).addToBackStack(null).commit();
              break;
          case 13:
              AppCompatActivity activity13 = (AppCompatActivity) v.getContext();
              activity13.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_fourteen_Fragment_Fourteen()).addToBackStack(null).commit();
              break;
          case 14:
              AppCompatActivity activity14 = (AppCompatActivity) v.getContext();
              activity14.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_fifteen_Fragment_Fourteen()).addToBackStack(null).commit();
              break;
          case 15:
              AppCompatActivity activity15 = (AppCompatActivity) v.getContext();
              activity15.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_sixteen_Fragment_Fourteen()).addToBackStack(null).commit();
              break;
          case 16:
              AppCompatActivity activity16 = (AppCompatActivity) v.getContext();
              activity16.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_seventeen_Fragment_Fourteen()).addToBackStack(null).commit();
              break;
          case 17:
              AppCompatActivity activity17 = (AppCompatActivity) v.getContext();
              activity17.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_eighteen_Fragment_Fourteen()).addToBackStack(null).commit();
              break;
          case 18:
              AppCompatActivity activity18 = (AppCompatActivity) v.getContext();
              activity18.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_nineteen_Fragment_Fourteen()).addToBackStack(null).commit();
              break;
          case 19:
              AppCompatActivity activity19 = (AppCompatActivity) v.getContext();
              activity19.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_twenty_Fragment_Fourteen()).addToBackStack(null).commit();
              break;
          case 20:
              AppCompatActivity activity20 = (AppCompatActivity) v.getContext();
              activity20.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_twentyOne_Fragment_Fourteen()).addToBackStack(null).commit();
              break;
          case 21:
              AppCompatActivity activity21 = (AppCompatActivity) v.getContext();
              activity21.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_twentyThree_Fragment_Fourteen()).addToBackStack(null).commit();
              break;
          case 22:
              AppCompatActivity activity22 = (AppCompatActivity) v.getContext();
              activity22.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_twentyfour_Fragment_Fourteen()).addToBackStack(null).commit();
              break;
          case 23:
              AppCompatActivity activity23 = (AppCompatActivity) v.getContext();
              activity23.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_twentyfive_Fragment_Fourteen()).addToBackStack(null).commit();
              break;
              case 24:
              AppCompatActivity activity24 = (AppCompatActivity) v.getContext();
              activity24.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_twentysix_Fragment_Fourteen()).addToBackStack(null).commit();
              break;
          case 25:
              AppCompatActivity activity25 = (AppCompatActivity) v.getContext();
              activity25.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_twentyseven_Fragment_Fourteen()).addToBackStack(null).commit();
              break;
          case 26:
              AppCompatActivity activity26 = (AppCompatActivity) v.getContext();
              activity26.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_twentyeight_Fragment_Fourteen()).addToBackStack(null).commit();
              break;
          case 27:
              AppCompatActivity activity27 = (AppCompatActivity) v.getContext();
              activity27.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_twentynine_Fragment_Fourteen()).addToBackStack(null).commit();
              break;
          case 28:
              AppCompatActivity activity28 = (AppCompatActivity) v.getContext();
              activity28.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_thirty_Fragment_Fourteen()).addToBackStack(null).commit();
              break;
          case 29:
              AppCompatActivity activity29 = (AppCompatActivity) v.getContext();
              activity29.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_thirtyOne_Fragment_Fourteen()).addToBackStack(null).commit();
              break;
          case 30:
              AppCompatActivity activity30 = (AppCompatActivity) v.getContext();
              activity30.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_thirtyTwo_Fragment_Fourteen()).addToBackStack(null).commit();
              break;
          case 31:
              AppCompatActivity activity31= (AppCompatActivity) v.getContext();
              activity31.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_thirtyThree_Fragment_Fourteen()).addToBackStack(null).commit();
              break;
          case 32:
              AppCompatActivity activity32 = (AppCompatActivity) v.getContext();
              activity32.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_thirtyFour_Fragment_Fourteen()).addToBackStack(null).commit();
              break;
          case 33:
              AppCompatActivity activity33 = (AppCompatActivity) v.getContext();
              activity33.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_thirtyFive_Fragment_Fourteen()).addToBackStack(null).commit();
              break;
          case 34:
              AppCompatActivity activity34 = (AppCompatActivity) v.getContext();
              activity34.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_thirtySix_Fragment_Fourteen()).addToBackStack(null).commit();
              break;
          case 35:
              AppCompatActivity activity35 = (AppCompatActivity) v.getContext();
              activity35.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_thirtySeven_Fragment_Fourteen()).addToBackStack(null).commit();
              break;
          case 36:
              AppCompatActivity activity36 = (AppCompatActivity) v.getContext();
              activity36.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_thirtyEight_Fragment_Fourteen()).addToBackStack(null).commit();
              break;
          case 37:
              AppCompatActivity activity37 = (AppCompatActivity) v.getContext();
              activity37.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_thirtyNine_Fragment_Fourteen()).addToBackStack(null).commit();
              break;
          case 38:
              Toast.makeText(v.getContext(), "বাতিল!", Toast.LENGTH_SHORT).show();
              break;
          case 39:
              AppCompatActivity activity39 = (AppCompatActivity) v.getContext();
              activity39.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Fourty_Fragment_Fourteen()).addToBackStack(null).commit();
              break;
          case 40:
              AppCompatActivity activity40 = (AppCompatActivity) v.getContext();
              activity40.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_FourtyOne_Fragment_Fourteen()).addToBackStack(null).commit();
              break;
          default:
              AppCompatActivity activity41 = (AppCompatActivity) v.getContext();
              activity41.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_FourtyTwo_Fragment_Fourteen()).addToBackStack(null).commit();
              break;

      }


  });

    }

    @Override
    public int getItemCount() {
        return 42;
    }
}
