package com.example.penalcodelowbangladesh;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

public class Fragment_Two extends Fragment {
    private RecyclerView recyclerView;
    private ArrayList<datamodel_One> dataholder_two = new ArrayList<>();

    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View myView =  inflater.inflate(R.layout.fragment__two, container, false);
        recyclerView = myView.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        datamodel_One ob1 = new datamodel_One("ধারা-৬","এই আইনের সংজ্ঞাগুলোর অর্থ ব্যতিত্রুমসমূহ সাপেক্ষে হবে");
        dataholder_two.add(ob1);
        datamodel_One ob2 = new datamodel_One("ধারা-৭","একবার ব্যাখ্যাকৃত অভিব্যক্তির তাৎপর্য");
        dataholder_two.add(ob2);
        datamodel_One ob3 = new datamodel_One("ধারা-৮","লিঙ্গ");
        dataholder_two.add(ob3);
        datamodel_One ob4 = new datamodel_One("ধারা-৯","বচন");
        dataholder_two.add(ob4);
        datamodel_One ob5 = new datamodel_One("ধারা-১০","নর-নারী");
        dataholder_two.add(ob5);
        datamodel_One ob6 = new datamodel_One("ধারা-১১","ব্যক্তি");
        dataholder_two.add(ob6);
        datamodel_One ob7 = new datamodel_One("ধারা-১২","জনসাধারণ");
        dataholder_two.add(ob7);
        datamodel_One ob8 = new datamodel_One("ধারা-১৩","বাতিল");
        dataholder_two.add(ob8);
        datamodel_One ob9 = new datamodel_One("ধারা-১৪","রাষ্ট্রের কর্মচারী");
        dataholder_two.add(ob9);
        datamodel_One ob10 = new datamodel_One("ধারা-১৫,১৬ বাতিল"," ");
        dataholder_two.add(ob10);

        datamodel_One ob11 = new datamodel_One("ধারা-১৭","সরকার");
        dataholder_two.add(ob11);
        datamodel_One ob12 = new datamodel_One("ধারা-১৮","বাতিল");
        dataholder_two.add(ob12);
        datamodel_One ob13 = new datamodel_One("ধারা-১৯","বিচারক");
        dataholder_two.add(ob13);
        datamodel_One ob14 = new datamodel_One("ধারা-২০","বিচারালয় বা আদালত");
        dataholder_two.add(ob14);
        datamodel_One ob15 = new datamodel_One("ধারা-২১","সরকারী কর্মচারী");
        dataholder_two.add(ob15);
        datamodel_One ob16 = new datamodel_One("ধারা-২২","অস্থাবর সম্পত্তি");
        dataholder_two.add(ob16);
        datamodel_One ob17 = new datamodel_One("ধারা-২৩","অবৈধ লাভ");
        dataholder_two.add(ob17);
        datamodel_One ob18 = new datamodel_One("ধারা-২৪","অসাধু ভাবে");
        dataholder_two.add(ob18);
        datamodel_One ob19 = new datamodel_One("ধারা-২৫","প্রতারণা মূলক ভাবে");
        dataholder_two.add(ob19);
        datamodel_One ob20 = new datamodel_One("ধারা-২৬","বিশ্বাস করার কারণ");
        dataholder_two.add(ob20);

        datamodel_One ob21 = new datamodel_One("ধারা-২৭","স্ত্রী,কেরানী, অথবা চাকরের দখলাধীন সম্পত্তি");
        dataholder_two.add(ob21);
        datamodel_One ob22 = new datamodel_One("ধারা-২৮","নকল করা");
        dataholder_two.add(ob22);
        datamodel_One ob23 = new datamodel_One("ধারা-২৯","দলিল");
        dataholder_two.add(ob23);
        datamodel_One ob24 = new datamodel_One("ধারা-৩০","মূল্যবান জামানত");
        dataholder_two.add(ob24);
        datamodel_One ob25 = new datamodel_One("ধারা-৩১","একটি উইল");
        dataholder_two.add(ob25);
        datamodel_One ob26 = new datamodel_One("ধারা-৩২","কোনো কাজ সম্পর্কে ব্যবহৃত বক্তব্য বেআইনী গাফিলতি বা আকৃতি সম্পর্কেও প্রয়োগযোগ্য");
        dataholder_two.add(ob26);
        datamodel_One ob27 = new datamodel_One("ধারা-৩৩","কার্য বিচ্যুতি");
        dataholder_two.add(ob27);
        datamodel_One ob28 = new datamodel_One("ধারা-৩৪","একই উদ্দেশ্য পূরণকল্পে কতিপয় ব্যক্তি কর্তৃক কৃত কার্যাবলী");
        dataholder_two.add(ob28);
        datamodel_One ob29 = new datamodel_One("ধারা-৩৫","যখন অনুরূপ কাজ অপরাধমূলক জ্ঞানে বা অপরাধমূলক উদ্দেশ্য নিয়ে সম্পাদিত হওয়ার দরুণ অপরাধমূলক হবে");
        dataholder_two.add(ob29);
        datamodel_One ob30 = new datamodel_One("ধারা-৩৬","আংশিকভাবে কাজ এবং আংশিকভাবে বিচ্যুতির সাহায্যে ফলাফল");
        dataholder_two.add(ob30);

        datamodel_One ob41 = new datamodel_One("ধারা-৩৭","একটি অপরাধের সাথে জড়িত কার্যসমূহের মধ্যে কোন একটির সংঘটন দ্বারা সহযোগিতা");
        dataholder_two.add(ob41);
        datamodel_One ob42 = new datamodel_One("ধারা-৩৮","অপরাধমূলক কাজের সাথে জড়িত ব্যক্তিগণ বিভিন্ন অপরাধে অপরাধী সাব্যস্ত হতে পারে");
        dataholder_two.add(ob42);
        datamodel_One ob43 = new datamodel_One("ধারা-৩৯","স্বেচ্ছাকৃতভাবে");
        dataholder_two.add(ob43);
        datamodel_One ob44 = new datamodel_One("ধারা-৪০","অপরাধ");
        dataholder_two.add(ob44);
        datamodel_One ob45 = new datamodel_One("ধারা-৪১","বিশেষ আইন");
        dataholder_two.add(ob45);
        datamodel_One ob46 = new datamodel_One("ধারা-৪২","স্থানীয় আইন");
        dataholder_two.add(ob46);
        datamodel_One ob47 = new datamodel_One("ধারা-৪৩","বেআইনী আইনত সম্পাদন করতে বাধ্য");
        dataholder_two.add(ob47);
        datamodel_One ob48 = new datamodel_One("ধারা-৪৪","ক্ষতি");
        dataholder_two.add(ob48);
        datamodel_One ob49 = new datamodel_One("ধারা-৪৫","জীবন");
        dataholder_two.add(ob49);
        datamodel_One ob50 = new datamodel_One("ধারা-৪৬","মৃত্যু");
        dataholder_two.add(ob50);

        datamodel_One ob51 = new datamodel_One("ধারা-৪৭","প্রাণী");
        dataholder_two.add(ob51);
        datamodel_One ob52 = new datamodel_One("ধারা-৪৮","জাহাজ");
        dataholder_two.add(ob52);
        datamodel_One ob53 = new datamodel_One("ধারা-৪৯","বৎসর মাস");
        dataholder_two.add(ob53);
        datamodel_One ob54 = new datamodel_One("ধারা-৫০","ধারা");
        dataholder_two.add(ob54);
        datamodel_One ob55 = new datamodel_One("ধারা-৫১","শপথ");
        dataholder_two.add(ob55);
        datamodel_One ob56 = new datamodel_One("ধারা-৫২","সরল বিশ্বাস");
        dataholder_two.add(ob56);
        datamodel_One ob57 = new datamodel_One("ধারা-৫৩","আশ্রয়দান");
        dataholder_two.add(ob57);

        MyAdapter_two myAdapter_two = new MyAdapter_two(dataholder_two);
        recyclerView.setAdapter(myAdapter_two);
        return myView;
    }
}