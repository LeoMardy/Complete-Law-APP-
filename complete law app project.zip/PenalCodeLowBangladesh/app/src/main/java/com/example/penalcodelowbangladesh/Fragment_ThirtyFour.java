package com.example.penalcodelowbangladesh;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textview.MaterialTextView;

import java.util.ArrayList;


public class Fragment_ThirtyFour extends Fragment {

    RecyclerView recyclerView_34;
    ArrayList<datamodel_One> dataholder_34 = new ArrayList<>();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment__thirty_four, container, false);
        recyclerView_34 = view.findViewById(R.id.recyclerView_34);
        recyclerView_34.setLayoutManager(new LinearLayoutManager(getContext()));

       datamodel_One k1 = new datamodel_One("ধারাঃ ৪২৫","অনিষ্ট");
       dataholder_34.add(k1);
        datamodel_One k2 = new datamodel_One("ধারাঃ ৪২৬","অনিষ্টের শাস্তি");
        dataholder_34.add(k2);
        datamodel_One k3 = new datamodel_One("ধারাঃ ৪২৭","পঞ্চাশ টাকা পরিমাণ ক্ষতি করিয়া অনিষ্ট সাধন");
        dataholder_34.add(k3);
        datamodel_One k4 = new datamodel_One("ধারাঃ ৪২৮","দশ টাকা মূল্যের কোন জন্তু হত্যা বা বিকলাঙ্গ করিয়া অনিষ্ট সাধন");
        dataholder_34.add(k4);
        datamodel_One k5 = new datamodel_One("ধারাঃ ৪২৯","যেকোন মূল্যের গবাদিপশু ইত্যাদি বা পঞ্চাশ টাকা মূল্যের কোন জন্তু বিকলাঙ্গ করিয়া অনিষ্ট সাধন");
        dataholder_34.add(k5);
        datamodel_One k6 = new datamodel_One("ধারাঃ ৪৩০","কৃষি, সেচ, পূর্ত কার্যের ক্ষতি করিয়া বা অবৈধভাবে পানির  স্রোতের গতি পরিবর্তন করিয়া অনিষ্ট সাধন");
        dataholder_34.add(k6);
        datamodel_One k7 = new datamodel_One("ধারাঃ ৪৩১","সরকারী রাস্তা, পুল, নদী বা খালের ক্ষতি করিয়া অনিষ্ট সাধন");
        dataholder_34.add(k7);
        datamodel_One k8 = new datamodel_One("ধারাঃ ৪৩২","ক্ষতিসহকারে সরকারী পয়ঃপ্রণালীর প্লাবন, প্রতিবন্ধকতা সৃষ্টি করিয়া অনিষ্ট সাধন");
        dataholder_34.add(k8);

        datamodel_One k9 = new datamodel_One("ধারাঃ ৪৩৩","কোন বাতিঘর বা সমুদ্র-চিহ্ন ধ্বংস, স্থানান্তরিত বা অপেক্ষাকৃত কম কার্যকর পরিণত করিয়া অনিষ্ট সাধন");
        dataholder_34.add(k9);
        datamodel_One k10 = new datamodel_One("ধারাঃ ৪৩৪","সরকারী কর্তৃপক্ষ কর্তৃক নির্দিষ্টকৃত সীমা নির্দেশ চিহন ধ্বংস বা স্থানান্তর ইত্যাদির মাধ্যমে অনিষ্ট সাধন করা");
        dataholder_34.add(k10);
        datamodel_One k11 = new datamodel_One("ধারাঃ ৪৩৫","একশত টাকা বা কৃষিজ ফসলের ক্ষেত্রে দশ টাকা পরিমাণ ক্ষতি করিবার উদ্দেশ্যে অগ্নি বা কোন বিস্ফোরক দ্রব্যের সাহায্যে অনিষ্ট সাধন");
        dataholder_34.add(k11);
        datamodel_One k12 = new datamodel_One("ধারাঃ ৪৩৬","দালান ইত্যাদি ধ্বংষ করিবার অভিপ্রায়ে অগ্নি বা বিস্ফোরক দ্রব্যের সাহায্যে অনিষ্ট সাধন করা");
        dataholder_34.add(k12);

        datamodel_One k13 = new datamodel_One("ধারাঃ ৪৩৭","পাটাতনবিশিষ্ট জাহাজ বা বিশ টন পরিমাণ ভারবাহ কোন জাহাজ ধ্বংস করা বা বিপজ্জনকরূপে পরিণত করিবার অভিপ্রায়ে অনিষ্ট সাধন করা");
        dataholder_34.add(k13);
        datamodel_One k14 = new datamodel_One("ধারাঃ ৪৩৮","অগ্নি বা বিস্ফোরক দ্রব্যের সাহায্যে ৪৩৭ ধারায় বর্ণিত অনিষ্ট সাদনের শাস্তি");
        dataholder_34.add(k14);
        datamodel_One k15 = new datamodel_One("ধারাঃ ৪৩৯","চুরি ইত্যাদি অনুষ্ঠানের উদ্দেশ্যে কোন জাহাজ জলমগ্ন, চড়া বা কুলের দিকে ধাবিত করিবার শাস্তি");
        dataholder_34.add(k15);
        datamodel_One k16 = new datamodel_One("ধারাঃ ৪৪০","মৃত্যু বা আঘাত ঘটাইবার প্রসত্তুতি গ্রহণের পর অনিষ্ট সাধন করা");
        dataholder_34.add(k16);




MyAdpater_34 myAdpater_34 = new MyAdpater_34(dataholder_34);
recyclerView_34.setAdapter(myAdpater_34);


        return view;
    }

    public static class MyAdpater_34 extends RecyclerView.Adapter<MyAdpater_34.MyViewHolder_34>{
        protected static class MyViewHolder_34 extends RecyclerView.ViewHolder{

            MaterialCardView materialCardView_34;
            MaterialTextView materialTextView_Header_34, materialTextView_Desc_34;


            public MyViewHolder_34(@NonNull View itemView) {
                super(itemView);

                materialCardView_34 = itemView.findViewById(R.id.recycler_CardView);
                materialTextView_Desc_34 = itemView.findViewById(R.id.recycler_TextViewDesc);
                materialTextView_Header_34 = itemView.findViewById(R.id.recycler_TextViewHeader);


            }
        }


        ArrayList<datamodel_One> dataholder_34;

        public MyAdpater_34(ArrayList<datamodel_One> dataholder_34) {
            this.dataholder_34 = dataholder_34;
        }

        @NonNull
        @Override
        public MyViewHolder_34 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_xml_design_one,parent,false);

            return new MyViewHolder_34(view);
        }

        @Override
        public void onBindViewHolder(@NonNull MyViewHolder_34 holder, int position) {

            holder.materialTextView_Header_34.setText(dataholder_34.get(position).getHeader());
            holder.materialTextView_Desc_34.setText(dataholder_34.get(position).getDesc());
            holder.materialCardView_34.setOnClickListener(v -> {

                if (position == 0) {

                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_One_Fragment_ThirtyFour()).addToBackStack(null).commit();


                } else if (position==1) {

                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Two_Fragment_ThirtyFour()).addToBackStack(null).commit();


                }else if (position==2) {

                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Three_Fragment_ThirtyFour()).addToBackStack(null).commit();


                }else if (position==3) {

                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Four_Fragment_ThirtyFour()).addToBackStack(null).commit();


                }else if (position==4) {

                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Five_Fragment_ThirtyFour()).addToBackStack(null).commit();


                }else if (position==5) {

                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Six_Fragment_ThirtyFour()).addToBackStack(null).commit();


                }else if (position==6) {

                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Seven_Fragment_ThirtyFour()).addToBackStack(null).commit();


                }else if (position==7) {

                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Eight_Fragment_ThirtyFour()).addToBackStack(null).commit();


                }else if (position==8) {

                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Nine_Fragment_ThirtyFour()).addToBackStack(null).commit();


                }else if (position==9) {

                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Ten_Fragment_ThirtyFour()).addToBackStack(null).commit();


                }else if (position==10) {

                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Eleven_Fragment_ThirtyFour()).addToBackStack(null).commit();


                }else if (position==11) {

                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Twelve_Fragment_ThirtyFour()).addToBackStack(null).commit();


                }else if (position==12) {

                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Thirteen_Fragment_ThirtyFour()).addToBackStack(null).commit();


                }else if (position==13) {

                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Fourteen_Fragment_ThirtyFour()).addToBackStack(null).commit();


                }else if (position==14) {

                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Fifteen_Fragment_ThirtyFour()).addToBackStack(null).commit();


                }else {

                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Sixteen_Fragment_ThirtyFour()).addToBackStack(null).commit();


                }


            });

        }

        @Override
        public int getItemCount() {
            return 16;
        }

    }
}