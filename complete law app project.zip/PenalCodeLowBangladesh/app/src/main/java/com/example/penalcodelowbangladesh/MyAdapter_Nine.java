package com.example.penalcodelowbangladesh;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textview.MaterialTextView;

import java.util.ArrayList;

public class MyAdapter_Nine extends RecyclerView.Adapter <MyAdapter_Nine.PiusMardy>{
    protected static class PiusMardy extends RecyclerView.ViewHolder{
       final private MaterialTextView recycler_TextViewHeader;
       final private MaterialTextView recycler_TextViewDesc;
       final private MaterialCardView recycler_CardView;


        public PiusMardy(@NonNull View itemView) {
            super(itemView);
            recycler_TextViewHeader= itemView.findViewById(R.id.recycler_TextViewHeader);
            recycler_TextViewDesc= itemView.findViewById(R.id.recycler_TextViewDesc);
            recycler_CardView= itemView.findViewById(R.id.recycler_CardView);

        }
    }
    ArrayList<datamodel_One> Bangladesh;

    public MyAdapter_Nine(ArrayList<datamodel_One> bangladesh) {
        Bangladesh = bangladesh;
    }

    @NonNull
    @Override
    public PiusMardy onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View Myview= LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_xml_design_one,parent,false);

        return new PiusMardy(Myview);
    }

    @Override
    public void onBindViewHolder(@NonNull PiusMardy holder, @SuppressLint("RecyclerView") int position) {
        holder.recycler_TextViewHeader.setText(Bangladesh.get(position).getHeader());
        holder.recycler_TextViewDesc.setText(Bangladesh.get(position).getDesc());
        holder.recycler_CardView.setOnClickListener(v -> {
            switch (position){
                case 0:
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_one_Fragment_Nine()).addToBackStack(null).commit();
                    break;
                case 1:
                    AppCompatActivity activity1 = (AppCompatActivity) v.getContext();
                    activity1.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_two_Fragment_Nine()).addToBackStack(null).commit();
                    break;
                case 2:
                    AppCompatActivity activity2 = (AppCompatActivity) v.getContext();
                    activity2.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_three_Fragment_Nine()).addToBackStack(null).commit();
                    break;
                case 3:
                    AppCompatActivity activity3 = (AppCompatActivity) v.getContext();
                    activity3.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_four_Fragment_Nine()).addToBackStack(null).commit();
                    break;
                case 4:
                    AppCompatActivity activity4 = (AppCompatActivity) v.getContext();
                    activity4.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_five_Fragment_NIne()).addToBackStack(null).commit();
                    break;
                case 5:
                    AppCompatActivity activity5 = (AppCompatActivity) v.getContext();
                    activity5.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_six_Fragment_Nine()).addToBackStack(null).commit();
                    break;
                case 6:
                    AppCompatActivity activity6 = (AppCompatActivity) v.getContext();
                    activity6.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_seven_Fragment_NIne()).addToBackStack(null).commit();
                    break;
                case 7:
                    AppCompatActivity activity7 = (AppCompatActivity) v.getContext();
                    activity7.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_eight_Fragment_Nine()).addToBackStack(null).commit();
                    break;
                case 8:
                    Toast.makeText(v.getContext(), "বাতিল!", Toast.LENGTH_SHORT).show();
                    break;
                case 9:
                    AppCompatActivity activity9 = (AppCompatActivity) v.getContext();
                    activity9.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_nine_Fragment_Nine()).addToBackStack(null).commit();
                    break;
                default:
                    AppCompatActivity activity10 = (AppCompatActivity) v.getContext();
                    activity10.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_ten_Fragment_Nine()).addToBackStack(null).commit();
                    break;

            }

        });

    }

    @Override
    public int getItemCount() {
        return 11;
    }


}
