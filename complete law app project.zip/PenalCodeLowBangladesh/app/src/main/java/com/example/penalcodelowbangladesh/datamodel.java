package com.example.penalcodelowbangladesh;

public class datamodel {
    int image;
    String DataHeader, Desc;

    public datamodel(int image, String dataHeader, String desc) {
        this.image = image;
        DataHeader = dataHeader;
        Desc = desc;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getDataHeader() {
        return DataHeader;
    }

    public void setDataHeader(String dataHeader) {
        DataHeader = dataHeader;
    }

    public String getDesc() {
        return Desc;
    }

    public void setDesc(String desc) {
        Desc = desc;
    }
}
