package com.example.penalcodelowbangladesh;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textview.MaterialTextView;

import java.util.ArrayList;


public class Fragment_twentySix extends Fragment {

    RecyclerView recyclerView_26;
    ArrayList<datamodel_One> dataholder_26 = new ArrayList<>();
    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_twenty_six, container, false);
        recyclerView_26 = view.findViewById(R.id.recyclerView_26);
        recyclerView_26.setLayoutManager(new LinearLayoutManager(getContext()));

        datamodel_One o1 = new datamodel_One("ধারাঃ ৩৭৭","অস্বাভাবিক অপরাধসমূহ");
        dataholder_26.add(o1);


        MyAdapter_26 myAdapter_26 = new MyAdapter_26(dataholder_26);
        recyclerView_26.setAdapter(myAdapter_26);


        return view;
    }


    public static class MyAdapter_26 extends RecyclerView.Adapter<MyAdapter_26.MyViewHolder_26>{
        protected static class MyViewHolder_26 extends RecyclerView.ViewHolder{


            MaterialCardView materialCardView_26;
            MaterialTextView materialTextView_Header_26, materialTextView_Desc_26;
            public MyViewHolder_26(@NonNull View itemView) {
                super(itemView);

                materialCardView_26 = itemView.findViewById(R.id.recycler_CardView);
                materialTextView_Header_26 = itemView.findViewById(R.id.recycler_TextViewHeader);
                materialTextView_Desc_26 = itemView.findViewById(R.id.recycler_TextViewDesc);
            }
        }
        ArrayList<datamodel_One> dataholder_26;

        public MyAdapter_26(ArrayList<datamodel_One> dataholder_26) {
            this.dataholder_26 = dataholder_26;
        }

        @NonNull
        @Override
        public MyViewHolder_26 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_xml_design_one,parent,false);

            return new MyViewHolder_26(view);
        }

        @Override
        public void onBindViewHolder(@NonNull MyViewHolder_26 holder, @SuppressLint("RecyclerView") int position) {

            holder.materialTextView_Desc_26.setText(dataholder_26.get(position).getDesc());
            holder.materialTextView_Header_26.setText(dataholder_26.get(position).getHeader());
            holder.materialCardView_26.setOnClickListener(v -> {


                if (position == 0) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_One_Fragment_TwentySix()).addToBackStack(null).commit();

                }


            });
        }

        @Override
        public int getItemCount() {
            return 1;
        }

    }
}