package com.example.penalcodelowbangladesh;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textview.MaterialTextView;

import java.util.ArrayList;


public class Fragment_Seventeen extends Fragment {

    RecyclerView recyclerView_Seventeen;
    ArrayList<datamodel_One> dataholder_seventeen = new ArrayList<>();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment__seventeen, container, false);
        recyclerView_Seventeen = view.findViewById(R.id.recycerView_Seventeen);
        recyclerView_Seventeen.setLayoutManager(new LinearLayoutManager(getContext()));

        datamodel_One ob1 = new datamodel_One("ধারাঃ ২৬৮", "গণ-উপদ্রপ");
        dataholder_seventeen.add(ob1);
        datamodel_One ob2 = new datamodel_One("ধারাঃ ২৬৯", "কোন কার্য দ্বারা জীবনের পক্ষে বিপজ্জনক কোন রোগের সংক্রমন ছড়াইতে পারে জানিয়াও অবহেলাবশতঃ উহা করা");
        dataholder_seventeen.add(ob2);
        datamodel_One ob3 = new datamodel_One("ধারাঃ ২৭০", "বিদ্বেষপরয়ন হইয়া উক্ত কার্য করা");
        dataholder_seventeen.add(ob3);
        datamodel_One ob4 = new datamodel_One("ধারাঃ ২৭১", "জ্ঞাতসারে সংক্রামক রোগ সম্পর্কিত নিয়ম লংঘন করা");
        dataholder_seventeen.add(ob4);
        datamodel_One ob5 = new datamodel_One("ধারাঃ ২৭২", "বিক্রয়ের জন্য মজুদ খাদ্য বা পানীয় দ্রব্য ভেজাল দিয়া বিষাক্ত বা অনিষ্টকর করা");
        dataholder_seventeen.add(ob5);
        datamodel_One ob6 = new datamodel_One("ধারাঃ ২৭৩", "কোন খাদ্য বা পানীয় দ্রব্য স্বাস্থ্যের পক্ষে ক্ষতিকর জানিয়াও পানীয় হিসাবে তাহা বিক্রয় করা");
        dataholder_seventeen.add(ob6);
        datamodel_One ob7 = new datamodel_One("ধারাঃ ২৭৪", "বিক্রয়ের জন্য মজুদ কোন ঔষধে ভেজাল দিয়া উহার কার্যকারিতা হ্রাস করা বা উহার ক্রিয়া পরিবর্তন করা বা উহাকে অনিষ্টকর করা");
        dataholder_seventeen.add(ob7);
        datamodel_One ob8 = new datamodel_One("ধারাঃ ২৭৫", "ভেজাল বলিয়া জ্ঞাত কোন ঔষধ বিক্রয়ের জন্য রাখা বা ঔষধালয় হইতে প্রদান করা");
        dataholder_seventeen.add(ob8);
        datamodel_One ob9 = new datamodel_One("ধারাঃ ২৭৬", "জ্ঞাতসারে কোন ঔষধ অপর কোন ঔষধ বলিয়া বিক্রয় করা বা ঔষধালয় হইতে প্রদান করা");
        dataholder_seventeen.add(ob9);
        datamodel_One ob10 = new datamodel_One("ধারাঃ ২৭৭", "সর্বসাধারণের ব্যবহার্য ঝরণা বা সংরক্ষণাবেক্ষনাগারের পানি দূষিত করা");
        dataholder_seventeen.add(ob10);

        datamodel_One ob11 = new datamodel_One("ধারাঃ ২৭৮", "আবহাওয়াকে স্বাস্থ্যের পক্ষে অনিষ্টকর করা");
        dataholder_seventeen.add(ob11);
        datamodel_One ob12 = new datamodel_One("ধারাঃ ২৭৯", "মানুষের জীবন বিপন্ন হইতে পারে এইরূপভাবে সাধারণের ব্যবহার্য রাসত্মায় বেপরোয়া বা অবহেলার সহিত গাড়ি বা ঘোড়া চালানো");
        dataholder_seventeen.add(ob12);
        datamodel_One ob13 = new datamodel_One("ধারাঃ ২৮০", "বেপরোয়া জাহাজ চালানো");
        dataholder_seventeen.add(ob13);
        datamodel_One ob14 = new datamodel_One("ধারাঃ ২৮১", "মিথ্যা আলো চিহ্ন বা বয়া প্রদর্শন করা");
        dataholder_seventeen.add(ob14);
        datamodel_One ob15 = new datamodel_One("ধারাঃ ২৮২", "ভাড়ার বিনিময়ে এরূপ অবস্থায় বা এরূপ মাল বোঝাই নৌযানে যাত্রী বহন করা যাহার ফলে তাহার জীবন বিপন্ন হইতে পারে");
        dataholder_seventeen.add(ob15);
        datamodel_One ob16 = new datamodel_One("ধারাঃ ২৮৩", "সর্বসাধারণের ব্যবহার্য রাস্তা বা নৌপথে বিপদ, বাধা বা ক্ষতির কারণ ঘটানো");
        dataholder_seventeen.add(ob16);
        datamodel_One ob17 = new datamodel_One("ধারাঃ ২৮৪", "মানুষের জীবন বিপন্ন হইতে পারে এরূপ কোন বিষাক্ত দ্রব্য লইয়া কারবার");
        dataholder_seventeen.add(ob17);
        datamodel_One ob18 = new datamodel_One("ধারাঃ ২৮৫", "ঐরূপ দহনশীল দ্রব্য বা আগুন লইয়া কারবার");
        dataholder_seventeen.add(ob18);
        datamodel_One ob19 = new datamodel_One("ধারাঃ ২৮৬", "বিষ্ফোরক দ্রব্য লইয়া ঐরূপ কারবার");
        dataholder_seventeen.add(ob19);
        datamodel_One ob20 = new datamodel_One("ধারাঃ ২৮৭", "কোন যন্ত্রপাতি লইয়া ঐরূপ কারবার");
        dataholder_seventeen.add(ob20);

        datamodel_One ob21 = new datamodel_One("ধারাঃ ২৮৮", "ভাঙ্গিয়া ফেলা বা মেরামতের অধিকার সম্পন্ন কোন ব্যক্তি কর্তৃ কোন বাড়ি ভাঙ্গিয়া ফেলার ফলে মানুষের জীবনের প্রতি সম্ভাব্য বিপদ সম্পর্কে সতর্ক না থাকা");
        dataholder_seventeen.add(ob21);
        datamodel_One ob22 = new datamodel_One("ধারাঃ ২৮৯", "প্রাণী সম্পর্কে তাচ্ছিল্যপূর্ণ আচরণ");
        dataholder_seventeen.add(ob22);
        datamodel_One ob23 = new datamodel_One("ধারাঃ ২৯০", "সর্বসাধারণের আপদ সৃষ্টি করা");
        dataholder_seventeen.add(ob23);
        datamodel_One ob24 = new datamodel_One("ধারাঃ ২৯১", " নিষেধাজ্ঞা জারির পর আপদ অব্যাহত রাখা");
        dataholder_seventeen.add(ob24);
        datamodel_One ob25 = new datamodel_One("ধারাঃ ২৯২", "অশ্লীল বই বিক্রয় করা ইত্যাদি");
        dataholder_seventeen.add(ob25);
        datamodel_One ob26 = new datamodel_One("ধারাঃ ২৯৩", "যুবক-যুবতীদের নিকট অশ্লীল বস্তু বিক্রয় করা ");
        dataholder_seventeen.add(ob26);
        datamodel_One ob27 = new datamodel_One("ধারাঃ ২৯৪", "অশ্লীল কার্য ও সঙ্গীত করা");
        dataholder_seventeen.add(ob27);
        datamodel_One ob28 = new datamodel_One("ধারাঃ ২৯৪-ক", "লটারি অফিস রাখা");
        dataholder_seventeen.add(ob28);
        datamodel_One ob29 = new datamodel_One("ধারাঃ ২৯৪-খ", "বাণিজ্য ইত্যাদি সম্পর্কে পুরস্কার প্রদান করা");
        dataholder_seventeen.add(ob29);



        MyAdpater_Seventeen myAdpater_seventeen = new MyAdpater_Seventeen(dataholder_seventeen);
        recyclerView_Seventeen.setAdapter(myAdpater_seventeen);

        return view;

    }

   public static class MyAdpater_Seventeen extends RecyclerView.Adapter<MyAdpater_Seventeen.MyViewHolder_Seventeen>{
       protected static class MyViewHolder_Seventeen extends RecyclerView.ViewHolder{
           MaterialTextView recyclerTextView_Header,recyclerTextView_Desc;
           MaterialCardView recyclerCardView_seventeen;
           public MyViewHolder_Seventeen(@NonNull View itemView) {
               super(itemView);
               recyclerTextView_Header = itemView.findViewById(R.id.recycler_TextViewHeader);
               recyclerTextView_Desc = itemView.findViewById(R.id.recycler_TextViewDesc);
               recyclerCardView_seventeen = itemView.findViewById(R.id.recycler_CardView);
           }
       }
       ArrayList<datamodel_One> dataholder_seventeen;

       public MyAdpater_Seventeen(ArrayList<datamodel_One> dataholder_seventeen) {
           this.dataholder_seventeen = dataholder_seventeen;
       }

       @NonNull
       @Override
       public MyViewHolder_Seventeen onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

           View myView = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_xml_design_one,parent,false);

           return new MyViewHolder_Seventeen(myView);
       }

       @Override
       public void onBindViewHolder(@NonNull MyViewHolder_Seventeen holder, int position) {

           holder.recyclerTextView_Header.setText(dataholder_seventeen.get(position).getHeader());
           holder.recyclerTextView_Desc.setText(dataholder_seventeen.get(position).getDesc());
           holder.recyclerCardView_seventeen.setOnClickListener(v -> {

               if (position == 0) {
                   AppCompatActivity activity = (AppCompatActivity) v.getContext();
                   activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_One_Fragment_Seventeen()).addToBackStack(null).commit();
               }else if (position==1){
                   AppCompatActivity activity2 = (AppCompatActivity) v.getContext();
                   activity2.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_two_Fragment_Seventeen()).addToBackStack(null).commit();
               } else if (position==2) {
                   AppCompatActivity activity3 = (AppCompatActivity) v.getContext();
                   activity3.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_three_Fragment_Seventeen()).addToBackStack(null).commit();

               } else if (position==3) {
                   AppCompatActivity activity4 = (AppCompatActivity) v.getContext();
                   activity4.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_four_Fragment_Seventeen()).addToBackStack(null).commit();

               } else if (position==4) {
                   AppCompatActivity activity5 = (AppCompatActivity) v.getContext();
                   activity5.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_five_Fragment_Seventeen()).addToBackStack(null).commit();


               } else if (position==5) {
                   AppCompatActivity activity6 = (AppCompatActivity) v.getContext();
                   activity6.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_six_Fragment_Seventeen()).addToBackStack(null).commit();


               } else if (position==6) {
                   AppCompatActivity activity7 = (AppCompatActivity) v.getContext();
                   activity7.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_seven_Fragment_Seventeen()).addToBackStack(null).commit();


               } else if (position==7) {
                   AppCompatActivity activity8 = (AppCompatActivity) v.getContext();
                   activity8.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_eight_Fragment_Seventeen()).addToBackStack(null).commit();


               } else if (position==8) {
                   AppCompatActivity activity9 = (AppCompatActivity) v.getContext();
                   activity9.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_nine_Fragment_Seventeen()).addToBackStack(null).commit();

               } else if (position==9) {
                   AppCompatActivity activity10 = (AppCompatActivity) v.getContext();
                   activity10.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_ten_Fragment_Seventeen()).addToBackStack(null).commit();

               } else if (position==10) {
                   AppCompatActivity activity11 = (AppCompatActivity) v.getContext();
                   activity11.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_eleven_Fragment_Seventeen()).addToBackStack(null).commit();

               } else if (position==11) {
                   AppCompatActivity activity12 = (AppCompatActivity) v.getContext();
                   activity12.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_twelve_Fragment_Seventeen()).addToBackStack(null).commit();

               } else if (position==12) {
                   AppCompatActivity activity13 = (AppCompatActivity) v.getContext();
                   activity13.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_thirteen_Fragment_Seventeen()).addToBackStack(null).commit();


               } else if (position==13) {
                   AppCompatActivity activity14 = (AppCompatActivity) v.getContext();
                   activity14.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_fourteen_Fragment_Seventeen()).addToBackStack(null).commit();


               } else if (position==14) {
                   AppCompatActivity activity15 = (AppCompatActivity) v.getContext();
                   activity15.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_fifteen_Fragment_Seventeen()).addToBackStack(null).commit();


               } else if (position==15) {
                   AppCompatActivity activity16 = (AppCompatActivity) v.getContext();
                   activity16.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Sixteen_Fragment_Seventeen()).addToBackStack(null).commit();


               } else if (position==16) {
                   AppCompatActivity activity17 = (AppCompatActivity) v.getContext();
                   activity17.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Seventeen_Fragment_Seventeen()).addToBackStack(null).commit();

               } else if (position==17) {
                   AppCompatActivity activity18 = (AppCompatActivity) v.getContext();
                   activity18.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Eighteen_Fragment_Seventeen()).addToBackStack(null).commit();


               } else if (position==18) {
                   AppCompatActivity activity19 = (AppCompatActivity) v.getContext();
                   activity19.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Nineteen_Fragment_Seventeen()).addToBackStack(null).commit();


               } else if (position==19) {
                   AppCompatActivity activity20 = (AppCompatActivity) v.getContext();
                   activity20.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Twenty_Fragment_Seventeen()).addToBackStack(null).commit();


               } else if (position==20) {
                   AppCompatActivity activity21 = (AppCompatActivity) v.getContext();
                   activity21.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_TwentyOne_Fragment_Seventeen()).addToBackStack(null).commit();


               } else if (position==21) {
                   AppCompatActivity activity22 = (AppCompatActivity) v.getContext();
                   activity22.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_TwentyTwo_Fragment_Seventeen()).addToBackStack(null).commit();


               } else if (position==22) {
                   AppCompatActivity activity23 = (AppCompatActivity) v.getContext();
                   activity23.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_TwentyThree_Fragment_Seventeen()).addToBackStack(null).commit();


               } else if (position==23) {
                   AppCompatActivity activity24 = (AppCompatActivity) v.getContext();
                   activity24.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_TwentyFour_Fragment_Seventeen()).addToBackStack(null).commit();


               } else if (position==24) {
                   AppCompatActivity activity25 = (AppCompatActivity) v.getContext();
                   activity25.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_TwentyFive_Fragment_Seventeen()).addToBackStack(null).commit();


               } else if (position==25) {
                   AppCompatActivity activity26 = (AppCompatActivity) v.getContext();
                   activity26.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_TwentySix_Fragment_Seventeen()).addToBackStack(null).commit();


               } else if (position==26) {
                   AppCompatActivity activity27 = (AppCompatActivity) v.getContext();
                   activity27.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_TwentySeven_Fragment_Seventeen()).addToBackStack(null).commit();


               } else if (position==27) {
                   AppCompatActivity activity28 = (AppCompatActivity) v.getContext();
                   activity28.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_TwentyEight_Fragment_Seventeen()).addToBackStack(null).commit();


               } else  {
                   AppCompatActivity activity29 = (AppCompatActivity) v.getContext();
                   activity29.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_TwentyNine_Fragment_Seventeen()).addToBackStack(null).commit();


               }


           });
       }

       @Override
       public int getItemCount() {
           return 29;
       }


   }
}

