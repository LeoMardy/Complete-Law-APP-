package com.example.penalcodelowbangladesh;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textview.MaterialTextView;

import java.util.ArrayList;

public class MyAdpater_Three extends RecyclerView.Adapter<MyAdpater_Three.MyViewHolder_Three> {
    protected static class MyViewHolder_Three extends RecyclerView.ViewHolder{
       final MaterialCardView materialCardView;
       final MaterialTextView materialTextView_Header,materialTextView_Desc;

        public MyViewHolder_Three(@NonNull View itemView) {
            super(itemView);
            materialCardView = itemView.findViewById(R.id.recycler_CardView);
            materialTextView_Header = itemView.findViewById(R.id.recycler_TextViewHeader);
            materialTextView_Desc = itemView.findViewById(R.id.recycler_TextViewDesc);
        }
    }
    ArrayList<datamodel_One> dataholder_three;

    public MyAdpater_Three(ArrayList<datamodel_One> dataholder_three) {
        this.dataholder_three = dataholder_three;
    }

    @NonNull
    @Override
    public MyViewHolder_Three onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_xml_design_one,parent,false);

        return new MyViewHolder_Three(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder_Three holder, @SuppressLint("RecyclerView") int position) {
      holder.materialTextView_Header.setText(dataholder_three.get(position).getHeader());
      holder.materialTextView_Desc.setText(dataholder_three.get(position).getDesc());
      holder.materialCardView.setOnClickListener(v -> {
          switch (position){
              case 0:
                  AppCompatActivity activity = (AppCompatActivity) v.getContext();
                  activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_One_Fragment_Three()).addToBackStack(null).commit();
                  break;
              case 1:
                  AppCompatActivity activity1 = (AppCompatActivity) v.getContext();
                  activity1.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_two_Fragment_Three()).addToBackStack(null).commit();
                  break;
              case 2:
                  AppCompatActivity activity2 = (AppCompatActivity) v.getContext();
                  activity2.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_three_Fragment_Three()).addToBackStack(null).commit();
                  break;
              case 3:
                  AppCompatActivity activity3 = (AppCompatActivity) v.getContext();
                  activity3.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_four_Fragment_Three()).addToBackStack(null).commit();
                  break;
              case 4:
                  AppCompatActivity activity4 = (AppCompatActivity) v.getContext();
                  activity4.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_five_Fragment_Three()).addToBackStack(null).commit();
                  break;
              case 5:
                  Toast.makeText(v.getContext(), "বাতিল", Toast.LENGTH_SHORT).show();
                  break;
              case 6:
                  AppCompatActivity activity5 = (AppCompatActivity) v.getContext();
                  activity5.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_six_Fragment_Three()).addToBackStack(null).commit();
                  break;
              case 7:
                  Toast.makeText(v.getContext(), "বাতিল", Toast.LENGTH_SHORT).show();
                  break;
              case 8:
                  Toast.makeText(v.getContext(), "বাতিল", Toast.LENGTH_SHORT).show();
                  break;
              case 9:
                  AppCompatActivity activity6 = (AppCompatActivity) v.getContext();
                  activity6.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_seven_Fragment_Three()).addToBackStack(null).commit();
                  break;
              case 10:
                  Toast.makeText(v.getContext(), "বাতিল", Toast.LENGTH_SHORT).show();
                  break;
              case 11:
                  Toast.makeText(v.getContext(), "বাতিল", Toast.LENGTH_SHORT).show();
                  break;
              case 12:
                  AppCompatActivity activity7 = (AppCompatActivity) v.getContext();
                  activity7.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_eight_Fragment_Three()).addToBackStack(null).commit();
                  break;
              case 13:
                  AppCompatActivity activity8 = (AppCompatActivity) v.getContext();
                  activity8.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_nine_Fragment_Three()).addToBackStack(null).commit();
                  break;
              case 14:
                  AppCompatActivity activity9 = (AppCompatActivity) v.getContext();
                  activity9.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_ten_Fragment_Three()).addToBackStack(null).commit();
                  break;
              case 15:
                  AppCompatActivity activity10 = (AppCompatActivity) v.getContext();
                  activity10.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_eleven_Fragment_Three()).addToBackStack(null).commit();
                  break;
              case 16:
                  AppCompatActivity activity11 = (AppCompatActivity) v.getContext();
                  activity11.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_twelve_Fragment_Three()).addToBackStack(null).commit();
                  break;
              case 17:
                  AppCompatActivity activity12 = (AppCompatActivity) v.getContext();
                  activity12.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_thirteen_Fragment_Three()).addToBackStack(null).commit();
                  break;
              case 18:
                  AppCompatActivity activity13 = (AppCompatActivity) v.getContext();
                  activity13.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_fourteen_Fragment_Three()).addToBackStack(null).commit();
                  break;
              case 19:
                  AppCompatActivity activity14 = (AppCompatActivity) v.getContext();
                  activity14.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_fifteen_Fragment_Three()).addToBackStack(null).commit();
                  break;
              case 20:
                  AppCompatActivity activity15 = (AppCompatActivity) v.getContext();
                  activity15.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_sixteen_Fragment_Three()).addToBackStack(null).commit();
                  break;
              case 21:
                  AppCompatActivity activity16 = (AppCompatActivity) v.getContext();
                  activity16.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_seventeen_Fragment_Three()).addToBackStack(null).commit();
                  break;
              case 22:
                  AppCompatActivity activity17 = (AppCompatActivity) v.getContext();
                  activity17.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_eighteen_Fragment_Three()).addToBackStack(null).commit();
                  break;
              case 23:
                  AppCompatActivity activity18 = (AppCompatActivity) v.getContext();
                  activity18.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_nineteen_Fragment_Three()).addToBackStack(null).commit();
                  break;
              case 24:
                  AppCompatActivity activity19 = (AppCompatActivity) v.getContext();
                  activity19.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_twenty_Fragment_Three()).addToBackStack(null).commit();
                  break;



          }
      });
    }

    @Override
    public int getItemCount() {
        return 25;
    }
}
