package com.example.penalcodelowbangladesh;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textview.MaterialTextView;

import java.util.ArrayList;


public class Fragment_TwentyFive extends Fragment {

    RecyclerView recyclerView_25;
    ArrayList<datamodel_One> dataholder_25 = new ArrayList<>();


    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment__twenty_five, container, false);
        recyclerView_25 = view.findViewById(R.id.recyclerView_25);
        recyclerView_25.setLayoutManager(new LinearLayoutManager(getContext()));

        datamodel_One p1 = new datamodel_One("ধারাঃ ৩৭৫","নারী ধর্ষণ");
        dataholder_25.add(p1);
        datamodel_One p2 = new datamodel_One("ধারাঃ ৩৭৬ ","নারী ধর্ষণের শাস্তি");
        dataholder_25.add(p2);


MyAdapter_25 myAdapter_25 = new MyAdapter_25(dataholder_25);
recyclerView_25.setAdapter(myAdapter_25);

        return view;
    }
    public  static class MyAdapter_25 extends RecyclerView.Adapter<MyAdapter_25.MyViewholder_25>{
        protected static class MyViewholder_25 extends RecyclerView.ViewHolder{
     MaterialCardView materialCardView_25;
     MaterialTextView materialTextView_Header_25, materialTextView_Desc_25;

            public MyViewholder_25(@NonNull View itemView) {
                super(itemView);

                materialCardView_25 = itemView.findViewById(R.id.recycler_CardView);
                materialTextView_Header_25 = itemView.findViewById(R.id.recycler_TextViewHeader);
                materialTextView_Desc_25 = itemView.findViewById(R.id.recycler_TextViewDesc);


            }
        }
        ArrayList<datamodel_One> dataholder_25 ;

        public MyAdapter_25(ArrayList<datamodel_One> dataholder_25) {
            this.dataholder_25 = dataholder_25;
        }

        @NonNull
        @Override
        public MyViewholder_25 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_xml_design_one,parent,false);

            return new MyViewholder_25(view);
        }

        @Override
        public void onBindViewHolder(@NonNull MyViewholder_25 holder, int position) {

            holder.materialTextView_Desc_25.setText(dataholder_25.get(position).getDesc());
            holder.materialTextView_Header_25.setText(dataholder_25.get(position).getHeader());
            holder.materialCardView_25.setOnClickListener(v -> {


                if (position == 0) {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_One_Fragment_TwentyFive()).addToBackStack(null).commit();


                } else  {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Two_Fragment_TwentyFive()).addToBackStack(null).commit();


                }


            });

        }

        @Override
        public int getItemCount() {
            return 2;
        }
    }
}