package com.example.penalcodelowbangladesh;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;


public class Fragment_Four extends Fragment {
    private RecyclerView recyclerView;
    ArrayList<datamodel_One> dataholder_four = new ArrayList<>();

    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View myView =  inflater.inflate(R.layout.fragment__four, container, false);
        recyclerView = myView.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        datamodel_One ob1 = new datamodel_One("ধারা-৭৬","আইনবলে বাধ্য বা ভুল ধারণাবশত নিজেকে আইনবলে বাধ্য বলিয়া বিশ্বাসকারী ব্যক্তি বিশেষে কর্তৃক সম্পাদিত কার্য");
        dataholder_four.add(ob1);
        datamodel_One ob2 = new datamodel_One("ধারাঃ ৭৭","বিচার-সম্পর্কিত কার্য পরিচালনাকালে বিচারকের কার্য");
        dataholder_four.add(ob2);
        datamodel_One ob3 = new datamodel_One("ধারাঃ ৭৮","আদালতের রায় বা আদেশের অনুস্বরণে সম্পাদিত কার্য");
        dataholder_four.add(ob3);
        datamodel_One ob4 = new datamodel_One("ধারাঃ ৭৯","আইন সমর্থিত বা ভুল ধারণাবশত নিজেকে আইন সমর্থিত বলিয়া বিশ্বাসকারী ব্যক্তি কর্তৃক সম্পাদিত কার্য");
        dataholder_four.add(ob4);
        datamodel_One ob5 = new datamodel_One("ধারাঃ ৮০","আইনানুগ কার্য সম্পাদনকালে দুর্ঘটনা");
        dataholder_four.add(ob5);
        datamodel_One ob6 = new datamodel_One("ধারাঃ ৮১","সম্ভাব্য ক্ষতিকারক কার্য, কিন্তু অপরাধমূক অভিপ্রায় ব্যতিরেকে এবং অন্যবিধ ক্ষতি নিবারণকল্পে সম্পাদিত");
        dataholder_four.add(ob6);
        datamodel_One ob7 = new datamodel_One("ধারাঃ ৮২","নয় বৎসরের কম বয়স্ক শিশুর কর্য");
        dataholder_four.add(ob7);
        datamodel_One ob8 = new datamodel_One("ধারাঃ ৮৩","নয় বৎসরের অধিক বয়স্ক ও বার বৎসরের কম বয়স্ক অপরিণত বোধ শক্তিসম্পন্ন শিশুর কার্য");
        dataholder_four.add(ob8);
        datamodel_One ob9 = new datamodel_One("ধারাঃ ৮৪"," অপ্রকৃতিস্থ ব্যক্তির কার্য");
        dataholder_four.add(ob9);
        datamodel_One ob10 = new datamodel_One("ধারাঃ ৮৫","অনিচ্ছাকৃত প্রমত্ততার কারণে বিচারশক্তি রহিত ব্যক্তির কার্য");
        dataholder_four.add(ob10);
        datamodel_One ob11 = new datamodel_One("ধারাঃ ৮৬","যে অপরাধের ক্ষেত্রে বিশেষ কোন উদ্দেশ্য বা জ্ঞানের প্রয়োজন রহিয়াছে উন্মত্ত ব্যক্তি কর্তৃক সেই অপরাধ অনুষ্ঠান");
        dataholder_four.add(ob11);
        datamodel_One ob12 = new datamodel_One("ধারাঃ ৮৭","মৃত্যু বা গুরুতর আঘাত ঘটাইবার জন্য অভিপ্রেত নহে, এবং অনুরূপ সম্ভাবনাপূর্ণ বলিয়া অজ্ঞাত কার্য সম্মতি সহকারে সম্পাদন করা");
        dataholder_four.add(ob12);
        datamodel_One ob13 = new datamodel_One("ধারাঃ ৮৮","মৃত্যু ঘটাইবার জন্য অভিপ্রেত নহে এমন কার্য ব্যক্তি বিশেষের উপকারার্থ সদবিশ্বাসে সম্মতি সহকারে সম্পাদন");
        dataholder_four.add(ob13);
        datamodel_One ob14 = new datamodel_One("ধারাঃ ৮৯","অভিভাবক কর্তৃক বা তাহার সম্মতিক্রমে শিশু বা অপ্রকৃতিস্থ ব্যক্তির মঙ্গলার্থে সদবিশ্বাসে কৃত কার্য");
        dataholder_four.add(ob14);
        datamodel_One ob15 = new datamodel_One("ধারাঃ ৯০","ভীতি বা ভ্রান্ত ধারণার অধীনে প্রদত্ত বলিয়া বিদিত সম্মতি");
        dataholder_four.add(ob15);
        datamodel_One ob16 = new datamodel_One("ধারাঃ ৯১","যেই সকল কার্য সাধিত ক্ষতি হইতে স্বতন্ত্রভাবে অপরাধ বলিয়া গণ্য সেই সকল কার্য বর্জন");
        dataholder_four.add(ob16);
        datamodel_One ob17 = new datamodel_One("ধারাঃ ৯২","সম্মতি ব্যতিরেকে কোন ব্যক্তির মঙ্গলার্থে সদবিশ্বাসে কৃত কার্য");
        dataholder_four.add(ob17);
        datamodel_One ob18 = new datamodel_One("ধারাঃ ৯৩","সদবিশ্বাসে কৃত যোগাযোগ");
        dataholder_four.add(ob18);
        datamodel_One ob19 = new datamodel_One("ধারাঃ ৯৪","যে কার্য করিবার জন্য ভীতি প্রদর্শন করিয়া কোন ব্যক্তিকে বাধ্য করা হয়");
        dataholder_four.add(ob19);
        datamodel_One ob20 = new datamodel_One("ধারা ৯৫","সামান্য ক্ষতিকারক কার্য");
        dataholder_four.add(ob20);

        MyAdapter_Four myAdapter_four = new MyAdapter_Four(dataholder_four);
        recyclerView.setAdapter(myAdapter_four);
        return myView;
    }
}