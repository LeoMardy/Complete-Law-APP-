package com.example.penalcodelowbangladesh;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textview.MaterialTextView;

import java.util.ArrayList;


public class Fragment_TwentyTwo extends Fragment {


    RecyclerView recyclerView_22;
    ArrayList<datamodel_One> dataholder_22 = new ArrayList<>();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment__twenty_two, container, false);
        recyclerView_22 = view.findViewById(R.id.recyclerView_22);
        recyclerView_22.setLayoutManager(new LinearLayoutManager(getContext()));

        datamodel_One L1 = new datamodel_One("ধারাঃ ৩৩৯","অবৈধ বাধা");
        dataholder_22.add(L1);
        datamodel_One L2 = new datamodel_One("ধারাঃ ৩৪০","অবৈধ অবরোধ");
        dataholder_22.add(L2);
        datamodel_One L3 = new datamodel_One("ধারাঃ ৩৪১","অবৈধ বাধাদানের শাস্তি");
        dataholder_22.add(L3);
        datamodel_One L4 = new datamodel_One("ধারাঃ ৩৪২","অবৈধ অবরোধের শাস্তি");
        dataholder_22.add(L4);
        datamodel_One L5 = new datamodel_One("ধারাঃ ৩৪৩","তিন বা ততোধিক দিবসের জন্য অবৈধ অবরোধ");
        dataholder_22.add(L5);
        datamodel_One L6 = new datamodel_One("ধারাঃ ৩৪৪","দশ বা ততোধিক দিবসের জন্য অবৈধ অবরোধ");
        dataholder_22.add(L6);
        datamodel_One L7 = new datamodel_One("ধারাঃ ৩৪৫","যে ব্যক্তির মুক্তিকল্পে রীট জারি করা হইয়াছে তাহার অবৈধ অবরোধ");
        dataholder_22.add(L7);
        datamodel_One L8 = new datamodel_One("ধারাঃ ৩৪৬","গোপনে অবৈধ অবরোধ");
        dataholder_22.add(L8);
        datamodel_One L9 = new datamodel_One("ধারাঃ ৩৪৭","বলপূর্বক সম্পত্তি ছিনাইয়া লইবার বা অবৈধ কাজ করিতে বাধ্য করিবার জন্য অবৈধ অবরোধ");
        dataholder_22.add(L9);
        datamodel_One L10 = new datamodel_One("ধারাঃ ৩৪৮","স্বীকারোক্তি আদায় করিবার বা সম্পত্তি প্রত্যর্পণ করিতে বাধ্য করিবার জন্য অবৈধ অবরোধ");
        dataholder_22.add(L10);


        MyAdapter_22 myAdapter_22 = new MyAdapter_22(dataholder_22);
        recyclerView_22.setAdapter(myAdapter_22);

        return view;
    }


    public static class MyAdapter_22 extends RecyclerView.Adapter<MyAdapter_22.MyViewholder_22>{
        protected static class MyViewholder_22 extends RecyclerView.ViewHolder{

            MaterialCardView materialCardView_22;
            MaterialTextView materialTextView_Header_22, materialTextView_Desc_22;

            public MyViewholder_22(@NonNull View itemView) {
                super(itemView);

                materialCardView_22 = itemView.findViewById(R.id.recycler_CardView);
                materialTextView_Header_22=itemView.findViewById(R.id.recycler_TextViewHeader);
                materialTextView_Desc_22 = itemView.findViewById(R.id.recycler_TextViewDesc);


            }
        }
        ArrayList<datamodel_One> dataholder_22;

        public MyAdapter_22(ArrayList<datamodel_One> dataholder_22) {
            this.dataholder_22 = dataholder_22;
        }

        @NonNull
        @Override
        public MyViewholder_22 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_xml_design_one,parent,false);

            return new MyViewholder_22(view);
        }

        @Override
        public void onBindViewHolder(@NonNull MyViewholder_22 holder, int position) {
         holder.materialTextView_Header_22.setText(dataholder_22.get(position).getHeader());
         holder.materialTextView_Desc_22.setText(dataholder_22.get(position).getDesc());
         holder.materialCardView_22.setOnClickListener(v -> {

             if (position == 0) {
                 AppCompatActivity activity = (AppCompatActivity) v.getContext();
                 activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_One_Fragment_TwentyTwo()).addToBackStack(null
                 ).commit();

             } else if (position==1) {

                 AppCompatActivity activity = (AppCompatActivity) v.getContext();
                 activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Two_Fragment_TwentyTwo()).addToBackStack(null
                 ).commit();
             }else if (position==2) {

                 AppCompatActivity activity = (AppCompatActivity) v.getContext();
                 activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Three_Fragment_TwentyTwo()).addToBackStack(null
                 ).commit();
             }else if (position==3) {

                 AppCompatActivity activity = (AppCompatActivity) v.getContext();
                 activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Four_Fragment_twentyTwo()).addToBackStack(null
                 ).commit();
             }else if (position==4) {

                 AppCompatActivity activity = (AppCompatActivity) v.getContext();
                 activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Five_Fragment_TwentyTwo()).addToBackStack(null
                 ).commit();
             }else if (position==5) {

                 AppCompatActivity activity = (AppCompatActivity) v.getContext();
                 activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Six_Fragment_TwentyTwo()).addToBackStack(null
                 ).commit();
             }else if (position==6) {

                 AppCompatActivity activity = (AppCompatActivity) v.getContext();
                 activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Seven_Fragment_TwentyTwo()).addToBackStack(null
                 ).commit();
             }else if (position==7) {

                 AppCompatActivity activity = (AppCompatActivity) v.getContext();
                 activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Eight_Fragment_TwentyTwo()).addToBackStack(null
                 ).commit();
             }else if (position==8) {

                 AppCompatActivity activity = (AppCompatActivity) v.getContext();
                 activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Nine_Fragment_TwentyTwo()).addToBackStack(null
                 ).commit();
             }else  {

                 AppCompatActivity activity = (AppCompatActivity) v.getContext();
                 activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Ten_Fragment_TwentyTwo()).addToBackStack(null
                 ).commit();
             }

         });
        }

        @Override
        public int getItemCount() {
            return 10;
        }

    }
}