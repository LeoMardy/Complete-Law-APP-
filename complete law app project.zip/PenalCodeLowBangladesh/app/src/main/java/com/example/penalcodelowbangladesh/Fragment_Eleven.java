package com.example.penalcodelowbangladesh;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;


public class Fragment_Eleven extends Fragment {
    private RecyclerView recyclerView_Eleven;
    private ArrayList<datamodel_One>dataholder_Eleven = new ArrayList<>();
    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment__eleven, container, false);
        recyclerView_Eleven = view.findViewById(R.id.recyclerView_Eleven);
        recyclerView_Eleven.setLayoutManager(new LinearLayoutManager(getContext()));

        datamodel_One obj1 = new datamodel_One("ধারাঃ ১৬১","সরকারী কর্মচারী হইয়া বা হওয়ার আশা করিয়া কোন সরকারী কার্যের জন্য ঘুষ লওয়া");
        dataholder_Eleven.add(obj1);
        datamodel_One obj2 = new datamodel_One("ধারাঃ ১৬২","দুর্নীতিমূলক বা বেআইনী উপায়ে সরকারী কর্মচারীকে প্রভাবিত করার জন্য ঘুষ লওয়া");
        dataholder_Eleven.add(obj2);
        datamodel_One obj3 = new datamodel_One("ধারাঃ ১৬৩","সরকারী কর্মচারীর উপর ব্যক্তিগত প্রভাব বিস্তারের জন্য ঘুষ লওয়া");
        dataholder_Eleven.add(obj3);
        datamodel_One obj4 = new datamodel_One("ধারাঃ ১৬৪","সরকারী কর্মচারী কর্তৃক ১৬২ বা ১৬৩ ধারায় বর্ণিত অপরাধসমূহে সহায়তা করিবার শাস্তি");
        dataholder_Eleven.add(obj4);
        datamodel_One obj5 = new datamodel_One("ধারাঃ ১৬৫","সরকারী কর্মচারী কর্তৃক তাহার কার্যের সহিত জড়িত কোন ব্যক্তির নিকট হইতে বিনামূল্যে কোন মূল্যবান বস্তু গ্রহণ করা");
        dataholder_Eleven.add(obj5);
        datamodel_One obj6 = new datamodel_One("ধারাঃ ১৬৫-ক","১৬১ ও ১৬৫ ধারার অপরাধে প্ররোচনা দেওয়া");
        dataholder_Eleven.add(obj6);
        datamodel_One obj7 = new datamodel_One("ধারাঃ ১৬৫-খ","১৬১ ও ১৬৫ ধারার অপরাধে প্ররোচনা দেওয়া");
        dataholder_Eleven.add(obj7);
        datamodel_One obj8 = new datamodel_One("ধারাঃ ১৬৬","কোন ব্যক্তির ক্ষতি করার উদ্দেশ্যে সরকারী কর্মচারী কর্তৃক আইনের নির্দেশ লংঘন");
        dataholder_Eleven.add(obj8);
        datamodel_One obj9 = new datamodel_One("ধারাঃ ১৬৭"," ক্ষতি করার উদ্দেশ্যে সরকারী কর্মচারী কর্তৃক ভূল দলিল প্রণয়ন");
        dataholder_Eleven.add(obj9);
        datamodel_One obj10 = new datamodel_One("ধারাঃ ১৬৮","সরকারী কর্মচারী কর্তৃক বেআইনীভাবে ব্যবসা করা");
        dataholder_Eleven.add(obj10);
        datamodel_One obj11 = new datamodel_One("ধারাঃ ১৬৯","সরকারী কর্মচারী কর্তৃক বেআইনীভাবে সম্পত্তি ক্রয় বা নিলাম ডাকা");
        dataholder_Eleven.add(obj11);
        datamodel_One obj12 = new datamodel_One("ধারাঃ ১৭০","ভুয়া সরকারী কর্মচারী বলিয়া পরিচয় দেওয়া");
        dataholder_Eleven.add(obj12);
        datamodel_One obj13 = new datamodel_One("ধারাঃ ১৭১","অসৎ উদ্দেশ্যে সরকারী কর্মচারীর পোশাক পরিধান বা চিহ্ন বহন");
        dataholder_Eleven.add(obj13);

   MyAdpater_Eleven myAdpater_eleven = new MyAdpater_Eleven(dataholder_Eleven);
   recyclerView_Eleven.setAdapter(myAdpater_eleven);


        return  view;
    }
}