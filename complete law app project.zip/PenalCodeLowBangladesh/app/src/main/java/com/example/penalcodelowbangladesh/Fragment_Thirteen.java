package com.example.penalcodelowbangladesh;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;


public class Fragment_Thirteen extends Fragment {
    private RecyclerView recyclerView_Thirteen;
    private ArrayList<datamodel_One> dataholder_Thirteen = new ArrayList<>();

    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment__thirteen, container, false);
        recyclerView_Thirteen = view.findViewById(R.id.recyclerView_Thirteen);
        recyclerView_Thirteen.setLayoutManager(new LinearLayoutManager(getContext()));

        datamodel_One ob1 = new datamodel_One("ধারাঃ ১৭২"," কোন সরকারী কর্মচারী কর্তৃক দেওয়া সমন প্রভৃতি এড়ানোর জন্য পলায়ন");
        dataholder_Thirteen.add(ob1);
        datamodel_One ob2 = new datamodel_One("ধারাঃ ১৭৩","সমন বা নোটিস জারি করিতে বা লটকাইয়া দিতে বাধা দেওয়া বা লটকানোর পর উহা অপসারণ করা বা কোন হুলিয়া জারি করিতে বাধা দেওয়া ");
        dataholder_Thirteen.add(ob2);
        datamodel_One ob3 = new datamodel_One("ধারাঃ ১৭৪","কোন স্থানে ব্যক্তিগতভাবে বা প্রতিনিধি মারফত হাজির হওয়ার আইনসঙ্গত আদেশ অমান্য করা, বা বিনা অনুমতিতে সে স্থান ত্যাগ করা ");
        dataholder_Thirteen.add(ob3);
        datamodel_One ob4 = new datamodel_One("ধারাঃ ১৭৫","কোন ব্যক্তি আইনতঃ বাধ্য হওয়া সত্বেও কোন সরকারী কর্মচারীর নিকট ইচ্ছাকৃতভাবে কোন দলিল পেশ না করা ");
        dataholder_Thirteen.add(ob4);
        datamodel_One ob5 = new datamodel_One("ধারাঃ ১৭৬"," কোন ব্যক্তি আইনতঃ বাধ্য হওয়া সত্ত্বেও ইচ্ছাকৃতভাবে সরকারী কর্মচারীকে নোটিস বা খবর না দেওয়া");
        dataholder_Thirteen.add(ob5);
        datamodel_One ob6 = new datamodel_One("ধারাঃ ১৭৭","সরকারী কর্মচারীকে জ্ঞাতসারে মিথ্যা খবর দেওয়া ");
        dataholder_Thirteen.add(ob6);
        datamodel_One ob7 = new datamodel_One("ধারাঃ ১৭৮","সরকারী কর্মচারী কর্তৃক প্রয়োজনীয় শপথ গ্রহণ করিতে অস্বীকার করা ");
        dataholder_Thirteen.add(ob7);
        datamodel_One ob8 = new datamodel_One("ধারাঃ ১৭৯"," আইনতঃ সত্য বলিতে বাধ্য হওয়া সত্ত্বেও প্রশ্নের জবাব দিতে অস্বীকার করা");
        dataholder_Thirteen.add(ob8);
        datamodel_One ob9 = new datamodel_One("ধারাঃ ১৮০","আইনতঃ বাধ্য হওয়া সত্ত্বেও সরকারী কর্মচারীর নিকট দেওয়া বিবৃতি স্বাক্ষর করিতে অস্বীকার করা ");
        dataholder_Thirteen.add(ob9);
        datamodel_One ob10 = new datamodel_One("ধারাঃ ১৮১","সরকারী কর্মচারীর নিকট শপথপূর্বক জ্ঞাতসারে সত্য বলিয়া মিথ্যা বিবৃতি দেওয়া ");
        dataholder_Thirteen.add(ob10);

        datamodel_One ob11 = new datamodel_One("ধারাঃ ১৮২","  কোন ব্যক্তির ক্ষতি বা বিরক্তির নিমিত্ত কোন সরকারী কর্মচারীর আইনসঙ্গত ক্ষমতা প্রয়োগের জন্য তাহাকে মিথ্যা খবর দেওয়া");
        dataholder_Thirteen.add(ob11);
        datamodel_One ob12 = new datamodel_One("ধারাঃ ১৮৩","সরকারী কর্মচারীর আইনসঙ্গত কর্তৃত্ববলে সম্পত্তি গ্রহণে বাধা দেওয়া ");
        dataholder_Thirteen.add(ob12);
        datamodel_One ob13 = new datamodel_One("ধারাঃ ১৮৪","সরকারী কর্মচারীর কর্তৃত্ববলে বিক্রয়যোগ্য সম্পত্তি বিক্রয়ে বাধা দেওয়া ");
        dataholder_Thirteen.add(ob13);
        datamodel_One ob14 = new datamodel_One("ধারাঃ ১৮৫"," আইনতঃ অনুমোদিত নিলাম বিক্রয়ে আইনতঃ অপারগ ব্যক্তি কর্তৃক সম্পত্তির নিলাম ডাকা অথবা সংশ্লিষ্ট দায়িত্ব পালন না করিবার উদ্দেশ্য লইয়া নিলাম ডাকা ");
        dataholder_Thirteen.add(ob14);
        datamodel_One ob15 = new datamodel_One("ধারাঃ ১৮৬","  সরকারী কর্মচারীকে তাহার সরকারী কার্য সম্পাদনে বাধা দেওয়া");
        dataholder_Thirteen.add(ob15);
        datamodel_One ob16 = new datamodel_One("ধারাঃ ১৮৭","আইনতঃ বাধ্য হওয়া সত্ত্বেও সরকারী কর্মচারীকে সাহায্য না করা ");
        dataholder_Thirteen.add(ob16);
        datamodel_One ob17 = new datamodel_One("ধারাঃ ১৮৮","সরকারী কর্মচারী কর্তৃক আইনসঙ্গতভাবে জারিকৃত কোন আদেশ অমান্য করা");
        dataholder_Thirteen.add(ob17);
        datamodel_One ob18 = new datamodel_One("ধারাঃ ১৮৯","সরকারী কর্মচারীকে ক্ষতিসাধনের হুমকি");
        dataholder_Thirteen.add(ob18);
        datamodel_One ob19 = new datamodel_One("ধারাঃ ১৯০","কোন ব্যক্তিকে ক্ষতি হইতে রক্ষা পাইবার উদ্দেশ্যে আইনসঙ্গত দরখাস্ত না করিতে বাধ্য করিবার জন্য হুমকি দেওয়া ");
        dataholder_Thirteen.add(ob19);

     MyAdapter_Thirteen myAdapter_thirteen = new MyAdapter_Thirteen(dataholder_Thirteen);
     recyclerView_Thirteen.setAdapter(myAdapter_thirteen);


        return view;
    }
}