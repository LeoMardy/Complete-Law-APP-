package com.example.penalcodelowbangladesh;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;


public class Fragment_Seven extends Fragment {
    private RecyclerView recyclerView;
    private ArrayList<datamodel_One> dataholder_Seven = new ArrayList<>();
    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment__seven, container, false);
        recyclerView = view.findViewById(R.id.recyclerView2);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        datamodel_One ob1 = new datamodel_One("ধারাঃ ১২০-ক","অপরাধমূলক ষড়যন্ত্রের সংজ্ঞা");
        dataholder_Seven.add(ob1);
        datamodel_One ob2 = new datamodel_One("ধারাঃ ১২০-খ","অপরাধমূলক ষড়যন্ত্রের শাস্তি");
        dataholder_Seven.add(ob2);

        Myadpater_Seven myadpater_seven = new Myadpater_Seven(dataholder_Seven);
        recyclerView.setAdapter(myadpater_seven);

        return view;
    }
}