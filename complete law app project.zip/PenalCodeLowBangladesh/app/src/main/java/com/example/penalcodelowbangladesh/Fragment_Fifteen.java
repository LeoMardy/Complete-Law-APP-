package com.example.penalcodelowbangladesh;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;


public class Fragment_Fifteen extends Fragment {

    private RecyclerView recyclerViewFifteen;
    private ArrayList<datamodel_One> dataholder_Fifteen = new ArrayList<>();

    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View myView = inflater.inflate(R.layout.fragment__fifteen, container, false);
        recyclerViewFifteen = myView.findViewById(R.id.recyclerViewFifteen);
       recyclerViewFifteen.setLayoutManager(new LinearLayoutManager(getContext()));

     datamodel_One ok1 = new datamodel_One("ধারাঃ ২৩০","মুদ্রার সংজ্ঞা");
     dataholder_Fifteen.add(ok1);
        datamodel_One ok2 = new datamodel_One("ধারাঃ ২৩১","মুদ্রা জাল করা বা জাল করার পদ্ধতির কোন অংশ সম্পাদন করা");
        dataholder_Fifteen.add(ok2);
        datamodel_One ok3 = new datamodel_One("ধারাঃ ২৩২","বাংলাদেশের মুদ্রা জাল করা বা জাল করার পদ্ধতির কোন অংশ সম্পাদন করা");
        dataholder_Fifteen.add(ok3);
        datamodel_One ok4 = new datamodel_One("ধারাঃ ২৩৩","মুদ্রা জাল করার উদ্দেশ্যে যন্ত্রপাতি প্রস্তুত, ক্রয় বা বিক্রয় করা");
        dataholder_Fifteen.add(ok4);
        datamodel_One ok5 = new datamodel_One("ধারাঃ ২৩৪","বাংলাদেশের মুদ্রা জাল করার উদ্দেশ্যে যন্ত্রপাতি প্রস্তুত, ক্রয় বা বিক্রয় করা");
        dataholder_Fifteen.add(ok5);
        datamodel_One ok6 = new datamodel_One("ধারাঃ ২৩৫","মুদ্রা জাল করার উদ্দেশ্যে ব্যবহারের জন্য যন্ত্রপাতি বা দ্রব্যসামগ্রী দখলে রাখা");
        dataholder_Fifteen.add(ok6);
        datamodel_One ok7 = new datamodel_One("ধারাঃ ২৩৬","বাংলাদেশের বাহিবে মুদ্রা জাল করার জন্য বাংলাদেশে প্ররোচনা দেওয়া");
        dataholder_Fifteen.add(ok7);
        datamodel_One ok8 = new datamodel_One("ধারাঃ ২৩৭"," জাল বলিয়া জানা সত্ত্বেও জাল মুদ্রা আমদানি বা রফতানি করা");
        dataholder_Fifteen.add(ok8);
        datamodel_One ok9 = new datamodel_One("ধারাঃ ২৩৮","জাল বলিয়া জানা সত্ত্বেও জাল বাংলাদেশের মুদ্রা আমদানি বা রপ্তানি করা");
        dataholder_Fifteen.add(ok9);
        datamodel_One ok10 = new datamodel_One("ধারাঃ ২৩৯","যখন দখলে আসিয়াছিল তখন জাল বলিয়া জানা সত্ত্বেও জাল মুদ্রা দখলে রাখা এবং উহা কাহারও নিকট অর্পণ করা");
        dataholder_Fifteen.add(ok10);

        datamodel_One ok11 = new datamodel_One("ধারাঃ ২৪০","বাংলাদেশের মুদ্রা সম্পর্কে ঐরূপ অপরাধ করা");
        dataholder_Fifteen.add(ok11);
        datamodel_One ok12 = new datamodel_One("ধারাঃ ২৪১","যখন প্রথম দখলে আসিয়াছিল তখন জাল বলিয়া জানা ছিল না, কিন্তু পরে জাল বলিয়া জানা সত্ত্বেও উহা আসল বলিয়া অন্যের নিকট অর্পণ করা");
        dataholder_Fifteen.add(ok12);
        datamodel_One ok13 = new datamodel_One("ধারাঃ ২৪২","দখলে আসার সময় জাল বলিয়া জানা সত্ত্বেও কোন ব্যক্তি কর্তৃক জাল মুদ্রা দখলে রাখা");
        dataholder_Fifteen.add(ok13);
        datamodel_One ok14 = new datamodel_One("ধারাঃ ২৪৩","দখলে আসার সময় জাল বলিয়া জানা সত্ত্বেও কোন ব্যক্তি কর্তৃক জাল বাংলাদেশের মুদ্রা দখলে রাখা");
        dataholder_Fifteen.add(ok14);
        datamodel_One ok15 = new datamodel_One("ধারাঃ ২৪৪","টাকশালে নিযুক্ত ব্যক্তি কর্তৃক আইনে নির্ধারিত ওজন বা গঠন হইতে ভিন্নরূপ ওজন বা গঠনের মুদ্রা প্রস্তুত করা");
        dataholder_Fifteen.add(ok15);
        datamodel_One ok16 = new datamodel_One("ধারাঃ ২৪৫","টাকশাল হইতে মুদ্রা প্রস্তুত করার কোন যন্ত্র বেআইনীভাবে লইয়া যাওয়া");
        dataholder_Fifteen.add(ok16);
        datamodel_One ok17 = new datamodel_One("ধারাঃ ২৪৬","প্রতারণামূলকভাবে কোন মুদ্রার ওজন কম করা বা গঠন পরিবর্তন করা");
        dataholder_Fifteen.add(ok17);
        datamodel_One ok18 = new datamodel_One("ধারাঃ ২৪৭","প্রতারণামূলকভাবে বাংলাদেশের কোন মুদ্রার ওজন কম করা বা গঠন পরিবর্তন করা");
        dataholder_Fifteen.add(ok18);
        datamodel_One ok19 = new datamodel_One("ধারাঃ ২৪৮","ভিন্ন ধরণের মুদ্রা হিসাবে চালাইবার উদ্দেশ্যে কোন মুদ্রার আকৃতি পরিবর্তন করা");
        dataholder_Fifteen.add(ok19);
        datamodel_One ok20 = new datamodel_One("ধারাঃ ২৪৯","ভিন্ন ধরণের মুদ্রা হিসাবে চালাইবার উদ্দেশ্যে বাংলাদেশের মুদ্রার আকৃতি পরিবর্তন করা");
        dataholder_Fifteen.add(ok20);

        datamodel_One ok21 = new datamodel_One("ধারাঃ ২৫০","পরিবর্তিত বলিয়া জানা সত্ত্বেও কোন মুদ্রা অন্যের নিকট অর্পণ করা");
        dataholder_Fifteen.add(ok21);
        datamodel_One ok22 = new datamodel_One("ধারাঃ ২৫১","পরিবর্তিত বলিয়া জানা সত্ত্বেও বাংলাদেশের মুদ্রা অন্যের নিকট অর্পণ করা");
        dataholder_Fifteen.add(ok22);
        datamodel_One ok23 = new datamodel_One("ধারাঃ ২৫২","যখন দখলে আসিয়াছিল তখন পরিবর্তিত বলিয়া জানা সত্ত্বেও সেই মুদ্রা দখলে রাখা");
        dataholder_Fifteen.add(ok23);
        datamodel_One ok24 = new datamodel_One("ধারাঃ ২৫৩","যখন দখলে আসিয়াছিল তখন পরিবর্তিত বলিয়া জানা সত্ত্বেও বাংলাদেশের মুদ্রা বলিয়া দখলে রাখা");
        dataholder_Fifteen.add(ok24);
        datamodel_One ok25 = new datamodel_One("ধারাঃ ২৫৪","যখন দখলে আসিয়াছিল তখন পরিবর্তিত বলিয়া জানা থাকা সত্ত্বেও উহা প্রকৃত মুদ্রা বলিয়া অন্যের নিকট অর্পণ করা");
        dataholder_Fifteen.add(ok25);
        datamodel_One ok26 = new datamodel_One("ধারাঃ ২৫৫","সরকারী স্ট্যাম্প জাল করা");
        dataholder_Fifteen.add(ok26);
        datamodel_One ok27 = new datamodel_One("ধারাঃ ২৫৫-ক","সরকারী কর্মচারী কর্তৃক আইনত কোন ব্যক্তিকে গ্রেফতার না করে পলায়ন করতে দেয়া");
        dataholder_Fifteen.add(ok27);
        datamodel_One ok28 = new datamodel_One("ধারাঃ ২৫৬","সরকারী স্ট্যাম্প জাল করার উদ্দেশ্যে যন্ত্রপাতি বা দ্রব্যসামগ্রী দখলে রাখা");
        dataholder_Fifteen.add(ok28);
        datamodel_One ok29 = new datamodel_One("ধারাঃ ২৫৭","সরকারী স্ট্যাম্প জাল করার উদ্দেশ্যে যন্ত্রপাতি প্রস্তুত, ক্রয় বা বিক্রয় করা");
        dataholder_Fifteen.add(ok29);
        datamodel_One ok30 = new datamodel_One("ধারাঃ ২৫৮","জাল সরকারী স্ট্যাম্প বিক্রয় করা");
        dataholder_Fifteen.add(ok30);

        datamodel_One ok31 = new datamodel_One("ধারাঃ ২৫৯","জাল সরকারী স্ট্যাম্প দখলে রাখা");
        dataholder_Fifteen.add(ok31);
        datamodel_One ok32 = new datamodel_One("ধারাঃ ২৬০","জালকৃত বলিয়া জানিয়াও তাহা সরকারী স্ট্যাম্প বলিয়া ব্যবহার করা");
        dataholder_Fifteen.add(ok32);
        datamodel_One ok33 = new datamodel_One("ধারাঃ ২৬১","সরকারী স্ট্যাম্পযুক্ত কোন বস্তু হইতে কোন লেখা তুলিয়া ফেলা বা সরকারের ক্ষতিসাধনের উদ্দেশ্যে কোন স্ট্যাম্প অপসারণ করা");
        dataholder_Fifteen.add(ok33);
        datamodel_One ok34 = new datamodel_One("ধারাঃ ২৬২","পূর্বে ব্যবহৃত হইয়াছে বলিয়া জানিয়াও সরকারী স্ট্যাম্প ব্যবহার করা");
        dataholder_Fifteen.add(ok34);
        datamodel_One ok35 = new datamodel_One("ধারাঃ ২৬৩","স্ট্যাম্প ব্যবহৃত হওয়ার চিহ্ন তুলিয়া ফেলা");
        dataholder_Fifteen.add(ok35);
        datamodel_One ok36 = new datamodel_One("ধারাঃ ২৬৩-ক","অসত্য ষ্ট্যাম্প নিষিদ্ধকরণ");
        dataholder_Fifteen.add(ok36);



    MyAdapter_Fifteen myAdapter_fifteen = new MyAdapter_Fifteen(dataholder_Fifteen);
    recyclerViewFifteen.setAdapter(myAdapter_fifteen);

        return myView;
    }
}