package com.example.penalcodelowbangladesh;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textview.MaterialTextView;

import java.util.ArrayList;


public class Fragment_Eighteen extends Fragment {

   RecyclerView recycerView_Eighteen;
   ArrayList<datamodel_One> dataholder_eighteen = new ArrayList<>();
    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment__eighteen, container, false);
        recycerView_Eighteen = view.findViewById(R.id.recycerView_Eighteen);
        recycerView_Eighteen.setLayoutManager(new LinearLayoutManager(getContext()));

        datamodel_One ob1 = new datamodel_One("ধারাঃ ২৯৫"," কোন শ্রেণীর লোকের ধর্মের অবমাননার উদ্দেশ্যে কোন উপাসনার স্থান বা পবিত্র বস্তু ধ্বংস, নষ্ট বা অপবিত্র করা");
        dataholder_eighteen.add(ob1);
        datamodel_One ob2 = new datamodel_One("ধারাঃ ২৯৫-ক","প্রতিহিংসাবশতঃ কোন শ্রেণীর লোকের ধর্ম বা ধর্মীয় বিশ্বাসের অবমাননা করা");
        dataholder_eighteen.add(ob2);
        datamodel_One ob3 =new datamodel_One("ধারাঃ ২৯৬","ধর্মীয় উপসনায় রত কোন সমাবেশে গোলযোগ সৃষ্টি করা");
        dataholder_eighteen.add(ob3);
        datamodel_One ob4 =new datamodel_One("ধারাঃ ২৯৭","গোরস্থান ইত্যাদিতে অনধিকার প্রবেশ");
        dataholder_eighteen.add(ob4);
        datamodel_One ob5 = new datamodel_One("ধারাঃ ২৯৮"," কোন ব্যক্তির ধর্মীয় অনুভূতিতে আঘাত করার উদ্দেশ্যে তাহার শ্রবণের মধ্যে কোন কথা উচ্চারণ করা বা কোন শব্দ করা অথবা তাহার দৃষ্টিগোচর কোন অংগভংগি করা বা কোন বস্তু স্থাপন করা");
        dataholder_eighteen.add(ob5);


        MyAdapter_Eighteen myAdapter_eighteen = new MyAdapter_Eighteen(dataholder_eighteen);
        recycerView_Eighteen.setAdapter(myAdapter_eighteen);
        return view;
    }
    public static class MyAdapter_Eighteen extends RecyclerView.Adapter<MyAdapter_Eighteen.MyViewHolder>{
        protected static class MyViewHolder extends RecyclerView.ViewHolder{
           MaterialTextView recycler_TextViewHeader_18,recycler_TextViewDesc_18;
           MaterialCardView recycler_CardView_18;
            public MyViewHolder(@NonNull View itemView) {
                super(itemView);
                recycler_TextViewDesc_18 = itemView.findViewById(R.id.recycler_TextViewDesc);
                recycler_TextViewHeader_18 = itemView.findViewById(R.id.recycler_TextViewHeader);
                recycler_CardView_18 = itemView.findViewById(R.id.recycler_CardView);
            }
        }
        ArrayList<datamodel_One> dataholder_eighteen;

        public MyAdapter_Eighteen(ArrayList<datamodel_One> dataholder_eighteen) {
            this.dataholder_eighteen = dataholder_eighteen;
        }

        @NonNull
        @Override
        public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View myView  = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_xml_design_one,parent,false);

            return new MyViewHolder(myView);
        }

        @Override
        public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
            holder.recycler_TextViewHeader_18.setText(dataholder_eighteen.get(position).getHeader());
            holder.recycler_TextViewDesc_18.setText(dataholder_eighteen.get(position).getDesc());
            holder.recycler_CardView_18.setOnClickListener(v -> {

                if (position == 0) {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_One_Fragment_Eighteen()).addToBackStack(null).commit();

                } else if (position==1) {
                    AppCompatActivity activity1 = (AppCompatActivity) v.getContext();
                    activity1.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Two_Fragment_Eighteen()).addToBackStack(null).commit();


                } else if (position==2) {
                    AppCompatActivity activity2= (AppCompatActivity) v.getContext();
                    activity2.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Three_Fragment_Eighteen()).addToBackStack(null).commit();


                } else if (position==3) {
                    AppCompatActivity activity3 = (AppCompatActivity) v.getContext();
                    activity3.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Four_Fragment_Eighteen()).addToBackStack(null).commit();


                } else if (position==4) {
                    AppCompatActivity activity4 = (AppCompatActivity) v.getContext();
                    activity4.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Five_Fragment_Eighteen()).addToBackStack(null).commit();


                }

            });

        }

        @Override
        public int getItemCount() {
            return 5;
        }

    }
}