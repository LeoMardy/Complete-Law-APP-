package com.example.penalcodelowbangladesh;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textview.MaterialTextView;

import java.util.ArrayList;


public class Fragment_FourtyThree extends Fragment {

    RecyclerView recyclerView_43;
    ArrayList<datamodel_One> dataholder_43 = new ArrayList<>();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment__fourty_three, container, false);
        recyclerView_43= view.findViewById(R.id.recyclerView_43);
        recyclerView_43.setLayoutManager(new LinearLayoutManager(getContext()));

        datamodel_One ok1 = new datamodel_One("ধারাঃ ৫১১","যাবজ্জীবন কারাদন্ডে বা কারাদন্ডে দন্ডনীয় অপরাধসমূহ সংঘটনের উদ্যেগের শাস্তি");
        dataholder_43.add(ok1);


        MyAdapter_43 myAdapter_43 = new MyAdapter_43(dataholder_43);
        recyclerView_43.setAdapter(myAdapter_43);

        return view;
    }

    public static class MyAdapter_43 extends RecyclerView.Adapter<MyAdapter_43.MyViewHolder_43>{
        protected static class MyViewHolder_43 extends RecyclerView.ViewHolder{

            MaterialCardView materialCardView_43;
            MaterialTextView materialTextView_Header_43, materialTextView_Desc_43;
            public MyViewHolder_43(@NonNull View itemView) {
                super(itemView);
                materialCardView_43 = itemView.findViewById(R.id.recycler_CardView);
                materialTextView_Desc_43 = itemView.findViewById(R.id.recycler_TextViewDesc);
                materialTextView_Header_43 = itemView.findViewById(R.id.recycler_TextViewHeader);
            }
        }
        ArrayList<datamodel_One> dataholder_43;

        public MyAdapter_43(ArrayList<datamodel_One> dataholder_43) {
            this.dataholder_43 = dataholder_43;
        }

        @NonNull
        @Override
        public MyViewHolder_43 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

            View view =LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_xml_design_one,parent,false);

            return new MyViewHolder_43(view);

        }

        @Override
        public void onBindViewHolder(@NonNull MyViewHolder_43 holder, int position) {

            holder.materialTextView_Header_43.setText(dataholder_43.get(position).getHeader());
            holder.materialTextView_Desc_43.setText(dataholder_43.get(position).getDesc());
            holder.materialCardView_43.setOnClickListener(v -> {


                if (position == 0) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_One_Fragment_FourtyThree()).addToBackStack(null).commit();


                }

            });

        }

        @Override
        public int getItemCount() {
            return 1;
        }
    }
}