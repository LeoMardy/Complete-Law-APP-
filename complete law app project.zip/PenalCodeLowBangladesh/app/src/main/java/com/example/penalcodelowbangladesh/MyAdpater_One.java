package com.example.penalcodelowbangladesh;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textview.MaterialTextView;

import java.util.ArrayList;

public class MyAdpater_One extends RecyclerView.Adapter<MyAdpater_One.MyViewHolder_One> {
    protected static class MyViewHolder_One extends RecyclerView.ViewHolder{
      final MaterialCardView materialCardView;
      final MaterialTextView materialTextView_Header,materialTextView_Desc;
        public MyViewHolder_One(@NonNull View itemView) {
            super(itemView);
            materialCardView = itemView.findViewById(R.id.recycler_CardView);
            materialTextView_Header = itemView.findViewById(R.id.recycler_TextViewHeader);
            materialTextView_Desc = itemView.findViewById(R.id.recycler_TextViewDesc);
        }
    }
    ArrayList<datamodel_One> dataholder_One;

    public MyAdpater_One(ArrayList<datamodel_One> datamodel_ones) {
        this.dataholder_One = datamodel_ones;
    }

    @NonNull
    @Override
    public MyViewHolder_One onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View myView = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_xml_design_one,parent,false);
        return new MyViewHolder_One(myView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder_One holder, @SuppressLint("RecyclerView") int position) {
     holder.materialTextView_Header.setText(dataholder_One.get(position).getHeader());
     holder.materialTextView_Desc.setText(dataholder_One.get(position).getDesc());

     holder.materialCardView.setOnClickListener(v -> {
      switch (position){
          case 0:
              AppCompatActivity compatActivity = (AppCompatActivity) v.getContext();
              compatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_One_Fragment()).addToBackStack(null).commit();
              break;
          case 1:
              AppCompatActivity activity1 = (AppCompatActivity) v.getContext();
              activity1.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Two_Fragment()).addToBackStack(null).commit();
              break;
          case 2:
              AppCompatActivity activity2 = (AppCompatActivity) v.getContext();
              activity2.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Three_Fragment()).addToBackStack(null).commit();
              break;
          case 3:
              AppCompatActivity activity3 = (AppCompatActivity) v.getContext();
              activity3.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Four_Fragment()).addToBackStack(null).commit();
              break;
          default:
              AppCompatActivity activity4 = (AppCompatActivity) v.getContext();
              activity4.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Five_Fragment()).addToBackStack(null).commit();
              break;
      }
     });

    }

    @Override
    public int getItemCount() {
        return 5;
    }
}
