package com.example.penalcodelowbangladesh;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textview.MaterialTextView;

import java.util.ArrayList;


public class Fragment_Thirty extends Fragment {

    RecyclerView recyclerView_30;
    ArrayList<datamodel_One> dataholder_30 = new ArrayList<>();


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment__thirty, container, false);
        recyclerView_30 = view.findViewById(R.id.recyclerView_30);
        recyclerView_30.setLayoutManager(new LinearLayoutManager(getContext()));


        datamodel_One o1 = new datamodel_One("ধারাঃ ৪০৩","অসাধুভাবে সম্পত্তি আত্মসাৎকরণ");
        dataholder_30.add(o1);
        datamodel_One o2 = new datamodel_One("ধারাঃ ৪০৪","মৃত ব্যক্তির মৃত্যুকালে তাহার দখলভুক্ত সম্পত্তি অসাধুভাবে আত্মসাৎকরণ");
        dataholder_30.add(o2);


MyAdpater_30 myAdpater_30 = new MyAdpater_30(dataholder_30);
recyclerView_30.setAdapter(myAdpater_30);

        return view;
    }


    public static class MyAdpater_30 extends RecyclerView.Adapter<MyAdpater_30.MyViewHolder_30>{
        protected static class MyViewHolder_30 extends RecyclerView.ViewHolder{

            MaterialCardView materialCardView_30;
            MaterialTextView materialTextView_Header_30, materialTextView_Desc_30;

            public MyViewHolder_30(@NonNull View itemView) {
                super(itemView);

                materialCardView_30 = itemView.findViewById(R.id.recycler_CardView);
                materialTextView_Header_30 = itemView.findViewById(R.id.recycler_TextViewHeader);
                materialTextView_Desc_30 = itemView.findViewById(R.id.recycler_TextViewDesc);

            }
        }

        ArrayList<datamodel_One> dataholder_30 ;

        public MyAdpater_30(ArrayList<datamodel_One> dataholder_30) {
            this.dataholder_30 = dataholder_30;
        }

        @NonNull
        @Override
        public MyViewHolder_30 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_xml_design_one,parent,false);

            return new MyViewHolder_30(view);
        }

        @Override
        public void onBindViewHolder(@NonNull MyViewHolder_30 holder, int position) {

            holder.materialTextView_Desc_30.setText(dataholder_30.get(position).getDesc());
            holder.materialTextView_Header_30.setText(dataholder_30.get(position).getHeader());
            holder.materialCardView_30.setOnClickListener(v -> {


                if (position == 0) {
                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_One_Fragment_Thirty()).addToBackStack(null).commit();

                } else  {

                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Two_Fragment_Thirty()).addToBackStack(null).commit();

                }

            });

        }

        @Override
        public int getItemCount() {
            return 2;
        }
    }
}