package com.example.penalcodelowbangladesh;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textview.MaterialTextView;

import java.util.ArrayList;

public class Fragment_TwentyNine extends Fragment {

RecyclerView recyclerView_29;
ArrayList<datamodel_One> dataholder_29 = new ArrayList<>();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment__twenty_nine, container, false);
        recyclerView_29 = view.findViewById(R.id.recyclerView_29);
        recyclerView_29.setLayoutManager(new LinearLayoutManager(getContext()));


        datamodel_One oj1 =new datamodel_One("ধারাঃ ৩৯০","যেক্ষেত্রে চুরি দস্যুতা বলিয়া গণ্য হয়");
        dataholder_29.add(oj1);
        datamodel_One oj2 =new datamodel_One("ধারাঃ ৩৯১","ডাকাতি");
        dataholder_29.add(oj2);
        datamodel_One oj3 =new datamodel_One("ধারাঃ ৩৯২","দস্যুতার শাস্তি।");
        dataholder_29.add(oj3);
        datamodel_One oj4 =new datamodel_One("ধারাঃ ৩৯৩","দস্যূতা অনুষ্ঠানের উদ্যোগ");
        dataholder_29.add(oj4);
        datamodel_One oj5 =new datamodel_One("ধারাঃ ৩৯৪","দস্যুবৃত্তি অনুষ্ঠানকালে স্বেচ্ছাকৃতভাবে আঘাত দান");
        dataholder_29.add(oj5);
        datamodel_One oj6 =new datamodel_One("ধারাঃ ৩৯৫","ডাকাতির শাস্তি");
        dataholder_29.add(oj6);
        datamodel_One oj7 =new datamodel_One("ধারাঃ ৩৯৬","খুনসহকারে ডাকাতি");
        dataholder_29.add(oj7);
        datamodel_One oj8 =new datamodel_One("ধারাঃ ৩৯৭","মৃত্যু বা গুরুতর আঘাত সংঘটনের উদ্যোগ সহকারে দস্যুতা বা ডাকাতি");
        dataholder_29.add(oj8);
        datamodel_One oj9 =new datamodel_One("ধারাঃ ৩৯৮","মারাত্মক অস্ত্রে সজ্জিত অবস্থায় দস্যুতা বা ডাকাতি করিবার উগ্যোগ");
        dataholder_29.add(oj9);
        datamodel_One oj10 =new datamodel_One("ধারাঃ ৩৯৯","ডাকাতি অনুষ্ঠানের প্রস্তুতি গ্রহণ");
        dataholder_29.add(oj10);
        datamodel_One oj11 =new datamodel_One("ধারাঃ ৪০০","ডাকাত দলভুক্ত হইবার শাস্তি");
        dataholder_29.add(oj11);
        datamodel_One oj12 =new datamodel_One("ধারাঃ ৪০১","চোরদের দলভুক্ত হইবার শাস্তি");
        dataholder_29.add(oj12);
        datamodel_One oj13 =new datamodel_One("ধারাঃ ৪০২","ডাকাতি অনুষ্ঠানের উদ্দেশ্যে সমবেত হওয়া");
        dataholder_29.add(oj13);


MyAdapter_29 myAdapter_29 = new MyAdapter_29(dataholder_29);
recyclerView_29.setAdapter(myAdapter_29);

        return view;
    }
    public static class MyAdapter_29 extends RecyclerView.Adapter<MyAdapter_29.MyViewHolder_29>{
        protected static class MyViewHolder_29 extends RecyclerView.ViewHolder{

            MaterialCardView materialCardView_29;
            MaterialTextView materialTextView_Header_29, materialTextView_Desc_29;
            public MyViewHolder_29(@NonNull View itemView) {
                super(itemView);

                materialCardView_29 = itemView.findViewById(R.id.recycler_CardView);
                materialTextView_Desc_29  = itemView.findViewById(R.id.recycler_TextViewDesc);
                materialTextView_Header_29 = itemView.findViewById(R.id.recycler_TextViewHeader);
            }
        }
        ArrayList<datamodel_One> dataholder_29 ;

        public MyAdapter_29(ArrayList<datamodel_One> dataholder_29) {
            this.dataholder_29 = dataholder_29;
        }

        @NonNull
        @Override
        public MyViewHolder_29 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_xml_design_one,parent,false);

            return new MyViewHolder_29(view);
        }

        @Override
        public void onBindViewHolder(@NonNull MyViewHolder_29 holder, int position) {
        holder.materialTextView_Header_29.setText(dataholder_29.get(position).getHeader());
        holder.materialTextView_Desc_29.setText(dataholder_29.get(position).getDesc());
        holder.materialCardView_29.setOnClickListener(v -> {


            if (position == 0) {

                AppCompatActivity activity = (AppCompatActivity) v.getContext();
                activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_One_Fragment_TwentyNine()).addToBackStack(null).commit();

            } else if (position==1) {
                AppCompatActivity activity = (AppCompatActivity) v.getContext();
                activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Two_Fragment_TwentyNine_mistake()).addToBackStack(null).commit();


            }else if (position==2) {
                AppCompatActivity activity = (AppCompatActivity) v.getContext();
                activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Two_Fragment_TwentyNine()).addToBackStack(null).commit();


            }else if (position==3) {
                AppCompatActivity activity = (AppCompatActivity) v.getContext();
                activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Three_Fragment_TwentyNine()).addToBackStack(null).commit();


            }else if (position==4) {
                AppCompatActivity activity = (AppCompatActivity) v.getContext();
                activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Four_Fragment_twentyNine()).addToBackStack(null).commit();


            }else if (position==5) {
                AppCompatActivity activity = (AppCompatActivity) v.getContext();
                activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Five_Fragment_TwentyNine()).addToBackStack(null).commit();


            }else if (position==6) {
                AppCompatActivity activity = (AppCompatActivity) v.getContext();
                activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Six_Fragment_TwentyNine()).addToBackStack(null).commit();


            }else if (position==7) {
                AppCompatActivity activity = (AppCompatActivity) v.getContext();
                activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Seven_Fragment_TwentyNine()).addToBackStack(null).commit();


            }else if (position==8) {
                AppCompatActivity activity = (AppCompatActivity) v.getContext();
                activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Eight_Fragment_TwentyNIne()).addToBackStack(null).commit();


            }else if (position==9) {
                AppCompatActivity activity = (AppCompatActivity) v.getContext();
                activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Nine_Fragment_TwentyNine()).addToBackStack(null).commit();


            }else if (position==10) {
                AppCompatActivity activity = (AppCompatActivity) v.getContext();
                activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Ten_Fragment_TwentyNine()).addToBackStack(null).commit();


            }else if (position==11) {
                AppCompatActivity activity = (AppCompatActivity) v.getContext();
                activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Eleven_Fragment_TwentyNine()).addToBackStack(null).commit();


            }else  {
                AppCompatActivity activity = (AppCompatActivity) v.getContext();
                activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Twelve_Fragment_TwentyNine()).addToBackStack(null).commit();


            }


        });
        }

        @Override
        public int getItemCount() {
            return 13;
        }

    }
}