package com.example.penalcodelowbangladesh;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textview.MaterialTextView;

import java.util.ArrayList;

public class MyAdpater_Eleven extends RecyclerView.Adapter<MyAdpater_Eleven.MyViewHolder_Eleven> {
    protected static class MyViewHolder_Eleven extends RecyclerView.ViewHolder{
       final private MaterialTextView recyclerViewText_HeaderID, recyclerviewText_DescID;
       final private MaterialCardView recyclerCardView_ID;

        public MyViewHolder_Eleven(@NonNull View itemView) {
            super(itemView);
            recyclerViewText_HeaderID = itemView.findViewById(R.id.recycler_TextViewHeader);
            recyclerviewText_DescID = itemView.findViewById(R.id.recycler_TextViewDesc);
            recyclerCardView_ID = itemView.findViewById(R.id.recycler_CardView);
        }
    }
    ArrayList<datamodel_One> dataholder_eleven;

    public MyAdpater_Eleven(ArrayList<datamodel_One> dataholder_eleven) {
        this.dataholder_eleven = dataholder_eleven;
    }

    @NonNull
    @Override
    public MyViewHolder_Eleven onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View myView = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_xml_design_one,parent,false);
        return new MyViewHolder_Eleven(myView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder_Eleven holder, @SuppressLint("RecyclerView") int position) {
    holder.recyclerViewText_HeaderID.setText(dataholder_eleven.get(position).getHeader());
    holder.recyclerviewText_DescID.setText(dataholder_eleven.get(position).getDesc());
    holder.recyclerCardView_ID.setOnClickListener(v -> {
        switch (position){
            case 0:
               AppCompatActivity activity = (AppCompatActivity) v.getContext();
               activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_One_Fragment_Eleven()).addToBackStack(null).commit();
               break;
            case 1:
                AppCompatActivity activity1 = (AppCompatActivity) v.getContext();
                activity1.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Two_Fragment_Eleven()).addToBackStack(null).commit();
                break;
            case 2:
                AppCompatActivity activity2 = (AppCompatActivity) v.getContext();
                activity2.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_three_Fragment_Eleven()).addToBackStack(null).commit();
                break;
            case 3:
                AppCompatActivity activity3 = (AppCompatActivity) v.getContext();
                activity3.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_four_Fragment_Eleven()).addToBackStack(null).commit();
                break;
            case 4:
                AppCompatActivity activity4 = (AppCompatActivity) v.getContext();
                activity4.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_five_Fragment_Eleven()).addToBackStack(null).commit();
                break;
            case 5:
                AppCompatActivity activity5 = (AppCompatActivity) v.getContext();
                activity5.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_six_Fragment_Eleven()).addToBackStack(null).commit();
                break;
            case 6:
                AppCompatActivity activity6 = (AppCompatActivity) v.getContext();
                activity6.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_seven_Fragment_Eleven()).addToBackStack(null).commit();
                break;
            case 7:
                AppCompatActivity activity7 = (AppCompatActivity) v.getContext();
                activity7.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_eight_Fragment_Eleven()).addToBackStack(null).commit();
                break;
            case 8:
                AppCompatActivity activity8 = (AppCompatActivity) v.getContext();
                activity8.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_nine_Fragment_Eleven()).addToBackStack(null).commit();
                break;
            case 9:
                AppCompatActivity activity9 = (AppCompatActivity) v.getContext();
                activity9.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_ten_Fragment_Eleven()).addToBackStack(null).commit();
                break;
            case 10:
                AppCompatActivity activity10 = (AppCompatActivity) v.getContext();
                activity10.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_eleven_Fragment_Eleven()).addToBackStack(null).commit();
                break;
            case 11:
                AppCompatActivity activity11 = (AppCompatActivity) v.getContext();
                activity11.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_twelve_Fragment_Eleven()).addToBackStack(null).commit();
                break;
            default:
                AppCompatActivity activity12 = (AppCompatActivity) v.getContext();
                activity12.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_thirteen_Fragment_Eleven()).addToBackStack(null).commit();
                break;

        }
    });
    }

    @Override
    public int getItemCount() {
        return 13;
    }
}
