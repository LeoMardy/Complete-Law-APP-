package com.example.penalcodelowbangladesh;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textview.MaterialTextView;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;


public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {
    protected static class MyViewHolder extends RecyclerView.ViewHolder{
        final private MaterialCardView recycler_CardView;
     //   final private CircleImageView recycler_ImageViewID;
        final private MaterialTextView recycler_TextViewHeader, recycler_TextViewDesc;
        final private CircleImageView circularImage;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            recycler_CardView = itemView.findViewById(R.id.recycler_CardView);
            circularImage= itemView.findViewById(R.id.circularImage);
            recycler_TextViewHeader = itemView.findViewById(R.id.recycler_TextViewHeader);
            recycler_TextViewDesc = itemView.findViewById(R.id.recycler_TextViewDesc);
        }
    }
    ArrayList<datamodel> dataholder;

    public MyAdapter(ArrayList<datamodel> dataholder) {
        this.dataholder = dataholder;
    }
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View myView = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_xml_design,parent,false);
        return new MyViewHolder(myView);
    }
    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") int position) {
    holder.circularImage.setImageResource(dataholder.get(position).getImage());
    holder.recycler_TextViewHeader.setText(dataholder.get(position).getDataHeader());
    holder.recycler_TextViewDesc.setText(dataholder.get(position).getDesc());

    holder.recycler_CardView.setOnClickListener(v -> {
        switch (position){
            case 0:
                AppCompatActivity activity = (AppCompatActivity) v.getContext();
                activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Fragment_One()).addToBackStack(null).commit();
                break;
           case 1:
                AppCompatActivity activity2 = (AppCompatActivity) v.getContext();
                activity2.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Fragment_Two()).addToBackStack(null).commit();
                break;
            case 2:
                AppCompatActivity activity3 = (AppCompatActivity) v.getContext();
                activity3.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Fragment_Three()).addToBackStack(null).commit();
                break;
            case 3:
                AppCompatActivity activity4 = (AppCompatActivity) v.getContext();
                activity4.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Fragment_Four()).addToBackStack(null).commit();
                break;
            case 4:
                AppCompatActivity activity5 = (AppCompatActivity) v.getContext();
                activity5.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Fragment_Five()).addToBackStack(null).commit();
                break;
            case 5:
                AppCompatActivity activity6 = (AppCompatActivity) v.getContext();
                activity6.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Fragment_Six()).addToBackStack(null).commit();
                break;
            case 6:
                AppCompatActivity activity7 = (AppCompatActivity) v.getContext();
                activity7.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Fragment_Seven()).addToBackStack(null).commit();
                break;
            case 7:
                AppCompatActivity activity8 = (AppCompatActivity) v.getContext();
                activity8.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Fragment_Eight()).addToBackStack(null).commit();
                break;
            case 8:
                AppCompatActivity activity9 = (AppCompatActivity) v.getContext();
                activity9.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Fragment_Nine()).addToBackStack(null).commit();
                break;
            case 9:
                AppCompatActivity activity10 = (AppCompatActivity) v.getContext();
                activity10.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Fragment_Ten()).addToBackStack(null).commit();
                break;
            case 10:
                AppCompatActivity activity11 = (AppCompatActivity) v.getContext();
                activity11.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Fragment_Eleven()).addToBackStack(null).commit();
                break;
            case 11:
                AppCompatActivity activity12 = (AppCompatActivity) v.getContext();
                activity12.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Fragment_Twelve()).addToBackStack(null).commit();
                break;
            case 12:
                AppCompatActivity activity13 = (AppCompatActivity) v.getContext();
                activity13.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Fragment_Thirteen()).addToBackStack(null).commit();
                break;
            case 13:
                AppCompatActivity activity14 = (AppCompatActivity) v.getContext();
                activity14.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Fragment_Fourteen()).addToBackStack(null).commit();
                break;
            case 14:
                AppCompatActivity activity15 = (AppCompatActivity) v.getContext();
                activity15.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Fragment_Fifteen()).addToBackStack(null).commit();
                break;
            case 15:
                AppCompatActivity activity16 = (AppCompatActivity) v.getContext();
                activity16.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Fragment_Sixteen()).addToBackStack(null).commit();
                break;
            case 16:
                AppCompatActivity activity17 = (AppCompatActivity) v.getContext();
                activity17.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Fragment_Seventeen()).addToBackStack(null).commit();
                break;
            case 17:
                AppCompatActivity activity18 = (AppCompatActivity) v.getContext();
                activity18.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Fragment_Eighteen()).addToBackStack(null).commit();
                break;
            case 18:
                AppCompatActivity activity19 = (AppCompatActivity) v.getContext();
                activity19.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Fragment_Nineteen()).addToBackStack(null).commit();
                break;
            case 19:
                AppCompatActivity activity20 = (AppCompatActivity) v.getContext();
                activity20.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Fragment_Twenty()).addToBackStack(null).commit();
                break;
            case 20:
                AppCompatActivity activity21 = (AppCompatActivity) v.getContext();
                activity21.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Fragment_TwentyOne()).addToBackStack(null).commit();
                break;
            case 21:
                AppCompatActivity activity22 = (AppCompatActivity) v.getContext();
                activity22.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Fragment_TwentyTwo()).addToBackStack(null).commit();
                break;
            case 22:
                AppCompatActivity activity23 = (AppCompatActivity) v.getContext();
                activity23.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Fragment_TwentyThree()).addToBackStack(null).commit();
                break;
            case 23:
                AppCompatActivity activity24 = (AppCompatActivity) v.getContext();
                activity24.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Fragment_TwentyFour()).addToBackStack(null).commit();
                break;
            case 24:
                AppCompatActivity activity25 = (AppCompatActivity) v.getContext();
                activity25.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Fragment_TwentyFive()).addToBackStack(null).commit();
                break;
            case 25:
                AppCompatActivity activity26 = (AppCompatActivity) v.getContext();
                activity26.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Fragment_twentySix()).addToBackStack(null).commit();
                break;
            case 26:
                AppCompatActivity activity27 = (AppCompatActivity) v.getContext();
                activity27.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Fragment_TwentySeven()).addToBackStack(null).commit();
                break;
            case 27:
                AppCompatActivity activity28 = (AppCompatActivity) v.getContext();
                activity28.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Fragment_TwentyEight()).addToBackStack(null).commit();
                break;
            case 28:
                AppCompatActivity activity29 = (AppCompatActivity) v.getContext();
                activity29.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Fragment_TwentyNine()).addToBackStack(null).commit();
                break;
            case 29:
                AppCompatActivity activity30 = (AppCompatActivity) v.getContext();
                activity30.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Fragment_Thirty()).addToBackStack(null).commit();
                break;
            case 30:
                AppCompatActivity activity31 = (AppCompatActivity) v.getContext();
                activity31.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Fragment_ThirtyOne()).addToBackStack(null).commit();
                break;
            case 31:
                AppCompatActivity activity32 = (AppCompatActivity) v.getContext();
                activity32.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Fragment_ThirtyTwo()).addToBackStack(null).commit();
                break;
            case 32:
                AppCompatActivity activity33 = (AppCompatActivity) v.getContext();
                activity33.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Fragment_ThirtyThree()).addToBackStack(null).commit();
                break;
            case 33:
                AppCompatActivity activity34 = (AppCompatActivity) v.getContext();
                activity34.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Fragment_ThirtyFour()).addToBackStack(null).commit();
                break;
            case 34:
                AppCompatActivity activity35 = (AppCompatActivity) v.getContext();
                activity35.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Fragment_ThirtyFive()).addToBackStack(null).commit();
                break;
            case 35:
                AppCompatActivity activity36 = (AppCompatActivity) v.getContext();
                activity36.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Fragment_ThirtySix()).addToBackStack(null).commit();
                break;
            case 36:
                AppCompatActivity activity37 = (AppCompatActivity) v.getContext();
                activity37.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Fragment_ThirtySeven()).addToBackStack(null).commit();
                break;
            case 37:
                AppCompatActivity activity38 = (AppCompatActivity) v.getContext();
                activity38.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Fragment_ThirtyEight()).addToBackStack(null).commit();
                break;
            case 38:
                AppCompatActivity activity39 = (AppCompatActivity) v.getContext();
                activity39.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Fragment_ThirtyNine()).addToBackStack(null).commit();
                break;
            case 39:
                AppCompatActivity activity40 = (AppCompatActivity) v.getContext();
                activity40.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Fragment_Fourty()).addToBackStack(null).commit();
                break;
            case 40:
                AppCompatActivity activity41 = (AppCompatActivity) v.getContext();
                activity41.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Fragment_FourtyOne()).addToBackStack(null).commit();
                break;
            case 41:
                AppCompatActivity activity42 = (AppCompatActivity) v.getContext();
                activity42.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Fragment_FourtyTwo()).addToBackStack(null).commit();
                break;
            case 42:
                AppCompatActivity activity43 = (AppCompatActivity) v.getContext();
                activity43.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Fragment_FourtyThree()).addToBackStack(null).commit();
                break;

        }

    });
    }
    @Override
    public int getItemCount() {
        return 43;
    }
}
