package com.example.penalcodelowbangladesh;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textview.MaterialTextView;

import java.util.ArrayList;

public class Fragment_ThirtyTwo extends Fragment {

    RecyclerView recyclerView_32;
    ArrayList<datamodel_One> dataholder_32 = new ArrayList<>();


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment__thirty_two, container, false);

         recyclerView_32 = view.findViewById(R.id.recyclerView_32);
         recyclerView_32.setLayoutManager(new LinearLayoutManager(getContext()));


         datamodel_One k1 = new datamodel_One("ধারাঃ ৪১০"," চোরাইমাল");
         dataholder_32.add(k1);
        datamodel_One k2 = new datamodel_One("ধারাঃ ৪১১"," অসাধুভাবে চোরাইমাল গ্রহণ করা");
        dataholder_32.add(k2);
        datamodel_One k3 = new datamodel_One("ধারাঃ ৪১২","ডাকাতি অনুষ্ঠানের মাধ্যমে অপহৃত মাল অসাধুভাবে গ্রহণ করা");
        dataholder_32.add(k3);
        datamodel_One k4 = new datamodel_One("ধারাঃ ৪১৩"," অভ্যাসগতভাবে চোরাইমাল বেচাকেনা করা");
        dataholder_32.add(k4);
        datamodel_One k5 = new datamodel_One("ধারাঃ ৪১৪"," চোরাইমাল গোপন করিবার ব্যাপারে সহায়তাকরণ");
        dataholder_32.add(k5);
        datamodel_One k6 = new datamodel_One("ধারাঃ ৪১৫"," প্রতারণা");
        dataholder_32.add(k6);
        datamodel_One k7 = new datamodel_One("ধারাঃ ৪১৬"," অপরের রূপ ধারণপূর্বক প্রতারণা");
        dataholder_32.add(k7);
        datamodel_One k8 = new datamodel_One("ধারাঃ ৪১৭"," প্রতারণার শাস্তি");
        dataholder_32.add(k8);
        datamodel_One k9 = new datamodel_One("ধারাঃ ৪১৮","অপরাধকারী যে ব্যক্তির স্বার্থ রক্ষা করিতে বাধ্য, সেই ব্যক্তির কোন অন্যায় ক্ষতি সাধিত হইতে পারে এইরূপ অবগতি মতে প্রতারণা");
        dataholder_32.add(k9);
        datamodel_One k10 = new datamodel_One("ধারাঃ ৪১৯"," অপরের রূপ ধারণপূর্বক প্রতারণা করিবার শাস্তি");
        dataholder_32.add(k10);
        datamodel_One k11 = new datamodel_One("ধারাঃ ৪২০"," প্রতারণা ও সম্পত্তি সমর্পণ করিবার জন্য অসাধুভাবে প্রবৃত্ত করা");
        dataholder_32.add(k11);



        MyAdapter_32 myAdapter_32 = new MyAdapter_32(dataholder_32);
        recyclerView_32.setAdapter(myAdapter_32);
        return view;
    }

    public static class MyAdapter_32 extends RecyclerView.Adapter<MyAdapter_32.MyViewHolder_32>{
        protected static class MyViewHolder_32 extends RecyclerView.ViewHolder{

            MaterialCardView materialCardView_32;
            MaterialTextView materialTextView_header_32, materialTextView_Desc_32;

            public MyViewHolder_32(@NonNull View itemView) {
                super(itemView);

                materialCardView_32 = itemView.findViewById(R.id.recycler_CardView);
                materialTextView_Desc_32 = itemView.findViewById(R.id.recycler_TextViewDesc);
                materialTextView_header_32 = itemView.findViewById(R.id.recycler_TextViewHeader);

            }
        }

        ArrayList<datamodel_One> dataholder_32 ;

        public MyAdapter_32(ArrayList<datamodel_One> dataholder_32) {
            this.dataholder_32 = dataholder_32;
        }

        @NonNull
        @Override
        public MyViewHolder_32 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_xml_design_one,parent,false);

            return new MyViewHolder_32(view);
        }

        @Override
        public void onBindViewHolder(@NonNull MyViewHolder_32 holder, int position) {

            holder.materialTextView_header_32.setText(dataholder_32.get(position).getHeader());
            holder.materialTextView_Desc_32.setText(dataholder_32.get(position).getDesc());
            holder.materialCardView_32.setOnClickListener(v -> {

                if (position == 0) {

                  AppCompatActivity activity = (AppCompatActivity) v.getContext();
                  activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_One_Fragment_ThirtyTwo()).addToBackStack(null).commit();


                } else if (position==1) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Two_Fragment_ThirtyTwo()).addToBackStack(null).commit();


                }else if (position==2) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Three_Fragment_ThirtyTwo()).addToBackStack(null).commit();


                }else if (position==3) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Four_Fragment_ThirtyTwo()).addToBackStack(null).commit();


                }else if (position==4) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Five_Fragment_ThirtyTwo()).addToBackStack(null).commit();


                }else if (position==5) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Six_Fragment_ThirtyTwo()).addToBackStack(null).commit();


                }else if (position==6) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Seven_Fragment_ThirtyTwo()).addToBackStack(null).commit();


                }else if (position==7) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Eight_Fragment_ThirtyTwo()).addToBackStack(null).commit();


                }else if (position==8) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Nine_Fragment_ThirtyTwo()).addToBackStack(null).commit();


                }else if (position==9) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Ten_Fragment_ThirtyTwo()).addToBackStack(null).commit();


                }else {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Eleven_Fragment_ThirtyTwo()).addToBackStack(null).commit();


                }


            });

        }

        @Override
        public int getItemCount() {
            return 11;
        }

    }
}