package com.example.penalcodelowbangladesh;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textview.MaterialTextView;

import java.util.ArrayList;


public class Fragment_ThirtyNine extends Fragment {

    RecyclerView recyclerView_39;
    ArrayList<datamodel_One> dataholder_39 = new ArrayList<>();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment__thirty_nine, container, false);
        recyclerView_39 = view.findViewById(R.id.recyclerView_39);
        recyclerView_39.setLayoutManager(new LinearLayoutManager(getContext()));

      datamodel_One k1 = new datamodel_One("ধারাঃ ৪৯০","বাতিল");
      dataholder_39.add(k1);
        datamodel_One k2 = new datamodel_One("ধারাঃ ৪৯১","অসহায় ব্যক্তির পরিচর্যা করা এবং তাহার অভাবসমূহ মিটাইবার চুক্তিভঙ্গকরণ");
        dataholder_39.add(k2);
        datamodel_One k3 = new datamodel_One("ধারাঃ ৪৯২","বাতিল");
        dataholder_39.add(k3);


        MyAdapter_39 m = new MyAdapter_39(dataholder_39);
        recyclerView_39.setAdapter(m);


        return view;
    }

    public static class MyAdapter_39 extends RecyclerView.Adapter<MyAdapter_39.MyViewHolder_39>{
        private static class MyViewHolder_39 extends RecyclerView.ViewHolder{

            MaterialCardView materialCardView_39;
            MaterialTextView materialTextView_Header_39, materialTextView_Desc_39;

            public MyViewHolder_39(@NonNull View itemView) {
                super(itemView);

                materialCardView_39 = itemView.findViewById(R.id.recycler_CardView);
                materialTextView_Desc_39 = itemView.findViewById(R.id.recycler_TextViewDesc);
                materialTextView_Header_39 = itemView.findViewById(R.id.recycler_TextViewHeader);

            }
        }

        ArrayList<datamodel_One> dataholder_39 ;

        public MyAdapter_39(ArrayList<datamodel_One> dataholder_39) {
            this.dataholder_39 = dataholder_39;
        }

        @NonNull
        @Override
        public MyViewHolder_39 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {


            View view =LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_xml_design_one,parent,false);

            return new MyViewHolder_39(view);
        }

        @Override
        public void onBindViewHolder(@NonNull MyViewHolder_39 holder, int position) {

            holder.materialTextView_Header_39.setText(dataholder_39.get(position).getHeader());
            holder.materialTextView_Desc_39.setText(dataholder_39.get(position).getDesc());
            holder.materialCardView_39.setOnClickListener(v -> {

                if (position == 0) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_One_Fragment_ThirtyNine()).addToBackStack(null).commit();


                } else if (position==1) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Two_Fragment_ThirtyNine()).addToBackStack(null).commit();


                } else if (position==2) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Three_Fragment_ThirtyNine()).addToBackStack(null).commit();


                }

            });

        }

        @Override
        public int getItemCount() {
            return 3;
        }

    }
}