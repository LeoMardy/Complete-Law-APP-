package com.example.penalcodelowbangladesh;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textview.MaterialTextView;

import java.util.ArrayList;


public class Fragment_TwentySeven extends Fragment {

    RecyclerView recyclerView_27;
    ArrayList<datamodel_One> dataholder_27 = new ArrayList<>();
    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment__twenty_seven, container, false);
        recyclerView_27  = view.findViewById(R.id.recyclerView_27);
        recyclerView_27.setLayoutManager(new LinearLayoutManager(getContext()));

        datamodel_One o1 = new datamodel_One("ধারাঃ ৩৭৮","চুরি");
        dataholder_27.add(o1);
        datamodel_One o = new datamodel_One("ধারাঃ ৩৭৯","চুরির শাস্তি");
        dataholder_27.add(o);
        datamodel_One o3 = new datamodel_One("ধারাঃ ৩৮০","বাসগৃহ ইত্যাদিতে চুরি");
        dataholder_27.add(o3);
        datamodel_One o4 = new datamodel_One("ধারাঃ ৩৮১","কেরানী বা চাকর কর্তৃক মনিবের অীধকারভুক্ত সম্পত্তি চুরি");
        dataholder_27.add(o4);
        datamodel_One o5 = new datamodel_One("ধারাঃ ৩৮২","চুরি করিবার উদ্দেশ্যে মৃত্যু ঘটান, আঘাত দান বা আটকাইবার প্রস্তুতি লোয়ার পর চুরি অনুষ্ঠান");
        dataholder_27.add(o5);




MyAdapter_27 myAdapter_27 = new MyAdapter_27(dataholder_27);
recyclerView_27.setAdapter(myAdapter_27);

        return view;
    }

    public static class MyAdapter_27 extends RecyclerView.Adapter<MyAdapter_27.MyViewHolder_27>{
        protected static class MyViewHolder_27 extends RecyclerView.ViewHolder{
            MaterialCardView materialCardView_27;
            MaterialTextView materialTextView_Header_27, materialTextView_Desc_27;
            public MyViewHolder_27(@NonNull View itemView) {
                super(itemView);
                materialCardView_27 = itemView.findViewById(R.id.recycler_CardView);
                materialTextView_Header_27 = itemView.findViewById(R.id.recycler_TextViewHeader);
                materialTextView_Desc_27 = itemView.findViewById(R.id.recycler_TextViewDesc);

            }
        }
        ArrayList<datamodel_One> dataholder_27 ;

        public MyAdapter_27(ArrayList<datamodel_One> dataholder_27) {
            this.dataholder_27 = dataholder_27;
        }

        @NonNull
        @Override
        public MyViewHolder_27 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_xml_design_one,parent,false);

            return new MyViewHolder_27(view);
        }

        @Override
        public void onBindViewHolder(@NonNull MyViewHolder_27 holder, int position) {

            holder.materialTextView_Desc_27.setText(dataholder_27.get(position).getDesc());
            holder.materialTextView_Header_27.setText(dataholder_27.get(position).getHeader());
            holder.materialCardView_27.setOnClickListener(v -> {

                if (position == 0) {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_One_Fragment_TwentySeven()).addToBackStack(null).commit();


                } else if (position==1) {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Two_Fragment_TwentySeven()).addToBackStack(null).commit();


                }else if (position==2) {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Three_Fragment_TwentySeven()).addToBackStack(null).commit();


                }else if (position==3) {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Four_Fragment_TwentySeven()).addToBackStack(null).commit();


                }else  {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Five_Fragment_TwentySeven()).addToBackStack(null).commit();


                }

            });

        }

        @Override
        public int getItemCount() {
            return 5;
        }
    }
}