package com.example.penalcodelowbangladesh;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textview.MaterialTextView;

import java.util.ArrayList;


public class Fragment_Sixteen extends Fragment {

    private final ArrayList<datamodel_One> dataholder_sixteen = new ArrayList<>();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment__sixteen, container, false);
        RecyclerView recyclerView_Sixteen = view.findViewById(R.id.recyclerView_Sixteen);
        recyclerView_Sixteen.setLayoutManager(new LinearLayoutManager(getContext()));

        datamodel_One ob1 = new datamodel_One("ধারাঃ ২৬৪","ওজনের জন্য প্রতারণা-মূলকভাবে মিথ্যা যন্ত্রপাতি ব্যবহার করা");
        dataholder_sixteen.add(ob1);
        datamodel_One ob2 = new datamodel_One("ধারাঃ ২৬৫","প্রতারণামূলকভাবে মিথ্যা ওজন বা পরিমাপ ব্যবহার করা");
        dataholder_sixteen.add(ob2);
        datamodel_One ob3 = new datamodel_One("ধারাঃ ২৬৬","প্রতারণামূলক ব্যবহারের উদ্দেশ্যে মিথ্যা ওজন বা পরিমাপের যন্ত্র দখলে রাখা");
        dataholder_sixteen.add(ob3);
        datamodel_One ob4 = new datamodel_One("ধারাঃ ২৬৭","অপ্রকৃত বাটখারা বা মাপকাঠি প্রস্তুত বা বিক্রয় করা");
        dataholder_sixteen.add(ob4);


        MyAdapter_Sixteen myAdapter_sixteen = new MyAdapter_Sixteen(dataholder_sixteen);
        recyclerView_Sixteen.setAdapter(myAdapter_sixteen);

        return view;
    }

    public static class MyAdapter_Sixteen extends RecyclerView.Adapter<MyAdapter_Sixteen.MyViewHolder_Sixteen>{
        protected static class MyViewHolder_Sixteen extends RecyclerView.ViewHolder{

           MaterialCardView recyclerCardView_sixteen;
           MaterialTextView recyclerTextView_Header_sixteen,recyclerTextView_Desc_sixteen;

            public MyViewHolder_Sixteen(@NonNull View itemView) {
                super(itemView);
                recyclerTextView_Header_sixteen = itemView.findViewById(R.id.recycler_TextViewHeader);
                recyclerTextView_Desc_sixteen = itemView.findViewById(R.id.recycler_TextViewDesc);
                recyclerCardView_sixteen = itemView.findViewById(R.id.recycler_CardView);

            }
        }
        private final ArrayList<datamodel_One> dataholder_sixteen;

        public MyAdapter_Sixteen(ArrayList<datamodel_One> dataholder_sixteen) {
            this.dataholder_sixteen = dataholder_sixteen;
        }

        @NonNull
        @Override
        public MyViewHolder_Sixteen onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

            View myView = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_xml_design_one,parent,false);

            return new MyViewHolder_Sixteen(myView);
        }

        @Override
        public void onBindViewHolder(@NonNull MyViewHolder_Sixteen holder, int position) {
            holder.recyclerTextView_Header_sixteen.setText(dataholder_sixteen.get(position).getHeader());
            holder.recyclerTextView_Desc_sixteen.setText(dataholder_sixteen.get(position).getDesc());
            holder.recyclerCardView_sixteen.setOnClickListener(v -> {

                switch (position){
                    case 0:
                        AppCompatActivity activity = (AppCompatActivity)v.getContext();
                        activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_One_Fragment_Sixteen()).addToBackStack(null).commit();
                        break;
                    case 1:
                        AppCompatActivity activity1 = (AppCompatActivity)v.getContext();
                        activity1.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_two_Fragment_Sixteen()).addToBackStack(null).commit();
                        break;
                    case 2:
                        AppCompatActivity activity2 = (AppCompatActivity)v.getContext();
                        activity2.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_three_Fragment_Sixteen()).addToBackStack(null).commit();
                        break;
                    case 3:
                        AppCompatActivity activity3 = (AppCompatActivity)v.getContext();
                        activity3.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_four_Fragment_Sixteen()).addToBackStack(null).commit();
                        break;
                }


            });
        }

        @Override
        public int getItemCount() {
            return 4;
        }
    }


}