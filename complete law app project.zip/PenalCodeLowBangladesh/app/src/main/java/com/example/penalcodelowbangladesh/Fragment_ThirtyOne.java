package com.example.penalcodelowbangladesh;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textview.MaterialTextView;

import java.util.ArrayList;


public class Fragment_ThirtyOne extends Fragment {

    RecyclerView recyclerView_31;
    ArrayList<datamodel_One> dataholder_31 = new ArrayList<>();
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment__thirty_one, container, false);

        recyclerView_31 = view.findViewById(R.id.recyclerView_31);
        recyclerView_31.setLayoutManager(new LinearLayoutManager(getContext()));

        datamodel_One k1 = new datamodel_One("ধারাঃ ৪০৫"," অপরাধমুলক বিশ্বাসভঙ্গ");
        dataholder_31.add(k1);
        datamodel_One k2 = new datamodel_One("ধারাঃ ৪০৬"," অপরাধমূল বিশ্বাসভঙ্গের শাস্তি");
        dataholder_31.add(k2);
        datamodel_One k3 = new datamodel_One("ধারাঃ ৪০৭"," বাহক প্রভৃতি কর্তৃক অপরাধমূলক বিশ্বাসভঙ্গ");
        dataholder_31.add(k3);
        datamodel_One k4 = new datamodel_One("ধারাঃ ৪০৮"," কেরানী বা চাকর কর্তৃক অপরাধমূলক বিশ্বাসভঙ্গকরণ");
        dataholder_31.add(k4);
        datamodel_One k5 = new datamodel_One("ধারাঃ ৪০৯"," সরকারী কর্মচারী বা ব্যাংকার, বণিক বা প্রতিভূ কর্তৃক অপরাধমূলক বিশ্বাসভঙ্গকরণ");
        dataholder_31.add(k5);

        MyAdapter_31 myAdapter_31 = new MyAdapter_31(dataholder_31);
        recyclerView_31.setAdapter(myAdapter_31);

        return view;
    }

    public static class MyAdapter_31 extends RecyclerView.Adapter<MyAdapter_31.MyViewHolder_31>{
        protected static class MyViewHolder_31 extends RecyclerView.ViewHolder{

            MaterialTextView materialTextView_Header_31, materialTextView_Desc_31;
            MaterialCardView materialCardView_31;


            public MyViewHolder_31(@NonNull View itemView) {
                super(itemView);

                materialTextView_Desc_31 = itemView.findViewById(R.id.recycler_TextViewDesc);
                materialTextView_Header_31 = itemView.findViewById(R.id.recycler_TextViewHeader);
                materialCardView_31 = itemView.findViewById(R.id.recycler_CardView);
            }
        }

        ArrayList<datamodel_One> dataholder_31;

        public MyAdapter_31(ArrayList<datamodel_One> dataholder_31) {
            this.dataholder_31 = dataholder_31;
        }

        @NonNull
        @Override
        public MyViewHolder_31 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_xml_design_one,parent,false);

            return new MyViewHolder_31(view);
        }

        @Override
        public void onBindViewHolder(@NonNull MyViewHolder_31 holder, int position) {

            holder.materialTextView_Header_31.setText(dataholder_31.get(position).getHeader());
            holder.materialTextView_Desc_31.setText(dataholder_31.get(position).getDesc());
            holder.materialCardView_31.setOnClickListener(v -> {

                if (position == 0) {
                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_One_Fragment_ThirtyOne()).addToBackStack(null).commit();


                } else if (position==1) {
                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Two_Fragment_ThirtyOne()).addToBackStack(null).commit();


                }else if (position==2) {
                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Three_Fragment_ThirtyOne()).addToBackStack(null).commit();


                }else if (position==3) {
                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Four_Fragment_ThirtyOne()).addToBackStack(null).commit();


                }else  {
                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Five_Fragment_ThirtyOne()).addToBackStack(null).commit();


                }

            });

        }

        @Override
        public int getItemCount() {
            return 5;
        }

    }
}