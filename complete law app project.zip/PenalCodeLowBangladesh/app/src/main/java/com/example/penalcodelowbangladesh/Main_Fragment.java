package com.example.penalcodelowbangladesh;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;


public class Main_Fragment extends Fragment {

FloatingActionButton privacy_policy;
AdView mAdView;
 private final ArrayList<datamodel> dataholder = new ArrayList<>();


    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View myView =  inflater.inflate(R.layout.fragment_main_, container, false);
        privacy_policy = myView.findViewById(R.id.privacy_policy);
           mAdView = myView.findViewById(R.id.adView);


       RecyclerView recyclerView = myView.findViewById(R.id.recyclerView);
       recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
      /* GridLayoutManager gridLayoutManager = new GridLayoutManager(getContext(),2);
       recyclerView.setLayoutManager(gridLayoutManager);*/
       /*-------- Image Slider---------*/
     //  ImageSliderLIst();
       /*-------------Bottom Navigation View--------*/



           MobileAds.initialize(getContext(), new OnInitializationCompleteListener() {
                  @Override
                  public void onInitializationComplete(InitializationStatus initializationStatus) {
                  }
           });

           // Instantiate the RequestQueue.
           RequestQueue queue = Volley.newRequestQueue(getContext());
           String url = "https://testserverleo.000webhostapp.com/apps/panelCodeBD";

// Request a string response from the provided URL.
           StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                   new Response.Listener<String>() {
                          @Override
                          public void onResponse(String response) {
                                 // Display the first 500 characters of the response string.

                                 if (response.contains("showAds")){

                                        AdRequest adRequest = new AdRequest.Builder().build();
                                        mAdView.loadAd(adRequest);
                                 }

                          }
                   }, new Response.ErrorListener() {
                  @Override
                  public void onErrorResponse(VolleyError error) {

                  }
           });

// Add the request to the RequestQueue.
           queue.add(stringRequest);


privacy_policy.setOnClickListener(new View.OnClickListener() {
   @Override
   public void onClick(View v) {

     getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Privacy_Fragment()).addToBackStack(null).commit();

   }
});

       datamodel ob1 = new datamodel(R.drawable.logo_final3,"ধারা- ১ হতে ৫","(সূচনা)");
       dataholder.add(ob1);
       datamodel ob2 = new datamodel(R.drawable.logo_final3,"ধারা- 6 হতে ৫২ক","(সাধারণ ও ব্যাখ্যাসমূহ)");
       dataholder.add(ob2);
       datamodel ob3 = new datamodel(R.drawable.logo_final3,"ধারা- ৫৩ হতে ৭৫ ","(সাজা সম্পর্কিত)");
       dataholder.add(ob3);
       datamodel ob4 = new datamodel(R.drawable.logo_final3,"ধারা-৭৬ হতে ৯৫ ","(সাধারণ ব্যতিত্রুমগুলি)");
       dataholder.add(ob4);
       datamodel ob5 = new datamodel(R.drawable.logo_final3,"ধারা-৯৬ হতে ১০৬","(ব্যক্তিগত প্রতিরক্ষার অধিকার সম্পর্কিত)");
       dataholder.add(ob5);
       datamodel ob6 = new datamodel(R.drawable.logo_final3,"ধারা-১০৭ হতে ১২০","(অপরাধে সহায়তা প্রসঙ্গে)");
       dataholder.add(ob6);
       datamodel ob7 = new datamodel(R.drawable.logo_final3,"ধারা-১২০ক হতে ১২০খ","(অপরাধমূলক ষড়যন্ত্র)");
       dataholder.add(ob7);
       datamodel ob8 = new datamodel(R.drawable.logo_final3,"ধারা-১২১ হতে ১৩০","(রাষ্ট্রবিরোধী অপরাধ সম্পর্কিত)");
       dataholder.add(ob8);
       datamodel ob9 = new datamodel(R.drawable.logo_final3,"ধারা-১৩১ হতে ১৪০","(সেনাবাহিনী, নৌবাহিনী ও বিমানবাহিনী বিষয়ক অপরাধ প্রসঙ্গে)");
       dataholder.add(ob9);
       datamodel ob10 = new datamodel(R.drawable.logo_final3,"ধারা-১৪১ হতে ১৬০","(গণশান্তি পরিপন্থী অপরাধ প্রসঙ্গে)");
       dataholder.add(ob10);
       datamodel ob11 = new datamodel(R.drawable.logo_final3,"ধারা-১৬১ হতে ১৭১ ","(সরকারী কর্মচারী দ্বারা কৃত বা সরকারী কর্মচারী বিষয়ক অপরাধগুলো প্রসঙ্গে)");
       dataholder.add(ob11);
       datamodel ob12 = new datamodel(R.drawable.logo_final3,"ধারা-১৭১ক হতে ১৭১ঝ","(নির্বাচন বিষয়ক অপরাধগুলো প্রসঙ্গে)");
       dataholder.add(ob12);
       datamodel ob13 = new datamodel(R.drawable.logo_final3,"ধারা-১৭২ হতে ১৯০","(সরকারী কর্মচারীদের আইনানুগ ক্ষমতার অবমাননা প্রসঙ্গে)");
       dataholder.add(ob13);
       datamodel ob14 = new datamodel(R.drawable.logo_final3,"ধারা-১৯১ হতে ২২৯ ","(মিথ্যা সাক্ষ্য ও সাধারণের ন্যায়বিচার বিরোধী অপরাধগুলো প্রসঙ্গে)");
       dataholder.add(ob14);
       datamodel ob15 = new datamodel(R.drawable.logo_final3,"ধারা-২৩০ হতে ২৬৩ক","(মুদ্রা ও সরকারী স্ট্যাম্পসমূহ সংত্রুান্ত অপারধগুলো প্রসঙ্গে)");
       dataholder.add(ob15);
       datamodel ob16 = new datamodel(R.drawable.logo_final3,"ধারা-২৬৪ হতে ২৬৭","(ওজন ও মাপ সংত্রুান্ত অপরাধ প্রসঙ্গে)");
       dataholder.add(ob16);
       datamodel ob17 = new datamodel(R.drawable.logo_final3,"ধারা-২৬৮ হতে ২৯৪খ ","(জনস্বাস্থ্য, নিরাপত্তা,সুবিধা,শোভনতা ও নৈতিকতা বিরোধী অপরাধসমূহ প্রসঙ্গে))");
       dataholder.add(ob17);
       datamodel ob18 = new datamodel(R.drawable.logo_final3,"ধারা-২৯৫ হতে ২৯৮","(ধর্মসংত্রুান্ত অপরাধসমূহ সম্পর্কিত)");
       dataholder.add(ob18);
       datamodel ob19 = new datamodel(R.drawable.logo_final3,"ধারা-২৯৯ হতে ৩১১ ","(জীবন ক্ষুন্নকারী অপরাধসমূহ প্রসঙ্গে)");
       dataholder.add(ob19);
       datamodel ob20 = new datamodel(R.drawable.logo_final3,"ধারা-৩১২ হতে ৩১৮","(গর্ভপাত করান,অপ্রসুত শিশুর ক্ষতিসাধন,শিশুদের অনার্বত রাখা এবং জন্ম সংত্রুান্ত তথ্য গোপন করা প্রসঙ্গে)");
       dataholder.add(ob20);
       datamodel ob21 = new datamodel(R.drawable.logo_final3,"ধারা-৩১৯ হতে ৩৩৮ক","(আঘাত সম্পর্কিত)");
       dataholder.add(ob21);
       datamodel ob22 = new datamodel(R.drawable.logo_final3,"ধারা-৩৩৯ হতে ৩৪৮","(অবৈধ বাধা ও অবৈধ্য অবরোধ প্রসঙ্গে)");
       dataholder.add(ob22);
       datamodel ob23 = new datamodel(R.drawable.logo_final3,"ধারা-৩৪৯ হতে ৩৫৮","(অপরাধমূলক বলপ্রয়োগ ও আত্রুমণ সম্পর্কিত)");
       dataholder.add(ob23);
       datamodel ob24 = new datamodel(R.drawable.logo_final3,"ধারা-৩৫৯ হতে ৩৭৪","(মনুষ্যহরণ,অপহরণ, দাস ব্যবসায় ও জোর করে শ্রম আদায় প্রসঙ্গে)");
       dataholder.add(ob24);
       datamodel ob25 = new datamodel(R.drawable.logo_final3,"ধারা-৩৭৫ হতে ৩৭৬","(নারী ধর্ষণ সম্পর্কিত)");
       dataholder.add(ob25);
       datamodel ob26 = new datamodel(R.drawable.logo_final3,"ধারা-৩৭৭","(অস্বাভাবিক অপরাধ সম্পর্কিত)");
       dataholder.add(ob26);
       datamodel ob27 = new datamodel(R.drawable.logo_final3,"ধারা-৩৭৮ হতে ৩৮২","(চুরি সম্পর্কিত)");
       dataholder.add(ob27);
       datamodel ob28 = new datamodel(R.drawable.logo_final3,"ধারা-৩৮৩ হতে ৩৮৯","(বল প্রয়োগে সম্পত্তি আদায় প্রসঙ্গে)");
       dataholder.add(ob28);
       datamodel ob29 = new datamodel(R.drawable.logo_final3,"ধারা-৩৯০ হতে ৪০২","(দস্যৃতা ও ডাকাতি সম্পর্কিত)");
       dataholder.add(ob29);
       datamodel ob30 = new datamodel(R.drawable.logo_final3,"ধারা-৪০৩ হতে ৪০৪","(অপরাধমূলক সম্পত্তি আত্মসাৎকরণ প্রসঙ্গে)");
       dataholder.add(ob30);
       datamodel ob31 = new datamodel(R.drawable.logo_final3,"ধারা-৪০৫ হতে ৪০৯","(অপরাধমূলক বিশ্বাসভঙ্গ প্রসঙ্গে)");
       dataholder.add(ob31);
       datamodel ob32 = new datamodel(R.drawable.logo_final3,"ধারা-৪১০ হতে ৪২০","(চোরাই সম্পত্তি প্রহণ প্রসঙ্গে)");
       dataholder.add(ob32);
       datamodel ob33 = new datamodel(R.drawable.logo_final3,"ধারা-৪২১ হতে ৪২৪","(প্রতারণমুলক দলিলসমূহ ও সম্পত্তি বেদখল প্রসঙ্গে)");
       dataholder.add(ob33);
       datamodel ob34 = new datamodel(R.drawable.logo_final3,"ধারা-৪২৫ হতে ৪৪০","(ক্ষতিসাধন প্রসঙ্গে)");
       dataholder.add(ob34);
       datamodel ob35 = new datamodel(R.drawable.logo_final3,"ধারা-৪৪১ হতে ৪৬২","(অপরাধমূলক অনধিকার প্রবেশ প্রসঙ্গে)");
       dataholder.add(ob35);
       datamodel ob36 = new datamodel(R.drawable.logo_final3,"ধারা-৪৬২ক হতে ৪৬২খ","(ব্যাংকিং কোম্পানির সম্পত্তির ক্ষতি সাধন প্রসঙ্গে)");
       dataholder.add(ob36);
       datamodel ob37 = new datamodel(R.drawable.logo_final3,"ধারা-৪৬৩ হতে ৪৭৭ক","(দলিলপত্র এবং ট্রেডমার্ক বা সম্পত্তির প্রতীকচিহ্ন সম্পর্কিত অপরাধসমূহ প্রসঙ্গে)");
       dataholder.add(ob37);
       datamodel ob38 = new datamodel(R.drawable.logo_final3,"ধারা-৪৭৮ হতে ৪৮৯ঙ","(বাণিজ্য,সম্পত্তি ও অন্যান্য চিহ্ন সম্পর্কিত)");
       dataholder.add(ob38);
       datamodel ob39 = new datamodel(R.drawable.logo_final3,"ধারা-৪৯০ হতে ৪৯২","(অপরাধমূলকভাবে চাকুরির চুত্তিভঙ্গ প্রসঙ্গে)");
       dataholder.add(ob39);
       datamodel ob40 = new datamodel(R.drawable.logo_final3,"ধারা-৪৯৩ হতে ৪৯৮","(বিবাহ সংত্রুান্ত অপরাধসমূহ প্রসঙ্গে)");
       dataholder.add(ob40);
       datamodel ob41 = new datamodel(R.drawable.logo_final3,"ধারা-৪৯৯ হতে ৫০২","(মানহানি সম্পর্কে)");
       dataholder.add(ob41);
       datamodel ob42 = new datamodel(R.drawable.logo_final3,"ধারা-৫০৩ হতে ৫১০","(অনিষ্টকর কার্য ও বিরক্তি উৎপাদন প্রসঙ্গে)");
       dataholder.add(ob42);
       datamodel ob43 = new datamodel(R.drawable.logo_final3,"ধারা-৫১১","(অপরাধসংঘটনের উদ্যোগ প্রসঙ্গে)");
       dataholder.add(ob43);

      MyAdapter myAdapter = new MyAdapter(dataholder);
      recyclerView.setAdapter(myAdapter);

        return myView;
    }

}