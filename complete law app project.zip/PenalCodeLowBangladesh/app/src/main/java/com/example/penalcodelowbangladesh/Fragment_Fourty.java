package com.example.penalcodelowbangladesh;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textview.MaterialTextView;

import java.util.ArrayList;


public class Fragment_Fourty extends Fragment {

RecyclerView recyclerView_40;
ArrayList<datamodel_One> dataholder_40 = new ArrayList<>();


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment__fourty, container, false);
        recyclerView_40 = view.findViewById(R.id.recyclerView_40);
        recyclerView_40.setLayoutManager(new LinearLayoutManager(getContext()));

datamodel_One k1 = new datamodel_One("ধারাঃ ৪৯৩","প্রতারণামূলকভাবে আইনানুগ বিবাহের বিশ্বাসে প্ররোচিত করিয়া কোন ব্যক্তি কর্তৃক স্বামী-স্ত্রীরূপে সহবাস");
dataholder_40.add(k1);
datamodel_One k2 = new datamodel_One("ধারাঃ ৪৯৪","স্বামী বা  স্ত্রীর জীবদ্দশায় পুনরায় বিবাহকরণ");
dataholder_40.add(k2);
        datamodel_One k3 = new datamodel_One("ধারাঃ ৪৯৫","যে ব্যক্তির সহিত পরবর্তী বিবাহের চুক্তি সম্পাদিত হয় তাহার নিকট পূর্ববর্তী বিবাহ গোপন করিয়া একই রকম অপরাধ অনুষ্ঠানকরণ");
        dataholder_40.add(k3);
        datamodel_One k4 = new datamodel_One("ধারাঃ ৪৯৬","আইনসঙ্গত বিবাহ সম্পাদন ব্যতিরেকে প্রতারণামূলকভাবে বিবাহ অনুষ্ঠান উদ্যাপন করা");
        dataholder_40.add(k4);
        datamodel_One k5 = new datamodel_One("ধারাঃ ৪৯৭","ব্যভিচার");
        dataholder_40.add(k5);
        datamodel_One k6 = new datamodel_One("ধারাঃ ৪৯৮","কোন বিবাহিতা নারীকে অপরাধমূলক উদ্দেশ্যে প্রলুব্ধকরণ বা অপহরণ বা আটককরণ");
        dataholder_40.add(k6);

MyAdapter_40 myAdapter_40 = new MyAdapter_40(dataholder_40);
recyclerView_40.setAdapter(myAdapter_40);

        return view;
    }

    public static class MyAdapter_40 extends RecyclerView.Adapter<MyAdapter_40.MyViewHolder_40>{
        protected static class MyViewHolder_40 extends RecyclerView.ViewHolder{

            MaterialCardView materialCardView_40;
            MaterialTextView materialTextView_Header_40, materialTextView_Desc_40;

            public MyViewHolder_40(@NonNull View itemView) {
                super(itemView);

                materialTextView_Desc_40 = itemView.findViewById(R.id.recycler_TextViewDesc);
                materialCardView_40= itemView.findViewById(R.id.recycler_CardView);
                materialTextView_Header_40 = itemView.findViewById(R.id.recycler_TextViewHeader);
            }
        }
        ArrayList<datamodel_One> dataholder_40;

        public MyAdapter_40(ArrayList<datamodel_One> dataholder_40) {
            this.dataholder_40 = dataholder_40;
        }

        @NonNull
        @Override
        public MyViewHolder_40 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_xml_design_one,parent,false);
            return new MyViewHolder_40(view);
        }

        @Override
        public void onBindViewHolder(@NonNull MyViewHolder_40 holder, int position) {

            holder.materialTextView_Header_40.setText(dataholder_40.get(position).getHeader());
            holder.materialTextView_Desc_40.setText(dataholder_40.get(position).getDesc());
            holder.materialCardView_40.setOnClickListener(v -> {

                if (position == 0) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_One_Fragment_Fourty()).addToBackStack(null).commit();


                } else if (position==1) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Two_Fragment_Fourty()).addToBackStack(null).commit();


                }else if (position==2) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Three_Fragment_Fourty()).addToBackStack(null).commit();

                }else if (position==3) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Four_Fragment_Fourty()).addToBackStack(null).commit();

                }else if (position==4) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Five_Fragment_Fourty()).addToBackStack(null).commit();

                }else {

                        AppCompatActivity activity = (AppCompatActivity) v.getContext();
                        activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Six_Fragment_Fourty()).addToBackStack(null).commit();

                }


                });

        }

        @Override
        public int getItemCount() {
            return 6;
        }

    }
}