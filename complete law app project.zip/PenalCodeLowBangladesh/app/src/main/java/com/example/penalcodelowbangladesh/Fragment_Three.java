package com.example.penalcodelowbangladesh;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;


public class Fragment_Three extends Fragment {
    private RecyclerView recyclerView;
    private ArrayList<datamodel_One> dataholder_three = new ArrayList<>();

    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View myView =  inflater.inflate(R.layout.fragment__three, container, false);
        recyclerView = myView.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        datamodel_One ob1 = new datamodel_One("ধারা-৫৩","দন্ডসমূহ");
        dataholder_three.add(ob1);
        datamodel_One ob2 = new datamodel_One("ধারা-৫৩-ক","কারাবাস উল্লেখের ব্যাখ্যা");
        dataholder_three.add(ob2);
        datamodel_One ob3 = new datamodel_One("ধারা-৫৪","মৃত্যুদন্ড হ্রাসকারণ");
        dataholder_three.add(ob3);
        datamodel_One ob4 = new datamodel_One("ধারা-৫৫","যাবতজ্জীবন কারাদন্ড হ্রাসকারণ");
        dataholder_three.add(ob4);
        datamodel_One ob5 = new datamodel_One("ধারা-৫৫-ক","রাষ্ট্রপতির বিশেষাধিকার সংরক্ষণ");
        dataholder_three.add(ob5);
        datamodel_One ob6 = new datamodel_One("ধারা-৫৬","বাতিল");
        dataholder_three.add(ob6);
        datamodel_One ob7 = new datamodel_One("ধারা-৫৭","দন্ড মেয়াদসমূহের ভগ্নাংশসমূহ");
        dataholder_three.add(ob7);
        datamodel_One ob8 = new datamodel_One("ধারা-৫৮","বাতিল");
        dataholder_three.add(ob8);
        datamodel_One ob9 = new datamodel_One("ধারা-৫৯","বাতিল");
        dataholder_three.add(ob9);
        datamodel_One ob10 = new datamodel_One("ধারা-৬০","কারাবাসের কতিপয় ক্ষেত্রে দন্ড সম্পুর্ণরূপে বা অংশত সশ্রম বা বিনাশ্রম হইতে পারিবে");
        dataholder_three.add(ob10);
        datamodel_One ob11 = new datamodel_One("ধারা-৬১","বাতিল");
        dataholder_three.add(ob11);
        datamodel_One ob12 = new datamodel_One("ধারা-৬২","বাতিল");
        dataholder_three.add(ob12);
        datamodel_One ob13 = new datamodel_One("ধারা-৬৩","অর্থদন্ডের পরিমাণ");
        dataholder_three.add(ob13);
        datamodel_One ob14 = new datamodel_One("ধারা-৬৪","অর্থদন্ড অনাদায়ের দরুন কারাদন্ড দান");
        dataholder_three.add(ob14);
        datamodel_One ob15 = new datamodel_One("ধারা-৬৫","যেক্ষেত্রে কারাবাস ও অর্থদন্ড বিধেয় সেই ক্ষেত্রে অর্থদন্ড অনাদায়ে কারাবাসের সীমা");
        dataholder_three.add(ob15);
        datamodel_One ob16 = new datamodel_One("ধারা-৬৬","অর্থদন্ড অনাদায়ে কারাদন্ডের বর্ণনা");
        dataholder_three.add(ob16);
        datamodel_One ob17 = new datamodel_One("ধারা-৬৭","কেবল অর্থদন্ডে দন্ডার্হ অপরাধের ক্ষেত্রে অর্থদন্ড অনাদায়ের কারাদন্ড");
        dataholder_three.add(ob17);
        datamodel_One ob18 = new datamodel_One("ধারা-৬৮","অর্থদন্ড আদায় করিলে কারাদন্ডের সমাপ্তি হইবে");
        dataholder_three.add(ob18);
        datamodel_One ob19 = new datamodel_One("ধারা-৬৯","অর্থদন্ডের আনুপাতির অংশ আদায় কারা হইলে কারাদন্ডের সমাপ্তি হইবে");
        dataholder_three.add(ob19);
        datamodel_One ob20 = new datamodel_One("ধারা-৭০","ছয় বৎসরের মধ্যে বা কারাবাসকালে আদায়যোগ্য অর্থদন্ডে দন্ডিত ব্যাক্তির মৃত্যুর ফলে সম্পত্তি");
        dataholder_three.add(ob20);
        datamodel_One ob21 = new datamodel_One("ধারা-৭১","কতিপয় অপরাধের সমবায়ে গঠিত অপরাধের শাস্তির সীমা");
        dataholder_three.add(ob21);
        datamodel_One ob22 = new datamodel_One("ধারা-৭২","কতিপয় অপরাধের একটির জন্য দোষী ব্যাক্তির শাস্তি-ইহা কি সম্পর্কে,রায়ে তাহাপর সন্দেহ প্রকাশকরণ");
        dataholder_three.add(ob22);
        datamodel_One ob23 = new datamodel_One("ধারা-৭৩","নির্জন কারাবাস");
        dataholder_three.add(ob23);
        datamodel_One ob24 = new datamodel_One("ধারা-৭৪","নির্জন কারাবাসের সীমা");
        dataholder_three.add(ob24);
        datamodel_One ob25 = new datamodel_One("ধারা-৭৫","পূর্ববর্তী দন্ডের পরে ১২শ পরিচ্ছেদের বা ১৭শ পরিচ্ছেদের অধীনে কতিপয় অপরাধের জন্য বর্ধিত দন্ড");
        dataholder_three.add(ob25);


MyAdpater_Three myAdpater_three = new MyAdpater_Three(dataholder_three);
recyclerView.setAdapter(myAdpater_three);
        return myView;
    }
}