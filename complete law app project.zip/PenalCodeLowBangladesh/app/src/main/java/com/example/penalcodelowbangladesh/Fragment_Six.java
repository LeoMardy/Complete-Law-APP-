package com.example.penalcodelowbangladesh;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;


public class Fragment_Six extends Fragment {
    private RecyclerView recyclerView;
    private ArrayList<datamodel_One> dataholder_Six = new ArrayList<>();
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment__six, container, false);
        recyclerView = view.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        datamodel_One ob1 = new datamodel_One("ধারাঃ ১০৭","কোন অপরাধে সহায়তা");
        dataholder_Six.add(ob1);
        datamodel_One ob2 = new datamodel_One("ধারাঃ ১০৮","দুষ্কর্মে সহায়তাকারী");
        dataholder_Six.add(ob2);
        datamodel_One ob3 = new datamodel_One("ধারাঃ ১০৮-ক","বাংলাদেশের বাাইরে দুষ্কর্মে সহায়তাকারী");
        dataholder_Six.add(ob3);
        datamodel_One ob4 = new datamodel_One("ধারা ১০৯","দুষ্কর্মে সহায়তার ফলে সহায়তাকৃত কাজটি সম্পাদিত হইবার ক্ষেত্রে এবং উহার শাস্তি বিধানার্থে কোন স্পষ্ট বিধান না থাকিবার ক্ষেত্রে দুষ্কর্মে সহায়তার শাস্তি");
        dataholder_Six.add(ob4);
        datamodel_One ob5 = new datamodel_One("ধারাঃ ১১০","সহায়তাকৃত ব্যক্তি সহায়তাকারীর অভিপ্রায় হইতে কার্য করিবার ভিন্ন অভিপ্রায়ে কার্য করিবার ক্ষেত্রে সহায়তার শাস্তি");
        dataholder_Six.add(ob5);
        datamodel_One ob6 = new datamodel_One("ধারাঃ ১১১"," সহায়তাকৃত কার্য হইতে ভিন্ন কার্য সম্পাদনের ক্ষেত্রে সহায়তাকারীর দায়িত্ব");
        dataholder_Six.add(ob6);
        datamodel_One ob7 = new datamodel_One("ধারাঃ ১১২","যেক্ষেত্রে সহায়তাকারী সহায়তাকৃত কার্য ও সম্পাদিত কার্যের দরুন ক্রমপুঞ্জিত শাস্তির জন্য দায়ী হয়");
        dataholder_Six.add(ob7);
        datamodel_One ob8 = new datamodel_One("ধারাঃ ১১৩","সাহায্যকৃত কার্যের কারণে দুষ্কর্মে সহায়তাকারী কর্তৃক অভিপ্রেত পরিণতি হইতে ভিন্ন পরিণতির ক্ষেত্রে দুষমের্মে সহায়তাকারীর দায়িত্ব");
        dataholder_Six.add(ob8);
        datamodel_One ob9 = new datamodel_One("ধারাঃ ১১৪","অপরাধ সংঘটনকালে সহায়তাকারীর উপস্থিতি");
        dataholder_Six.add(ob9);
        datamodel_One ob10 = new datamodel_One("ধারা ১১৫","মুত্যুদন্ড বা যাবজ্জীবন কারাদন্ডে দন্ডনীয় অপরাধে সহায়তাকরণ, অপরাধ অনুষ্ঠিত না হইলে");
        dataholder_Six.add(ob10);
        datamodel_One ob11 = new datamodel_One("ধারাঃ ১১৬","কারাদন্ডে দন্ডনীয় অপরাধে সহায়তাকরন, অপরাধটি অনুষ্ঠিত না হইবার ক্ষেত্রে");
        dataholder_Six.add(ob11);
        datamodel_One ob12 = new datamodel_One("ধারাঃ ১১৭","জনসাধারণ বা দশের অধিক ব্যক্তি কর্তৃক অপরাধ অনুষ্ঠানে সহায়তাকরণ");
        dataholder_Six.add(ob12);
        datamodel_One ob13 = new datamodel_One("ধারাঃ ১১৮","মৃত্যু বা যাবজ্জীবন কারাদন্ডে দণ্ডনীয় অপরাধ সংঘটনের ষড়যন্ত্র গোপনকরন");
        dataholder_Six.add(ob13);
        datamodel_One ob14 = new datamodel_One("ধারাঃ ১১৯","সরকারী কর্মচারী কর্তৃক এমন অপরাধ সংঘটনের ক্ষেত্রে ষড়যন্ত্র গোপনকরণ যাহা নিবারণ করা তাহার কর্তব্য");
        dataholder_Six.add(ob14);
        datamodel_One ob15 = new datamodel_One("ধারাঃ ১২০"," কারাদন্ডে দন্ডনীয় অপরাধ সংঘটনের ষড়যন্ত্রের গোপনকরণ");
        dataholder_Six.add(ob15);

        MyAdapter_Six myAdapter_six = new MyAdapter_Six(dataholder_Six);
        recyclerView.setAdapter(myAdapter_six);

        return view;
    }
}