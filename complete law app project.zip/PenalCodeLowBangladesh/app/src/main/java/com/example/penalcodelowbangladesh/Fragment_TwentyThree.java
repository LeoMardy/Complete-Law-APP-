package com.example.penalcodelowbangladesh;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textview.MaterialTextView;

import java.util.ArrayList;


public class Fragment_TwentyThree extends Fragment {

    RecyclerView recyclerView_23;
    ArrayList<datamodel_One> dataholder_23 = new ArrayList<>();

    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment__twenty_three, container, false);
       recyclerView_23 = view.findViewById(R.id.recyclerView_23);
       recyclerView_23.setLayoutManager(new LinearLayoutManager(getContext()));

       datamodel_One ok1 = new datamodel_One("ধারাঃ ৩৪৯"," বলপ্রয়োগ");
       dataholder_23.add(ok1);
        datamodel_One ok2 = new datamodel_One("ধারাঃ ৩৫০","অপরাধমূলক বলপ্রয়োগ");
        dataholder_23.add(ok2);
        datamodel_One ok3 = new datamodel_One("ধারাঃ ৩৫১","আক্রমণ");
        dataholder_23.add(ok3);
        datamodel_One ok5 = new datamodel_One("ধারা ৩৫২"," গুরুতর আকস্মিক উত্তেজনার ফল ব্যতীত প্রকারান্তরে আক্রমণ বা অপরাধমূলক বলপ্রয়োগের শাস্তি");
        dataholder_23.add(ok5);
        datamodel_One ok6 = new datamodel_One("ধারাঃ ৩৫৩","সরকারী কর্মচারীকে তাহার কর্তব্য পালনে বাধাদানের নিমিত্ত আক্রমণ ও অপরাধমূলক বলপ্রয়োগ ");
        dataholder_23.add(ok6);
        datamodel_One ok7 = new datamodel_One("ধারাঃ ৩৫৪","কোন নারীর শালীনতা নষ্ট করিবার উদ্দেশ্যে তাহাকে আক্রমণ ও তৎপ্রতি অপরাধমূলক বলপ্রয়োগ ");
        dataholder_23.add(ok7);
        datamodel_One ok8 = new datamodel_One("ধারাঃ ৩৫৫"," গুরুতর উত্তেজনাবশতঃ ব্যতীত, প্রকারান্তরে কোন ব্যক্তিকে অপমান করিবার অভিপ্রায়ে আক্রমণ বা অপরাধমূলক বলপ্রয়োগ");
        dataholder_23.add(ok8);
        datamodel_One ok9 = new datamodel_One("ধারাঃ ৩৫৬"," কোন ব্যক্তি কর্তৃক বাহিত সম্পত্তি চুরি করিবার উদ্যোগে আক্রমণ বা অপরাধমূলক বলপ্রয়োগ");
        dataholder_23.add(ok9);
        datamodel_One ok10 = new datamodel_One("ধারাঃ ৩৫৭"," কোন ব্যক্তিকে অবৈধভাবে অবরোধ করিবার উদ্যোগে আক্রমণ বা অপরাধমূলক বলপ্রয়োগ");
        dataholder_23.add(ok10);
        datamodel_One ok11 = new datamodel_One("ধারাঃ ৩৫৮","গুরুতর উত্তেজনাবশতঃ অক্রমণ বা অপরাধমূলক বলপ্রয়োগ");
        dataholder_23.add(ok11);





MyAdatper_23 myAdatper_23 = new MyAdatper_23(dataholder_23);
recyclerView_23.setAdapter(myAdatper_23);

        return view;
    }

    public static class MyAdatper_23 extends RecyclerView.Adapter<MyAdatper_23.MyViewholder_23>{
        protected static class MyViewholder_23 extends  RecyclerView.ViewHolder{

            MaterialCardView materialCardView_23;
            MaterialTextView materialTextView_Header_23, materialTextView_Desc_23;
            public MyViewholder_23(@NonNull View itemView) {
                super(itemView);

                materialCardView_23 = itemView.findViewById(R.id.recycler_CardView);
                materialTextView_Header_23 = itemView.findViewById(R.id.recycler_TextViewHeader);
                materialTextView_Desc_23 = itemView.findViewById(R.id.recycler_TextViewDesc);

            }
        }
        ArrayList<datamodel_One> dataholder_23;

        public MyAdatper_23(ArrayList<datamodel_One> dataholder_23) {
            this.dataholder_23 = dataholder_23;
        }

        @NonNull
        @Override
        public MyViewholder_23 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_xml_design_one,parent,false);

            return new MyViewholder_23(view);
        }

        @Override
        public void onBindViewHolder(@NonNull MyViewholder_23 holder, int position) {

            holder.materialTextView_Header_23.setText(dataholder_23.get(position).getHeader());
            holder.materialTextView_Desc_23.setText(dataholder_23.get(position).getDesc());
            holder.materialCardView_23.setOnClickListener(v -> {

                if (position == 0) {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_One_Fragment_TwentyThree()).addToBackStack(null).commit();


                } else if (position==1) {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Two_Fragment_TwentyThree()).addToBackStack(null).commit();


                }else if (position==2) {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Three_Fragment_TwentyThree()).addToBackStack(null).commit();


                }else if (position==3) {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Four_Fragment_TwentyThree()).addToBackStack(null).commit();


                }else if (position==4) {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Five_Fragment_TwentyThree()).addToBackStack(null).commit();


                }else if (position==5) {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Six_Fragment_TwentyThree()).addToBackStack(null).commit();


                }else if (position==6) {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Seven_Fragment_TwentyThree()).addToBackStack(null).commit();


                }else if (position==7) {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Eight_Fragment_TwentyThree()).addToBackStack(null).commit();


                }else if (position==8) {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Nine_Fragment_TwentyThree()).addToBackStack(null).commit();


                }else {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Ten_Fragment_TwentyThree()).addToBackStack(null).commit();


                }

            });

        }

        @Override
        public int getItemCount() {
            return 10;
        }
    }

}