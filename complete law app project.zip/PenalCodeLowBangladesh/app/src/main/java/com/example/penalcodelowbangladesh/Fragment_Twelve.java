package com.example.penalcodelowbangladesh;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;


public class Fragment_Twelve extends Fragment {
    private RecyclerView recyclerView_Twelve;
    private ArrayList<datamodel_One> dataholder_Twelve = new ArrayList<>();


    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment__twelve, container, false);
        recyclerView_Twelve = view.findViewById(R.id.recyclerView_twelve);
        recyclerView_Twelve.setLayoutManager(new LinearLayoutManager(getContext()));

        datamodel_One obj14 = new datamodel_One("ধারাঃ ১৭১-ক","প্রার্থী ও নির্বাচনাধিকার এর সংজ্ঞা");
        dataholder_Twelve.add(obj14);
        datamodel_One obj15 = new datamodel_One("ধারাঃ ১৭১-খ","ঘুষ");
        dataholder_Twelve.add(obj15);
        datamodel_One obj16 = new datamodel_One("ধারাঃ ১৭১-গ","নির্বাচনসমূহে অন্যায় প্রভাব");
        dataholder_Twelve.add(obj16);
        datamodel_One obj17 = new datamodel_One("ধারাঃ ১৭১-ঘ","নির্বাচনসমূহে ছদ্মবেশ ধারণ");
        dataholder_Twelve.add(obj17);
        datamodel_One obj18 = new datamodel_One("ধারাঃ ১৭১-ঙ","ঘুষের শাস্তি");
        dataholder_Twelve.add(obj18);
        datamodel_One obj19 = new datamodel_One("ধারাঃ ১৭১-চ","নির্বাচনে অন্যায় প্রভাব বিস্তার ও মিথ্যা পরিচয় দেওযা");
        dataholder_Twelve.add(obj19);
        datamodel_One obj20 = new datamodel_One("ধারাঃ ১৭১-ছ","নির্বাচন সম্পর্কে মিথ্যা বিবৃতিদান");
        dataholder_Twelve.add(obj20);
        datamodel_One obj21 = new datamodel_One("ধারাঃ ১৭১-জ","নির্বাচন সম্পর্কিত ব্যাপারে অবৈধ অর্থ প্রদান");
        dataholder_Twelve.add(obj21);
        datamodel_One obj22 = new datamodel_One("ধারাঃ ১৭১-ঝ","নির্বাচন সম্পর্কিত খরচের হিসাব না রাখা");
        dataholder_Twelve.add(obj22);

    MyAdapter_Twelve myAdapter_twelve = new MyAdapter_Twelve(dataholder_Twelve);
    recyclerView_Twelve.setAdapter(myAdapter_twelve);


        return view;
    }
}