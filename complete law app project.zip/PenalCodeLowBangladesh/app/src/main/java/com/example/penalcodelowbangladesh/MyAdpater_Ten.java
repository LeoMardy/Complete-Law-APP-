package com.example.penalcodelowbangladesh;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textview.MaterialTextView;

import java.util.ArrayList;

public class MyAdpater_Ten extends RecyclerView.Adapter <MyAdpater_Ten.MyViewHolder_Ten>{
    protected static class MyViewHolder_Ten extends RecyclerView.ViewHolder{
       final private MaterialCardView recycler_CardView;
       final private MaterialTextView recycler_TextViewHeader,recycler_TextViewDesc;

        public MyViewHolder_Ten(@NonNull View itemView) {
            super(itemView);
            recycler_TextViewHeader = itemView.findViewById(R.id.recycler_TextViewHeader);
            recycler_TextViewDesc = itemView.findViewById(R.id.recycler_TextViewDesc);
            recycler_CardView = itemView.findViewById(R.id.recycler_CardView);
        }
    }
    ArrayList<datamodel_One> dataholder_ten;

    public MyAdpater_Ten(ArrayList<datamodel_One> dataholder_ten) {
        this.dataholder_ten = dataholder_ten;
    }

    @NonNull
    @Override
    public MyViewHolder_Ten onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_xml_design_one,parent,false);
        return new MyViewHolder_Ten(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder_Ten holder, @SuppressLint("RecyclerView") int position) {
    holder.recycler_TextViewHeader.setText(dataholder_ten.get(position).getHeader());
    holder.recycler_TextViewDesc.setText(dataholder_ten.get(position).getDesc());
    holder.recycler_CardView.setOnClickListener(v -> {
        switch (position){
            case 0:
                AppCompatActivity activity = (AppCompatActivity) v.getContext();
                activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_One_Fragment_Ten()).addToBackStack(null).commit();
             break;
            case 1:
                AppCompatActivity activity1 = (AppCompatActivity) v.getContext();
                activity1.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_two_Fragment_Ten()).addToBackStack(null).commit();
                break;
            case 2:
                AppCompatActivity activity2 = (AppCompatActivity) v.getContext();
                activity2.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_three_Fragment_Ten()).addToBackStack(null).commit();
                break;
            case 3:
                AppCompatActivity activity3 = (AppCompatActivity) v.getContext();
                activity3.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_four_Fragment_Ten()).addToBackStack(null).commit();
                break;
            case 4:
                AppCompatActivity activity4 = (AppCompatActivity) v.getContext();
                activity4.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_five_Fragment_Ten()).addToBackStack(null).commit();
                break;
            case 5:
                AppCompatActivity activity5 = (AppCompatActivity) v.getContext();
                activity5.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_six_Fragment_Ten()).addToBackStack(null).commit();
                break;
            case 6:
                AppCompatActivity activity6 = (AppCompatActivity) v.getContext();
                activity6.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_seven_Fragment_Ten()).addToBackStack(null).commit();
                break;
            case 7:
                AppCompatActivity activity7 = (AppCompatActivity) v.getContext();
                activity7.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_eight_Fragment_Ten()).addToBackStack(null).commit();
                break;
            case 8:
                AppCompatActivity activity8 = (AppCompatActivity) v.getContext();
                activity8.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_nine_Fragment_Ten()).addToBackStack(null).commit();
                break;
            case 9:
                AppCompatActivity activity9 = (AppCompatActivity) v.getContext();
                activity9.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_ten_Fragment_Ten()).addToBackStack(null).commit();
                break;
            case 10:
                AppCompatActivity activity10 = (AppCompatActivity) v.getContext();
                activity10.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_eleven_Fragment_Ten()).addToBackStack(null).commit();
                break;
            case 11:
                AppCompatActivity activity11 = (AppCompatActivity) v.getContext();
                activity11.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_twelve_Fragment_Ten()).addToBackStack(null).commit();
                break;
            case 12:
                AppCompatActivity activity12 = (AppCompatActivity) v.getContext();
                activity12.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_thirteen_Fragment_Ten()).addToBackStack(null).commit();
                break;
            case 13:
                AppCompatActivity activity13 = (AppCompatActivity) v.getContext();
                activity13.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_fourteen_Fragment_Ten()).addToBackStack(null).commit();
                break;
            case 14:
                AppCompatActivity activity14 = (AppCompatActivity) v.getContext();
                activity14.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_fifteen_Fragment_Ten()).addToBackStack(null).commit();
                break;
            case 15:
                AppCompatActivity activity15 = (AppCompatActivity) v.getContext();
                activity15.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_sixteen_Fragment_Ten()).addToBackStack(null).commit();
                break;
            case 16:
                AppCompatActivity activity16 = (AppCompatActivity) v.getContext();
                activity16.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_seventeen_Fragment_Ten()).addToBackStack(null).commit();
                break;
            case 17:
                AppCompatActivity activity17 = (AppCompatActivity) v.getContext();
                activity17.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_eighteen_Fragment_Ten()).addToBackStack(null).commit();
                break;
            case 18:
                AppCompatActivity activity18 = (AppCompatActivity) v.getContext();
                activity18.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_nineteen_Fragment_Ten()).addToBackStack(null).commit();
                break;
            case 19:
                AppCompatActivity activity19 = (AppCompatActivity) v.getContext();
                activity19.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_twenty_Fragment_Ten()).addToBackStack(null).commit();
                break;
            case 20:
                AppCompatActivity activity20 = (AppCompatActivity) v.getContext();
                activity20.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_twentyOne_Fragment_Ten()).addToBackStack(null).commit();
                break;
            default:
                AppCompatActivity activity21 = (AppCompatActivity) v.getContext();
                activity21.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_twentyTwo_Fragment_Ten()).addToBackStack(null).commit();
                break;

        }
    });
    }

    @Override
    public int getItemCount() {
        return 22;
    }
}
