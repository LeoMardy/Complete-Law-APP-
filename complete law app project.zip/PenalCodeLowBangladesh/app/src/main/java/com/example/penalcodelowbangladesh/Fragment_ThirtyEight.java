package com.example.penalcodelowbangladesh;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textview.MaterialTextView;

import java.util.ArrayList;


public class Fragment_ThirtyEight extends Fragment {


    RecyclerView recyclerView_38;
    ArrayList<datamodel_One> dataholder_38 = new ArrayList<>();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment__thirty_eight, container, false);

        recyclerView_38 =view.findViewById(R.id.recyclerView_38);
        recyclerView_38.setLayoutManager(new LinearLayoutManager(getContext()));

        datamodel_One k1 = new datamodel_One("ধারাঃ ৪৭৮","বাণিজ্য-প্রতীক");
        dataholder_38.add(k1);
        datamodel_One k2 = new datamodel_One("ধারাঃ ৪৭৯","পণ্য-প্রতীক");
        dataholder_38.add(k2);
        datamodel_One k3 = new datamodel_One("ধারাঃ ৪৮০"," মিথ্যা পণ্য-প্রতীকের ব্যবহার");
        dataholder_38.add(k3);
        datamodel_One k4 = new datamodel_One("ধারাঃ ৪৮১","মিথ্যা সম্পত্তি-প্রতীক ব্যবহার");
        dataholder_38.add(k4);
        datamodel_One k5 = new datamodel_One("ধারাঃ ৪৮২","মিথ্যা বাণিজ্য-প্রতীক বা সম্পত্তি-প্রতীক ব্যবহারের শাস্তি");
        dataholder_38.add(k5);
        datamodel_One k6 = new datamodel_One("ধারাঃ ৪৮৩","অন্য কোন ব্যক্তি কর্তৃক ব্যবহৃত কোন বাণিজ্য-প্রতীক বা সম্পত্তি-প্রতীক জালকরণ");
        dataholder_38.add(k6);
        datamodel_One k7 = new datamodel_One("ধারাঃ ৪৮৪"," কোন সরকার কর্মচারী কর্তৃক ব্যবহৃত কোন প্রতীক জালকরণ");
        dataholder_38.add(k7);
        datamodel_One k8= new datamodel_One("ধারাঃ ৪৮৫","বাণিজ্য প্রতীক বা সম্পত্তি প্রতীক নকল করিবার যেকোন যন্ত্র প্রস্তুত বা দখল");
        dataholder_38.add(k8);
        datamodel_One k9 = new datamodel_One("ধারাঃ ৪৮৬","মেকি বাণিজ্য প্রতীক বা সম্পত্তি প্রতীকে চিহ্নিত মাল বিক্রয়");
        dataholder_38.add(k9);
        datamodel_One k10 = new datamodel_One("ধারাঃ ৪৮৭","মালধারক কোন পাত্রের উপর মিথ্যা চিহ্ন");
        dataholder_38.add(k10);
        datamodel_One k11 = new datamodel_One("ধারাঃ ৪৮৮","অনুরূপ যেকোন মিথ্যা চিহ্ন ব্যবহারের শাস্তি");
        dataholder_38.add(k11);
        datamodel_One k12 = new datamodel_One("ধারাঃ ৪৮৯","ক্ষতিসাধন করিবার উদ্দেশ্যে সম্পত্তি প্রতকে হস্তক্ষেপকরণ");
        dataholder_38.add(k12);

        datamodel_One k13 = new datamodel_One("ধারাঃ ৪৮৯-ক","মুদ্রা-নোটসমূহ বা ব্যাংক-নোটসমূহ নকলকরণ");
        dataholder_38.add(k13);
        datamodel_One k14 = new datamodel_One("ধারাঃ ৪৮৯-খ","জাল বা মেকি মুদ্রা-নোট বা ব্যাংক-নোট খাটিঁ হিসাবে ব্যবহারকরণ");
        dataholder_38.add(k14);
        datamodel_One k15 = new datamodel_One("ধারাঃ ৪৮৯-গ","মুদ্রা-নোট বা জাল বা নকল ব্যাংক-নোট দখলে রাখা");
        dataholder_38.add(k15);
        datamodel_One k16 = new datamodel_One("ধারাঃ ৪৮৯-ঘ","মুদ্রা-নোটসমূহ বা ব্যাংক-নোটসমূহ জাল বা নকল করিবার যন্ত্রপাতি বা উপাদানসমূহ প্রস্তুত বা দখল");
        dataholder_38.add(k16);
        datamodel_One k17 = new datamodel_One("ধারাঃ ৪৮৯-ঙ","মুদ্রা-নোটসমূহ বা ব্যাংক-নোটসমূহের সদৃশ দলিলসমূহ প্রস্তুত বা ব্যবহারকরণ");
        dataholder_38.add(k17);


        MyAdapter_38 myAdapter_38 = new MyAdapter_38(dataholder_38);
        recyclerView_38.setAdapter(myAdapter_38);

        return view;
    }


    public static class MyAdapter_38 extends RecyclerView.Adapter<MyAdapter_38.MyViewHolder_38>{
        protected static class MyViewHolder_38 extends RecyclerView.ViewHolder{

            MaterialCardView materialCardView_38;
            MaterialTextView materialTextView_Header_38, materialTextView_Desc_38;


            public MyViewHolder_38(@NonNull View itemView) {
                super(itemView);

                materialCardView_38 = itemView.findViewById(R.id.recycler_CardView);
                materialTextView_Desc_38 = itemView.findViewById(R.id.recycler_TextViewDesc);
                materialTextView_Header_38 = itemView.findViewById(R.id.recycler_TextViewHeader);

            }
        }

        ArrayList<datamodel_One> dataholder_38;

        public MyAdapter_38(ArrayList<datamodel_One> dataholder_38) {
            this.dataholder_38 = dataholder_38;
        }

        @NonNull
        @Override
        public MyViewHolder_38 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_xml_design_one,parent,false);

            return new MyViewHolder_38(view);
        }

        @Override
        public void onBindViewHolder(@NonNull MyViewHolder_38 holder, int position) {

            holder.materialTextView_Header_38.setText(dataholder_38.get(position).getHeader());
            holder.materialTextView_Desc_38.setText(dataholder_38.get(position).getDesc());
            holder.materialCardView_38.setOnClickListener(v -> {

                if (position == 0) {

                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_One_Fragment_ThirtyEight()).addToBackStack(null).commit();


                } else if (position==1) {

                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Two_Fragment_ThirtyEight()).addToBackStack(null).commit();


                }else if (position==2) {

                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Three_Fragment_ThirtyEight()).addToBackStack(null).commit();

                }else if (position==3) {

                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Four_Fragment_ThirtyEight()).addToBackStack(null).commit();


                }else if (position==4) {

                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Five_Fragment_ThirtyEight()).addToBackStack(null).commit();


                }else if (position==
                5) {

                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Six_Fragment_ThirtyEight()).addToBackStack(null).commit();


                }else if (position==6) {

                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Seven_Fragment_ThirtyEight()).addToBackStack(null).commit();


                }else if (position==7) {

                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Eight_Fragment_ThirtyEight()).addToBackStack(null).commit();


                }else if (position==8) {

                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Nine_Fragment_ThirtyEight()).addToBackStack(null).commit();


                }else if (position==9) {

                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Ten_Fragment_ThirtyEight()).addToBackStack(null).commit();


                }else if (position==10) {

                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Eleven_Fragment_ThirtyEight()).addToBackStack(null).commit();


                }else if (position==11){

                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Twelve_Fragment_ThirtyEight()).addToBackStack(null).commit();


                }else if (position==12){

                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Thirteen_Fragment_ThirtyEight()).addToBackStack(null).commit();


                }else if (position==13){

                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Fourteen_Fragment_ThirtyEight()).addToBackStack(null).commit();


                }else if (position==14){

                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Fifteen_Fragment_ThirtyEight()).addToBackStack(null).commit();


                }else if (position==15){

                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Sixteen_Fragment_ThirtyEight()).addToBackStack(null).commit();


                }else if (position==16){

                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container, new Sub_Seventeen_Fragment_ThirtyEight()).addToBackStack(null).commit();


                }


            });

        }

        @Override
        public int getItemCount() {
            return 17;
        }

    }
}