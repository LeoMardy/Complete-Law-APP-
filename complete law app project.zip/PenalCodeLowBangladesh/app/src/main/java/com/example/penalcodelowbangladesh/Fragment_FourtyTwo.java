package com.example.penalcodelowbangladesh;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textview.MaterialTextView;

import java.util.ArrayList;


public class Fragment_FourtyTwo extends Fragment {

    RecyclerView recyclerView_42;
    ArrayList<datamodel_One> dataholder_42 = new ArrayList<>();


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment__fourty_two, container, false);
        recyclerView_42 = view.findViewById(R.id.recyclerView_42);
        recyclerView_42.setLayoutManager(new LinearLayoutManager(getContext()));

        datamodel_One k1 = new datamodel_One("ধারাঃ ৫০৩","অপরাধ ভীতিপ্রদর্শন");
        dataholder_42.add(k1);
        datamodel_One k2 = new datamodel_One("ধারাঃ ৫০৪","শাস্তিভঙ্গের জন্য উত্তেজনা সৃষ্টির উদ্দেশ্যে ইচ্ছাকৃত অপমান");
        dataholder_42.add(k2);
        datamodel_One k3 = new datamodel_One("ধারাঃ ৫০৫","জনগণের অনিষ্ট সাধনে সহায়ক বিবৃতিসমূহ");
        dataholder_42.add(k3);
        datamodel_One k4 = new datamodel_One("ধারাঃ ৫০৫-ক","কথার দ্বারা ক্ষতিকর কাজ, ইত্যাদি");
        dataholder_42.add(k4);
        datamodel_One k5 = new datamodel_One("ধারাঃ ৫০৬","অপরাধমূলক ভীতি প্রদর্শনের শাস্তি");
        dataholder_42.add(k5);
        datamodel_One k6 = new datamodel_One("ধারাঃ ৫০৭","বেনামী চিঠিপত্রের সাহায্যে অপরাধমূলক ভীতিপ্রদর্শন");
        dataholder_42.add(k6);
        datamodel_One k7 = new datamodel_One("ধারাঃ ৫০৮","কোন ব্যক্তিকে সে দৈব আক্রোশ কবলিত হইবে বলিয়া বিশ্বাস করিবার জন্য প্ররোচিত করিয়া কোন কার্য সম্পাদন করা");
        dataholder_42.add(k7);
        datamodel_One k8 = new datamodel_One("ধারাঃ ৫০৯","কোন নারীর শালীনতার অমর্যাদার অভিপ্রায়ে কোন মন্তব্য, অঙ্গভঙ্গি বা কোন কার্য");
        dataholder_42.add(k8);
        datamodel_One k9 = new datamodel_One("ধারাঃ ৫১০","প্রকাশ্যে মাতাল ব্যক্তির অশোভন আচরণ");
        dataholder_42.add(k9);


        MyAdapter_42 myAdapter_42 = new MyAdapter_42(dataholder_42);
        recyclerView_42.setAdapter(myAdapter_42);

        return view;
    }

    public static class MyAdapter_42 extends RecyclerView.Adapter<MyAdapter_42.MyViewHolder_42>{
        protected static class MyViewHolder_42 extends RecyclerView.ViewHolder{

            MaterialCardView materialCardView_42;
            MaterialTextView materialTextView_Header_42, materialTextView_Desc_42;
            public MyViewHolder_42(@NonNull View itemView) {
                super(itemView);
                materialTextView_Header_42 = itemView.findViewById(R.id.recycler_TextViewHeader);
                materialTextView_Desc_42 = itemView.findViewById(R.id.recycler_TextViewDesc);
                materialCardView_42 = itemView.findViewById(R.id.recycler_CardView);

            }
        }
        ArrayList<datamodel_One> dataholder_42;

        public MyAdapter_42(ArrayList<datamodel_One> dataholder_42) {
            this.dataholder_42 = dataholder_42;
        }

        @NonNull
        @Override
        public MyViewHolder_42 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_xml_design_one,parent,false);

            return new MyViewHolder_42(view);
        }

        @Override
        public void onBindViewHolder(@NonNull MyViewHolder_42 holder, int position) {

            holder.materialTextView_Desc_42.setText(dataholder_42.get(position).getDesc());
            holder.materialTextView_Header_42.setText(dataholder_42.get(position).getHeader());
            holder.materialCardView_42.setOnClickListener(v -> {

                if (position == 0) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_One_Fragment_FourtyTwo()).addToBackStack(null).commit();


                } else if (position==1) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Two_Fragment_FourtyTwo()).addToBackStack(null).commit();


                }else if (position==2) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Three_Fragment_FourtyTwo()).addToBackStack(null).commit();


                }else if (position==3) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Four_Fragment_FourtyTwo()).addToBackStack(null).commit();


                }else if (position==4) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Five_Fragment_FourtyTwo()).addToBackStack(null).commit();


                }else if (position==5) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Six_Fragment_FourtyTwo()).addToBackStack(null).commit();


                }else if (position==6) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Seven_Fragment_FourtyTwo()).addToBackStack(null).commit();


                }else if (position==7) {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Eight_Fragment_FourtyTwo()).addToBackStack(null).commit();


                }else  {

                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Nine_Fragment_FourtyTwo()).addToBackStack(null).commit();


                }


            });

        }

        @Override
        public int getItemCount() {
            return 9;
        }
    }
}