package com.example.penalcodelowbangladesh;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textview.MaterialTextView;

import java.util.ArrayList;

public class Fragment_ThirtyThree extends Fragment {

    RecyclerView recyclerView_33;
    ArrayList<datamodel_One> dataholder_33 = new ArrayList<>();


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment__thirty_three, container, false);
        recyclerView_33 = view.findViewById(R.id.recyclerView_33);
        recyclerView_33.setLayoutManager(new LinearLayoutManager(getContext()));

        datamodel_One k1 = new datamodel_One("ধারাঃ ৪২১","পাওনাদারগণের মধ্যে বন্টন নিবারণার্থ অসাধুভাবে বা প্রতারণামূলকভাবে বা সম্পত্তি অপসারণ বা গোপনকরণ");
        dataholder_33.add(k1);
        datamodel_One k2 = new datamodel_One("ধারাঃ ৪২২","পাওনাদারগণের ঋণ ফেরত পাইবার ব্যাপারে অসাধুভাবে বা প্রতারণামূলকভাবে বাধাদান করা");
        dataholder_33.add(k2);
        datamodel_One k3 = new datamodel_One("ধারাঃ ৪২৩","মূল্যের অসত্য বর্ণনা সম্বলিত হস্তান্তর দলিলের অসাধু বা প্রতারণামূলক সম্পাদন");
        dataholder_33.add(k3);
        datamodel_One k4 = new datamodel_One("ধারাঃ ৪২৪","অসাধুভাবে বা প্রতারণামূলকভাবে সম্পত্তি অপসারণ বা গোপনকরণ");
        dataholder_33.add(k4);



MyAdapter_33 myAdapter_33 = new MyAdapter_33(dataholder_33);
recyclerView_33.setAdapter(myAdapter_33);
        return view;
    }


    public static class MyAdapter_33 extends RecyclerView.Adapter<MyAdapter_33.MyViewHolder_33>{

        protected static class MyViewHolder_33 extends RecyclerView.ViewHolder{


            MaterialCardView materialCardView_33;
            MaterialTextView materialTextView_Header_33, materialTextView_Desc_33;

            public MyViewHolder_33(@NonNull View itemView) {
                super(itemView);

                materialCardView_33 = itemView.findViewById(R.id.recycler_CardView);
                materialTextView_Desc_33 = itemView.findViewById(R.id.recycler_TextViewDesc);
                materialTextView_Header_33 = itemView.findViewById(R.id.recycler_TextViewHeader);
            }
        }

        ArrayList<datamodel_One> dataholder_33;

        public MyAdapter_33(ArrayList<datamodel_One> dataholder_33) {
            this.dataholder_33 = dataholder_33;
        }

        @NonNull
        @Override
        public MyViewHolder_33 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_xml_design_one,parent,false);

            return new MyViewHolder_33(view);
        }

        @Override
        public void onBindViewHolder(@NonNull MyViewHolder_33 holder, int position) {

            holder.materialTextView_Header_33.setText(dataholder_33.get(position).getHeader());
            holder.materialTextView_Desc_33.setText(dataholder_33.get(position).getDesc());
            holder.materialCardView_33.setOnClickListener(v -> {

                if (position == 0) {

                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_One_Fragment_ThirtyThree()).addToBackStack(null).commit();


                } else if (position==1) {

                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Two_Fragment_ThirtyThree()).addToBackStack(null).commit();


                }else if (position==2) {

                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Three_Fragment_ThirtyThree()).addToBackStack(null).commit();


                }else  {

                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Four_Fragment_ThirtyThree()).addToBackStack(null).commit();


                }

            });

        }

        @Override
        public int getItemCount() {
            return 4;
        }

    }

}