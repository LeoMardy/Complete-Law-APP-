package com.example.penalcodelowbangladesh;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textview.MaterialTextView;

import java.util.ArrayList;


public class Fragment_ThirtyFive extends Fragment {

    RecyclerView recyclerView_35;
    ArrayList<datamodel_One> dataholder_35 = new ArrayList<>();


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment__thirty_five, container, false);
        recyclerView_35 = view.findViewById(R.id.recyclerView_35);
        recyclerView_35.setLayoutManager(new LinearLayoutManager(getContext()));


        datamodel_One k1 = new datamodel_One("ধারাঃ ৪৪১","অপরাধমূলক অনধিকার প্রবেশ");
        dataholder_35.add(k1);
        datamodel_One k2 = new datamodel_One("ধারাঃ ৪৪২","অনধিকার গৃহপ্রবেশ");
        dataholder_35.add(k2);
        datamodel_One k3 = new datamodel_One("ধারাঃ ৪৪৩","সঙ্গোপনে অনধিকার গৃহপ্রবেশ");
        dataholder_35.add(k3);
        datamodel_One k4 = new datamodel_One("ধারাঃ ৪৪৪","রাত্রিবেলায় সঙ্গোপনে অনধিকার গৃহপ্রবেশ");
        dataholder_35.add(k4);
        datamodel_One k5 = new datamodel_One("ধারাঃ ৪৪৫","অপথে গৃহপ্রবেশ");
        dataholder_35.add(k5);
        datamodel_One k6 = new datamodel_One("ধারাঃ ৪৪৬","রাত্রিকালে সিঁধ কাটিয়া বা দরজা-জানালা ভাঙ্গিয়া গৃহে প্রবেশ");
        dataholder_35.add(k6);
        datamodel_One k7 = new datamodel_One("ধারাঃ ৪৪৭","অপরাধজনক অনধিকার প্রবেশের শাস্তি");
        dataholder_35.add(k7);
        datamodel_One k8 = new datamodel_One("ধারাঃ ৪৪৮","গৃহে অনধিকার প্রবেশের শাস্তি");
        dataholder_35.add(k8);
        datamodel_One k9 = new datamodel_One("ধারাঃ ৪৪৯","মৃত্যুদন্ডে দন্ডনীয় অপরাধ করিবার উদ্দেশ্যে গৃহে অনধিকার প্রবেশ");
        dataholder_35.add(k9);
        datamodel_One k10 = new datamodel_One("ধারাঃ ৪৫০","যাবজ্জীবন কারাদন্ডে দন্ডনীয় অপরাধ উদ্দেশ্যে গৃহে অনধিকার প্রবেশ");
        dataholder_35.add(k10);

        datamodel_One k11 = new datamodel_One("ধারাঃ ৪৫১","কারাদন্ডে দন্ডনীয় অপরাধ করিবার উদ্দেশ্যে গৃহে অনধিকার প্রবেশ");
        dataholder_35.add(k11);
        datamodel_One k12 = new datamodel_One("ধারাঃ ৪৫২","আঘাত, আক্রমণ কিংবা অন্যায় নিয়ন্ত্রণ আরোপের প্রস্তুতি গ্রহণান্তে গৃহে অনধিকার প্রবেশ");
        dataholder_35.add(k12);
        datamodel_One k13 = new datamodel_One("ধারাঃ ৪৫৩","সঙ্গোপনে গৃহে অনধিকার প্রবেশ বা সিঁধ কাটিয়া গৃহে প্রবেশের  শাস্তি");
        dataholder_35.add(k13);
        datamodel_One k14 = new datamodel_One("ধারাঃ ৪৫৪","কারাদন্ডে দন্ডনীয় অপরাধ করিবার উদ্দেশ্যে সঙ্গোপনে গৃহে অনধিকার প্রবেশ অথবা সিঁধ কাটিয়া গৃহে প্রবেশ");
        dataholder_35.add(k14);
        datamodel_One k15 = new datamodel_One("ধারাঃ ৪৫৫","আঘাত, আক্রমণ কিংবা অন্যায় নিয়ন্ত্রণ আরোপ বা অন্যায়ভাবে আটকের প্রস্তুতি গ্রহণান্তে সঙ্গোপনে গৃহে অনধিকার প্রবেশ বা সিঁধ কাটিয়া গৃহে প্রবেশ");
        dataholder_35.add(k15);
        datamodel_One k16 = new datamodel_One("ধারাঃ ৪৫৬","রাত্রে সঙ্গোপনে গৃহে অনধিকার প্রবেশ বা সিঁধ কাটিয়া গৃহে প্রবেশ করিবার শাস্তি");
        dataholder_35.add(k16);
        datamodel_One k17 = new datamodel_One("ধারাঃ ৪৫৭","কারাদন্ডে দন্ডনীয় অপরাধ করিবার উদ্দেশ্যে রাত্রে সঙ্গোপনে গৃহে অনধিকার প্রবেশ বা সিঁধ কাটিয়া গৃহে প্রবেশ");
        dataholder_35.add(k17);
        datamodel_One k18 = new datamodel_One("ধারাঃ ৪৫৮","আঘাত, আক্রমণ কিংবা অন্যায়ভাবে নিয়ন্ত্রণ আরোপের প্রস্তুতি গ্রহণান্তে রাত্রে সঙ্গোপনে গৃহে অনধিকার প্রবেশ বা সিঁধ কাটিয়া গৃহে প্রবেশ");
        dataholder_35.add(k18);
        datamodel_One k19 = new datamodel_One("ধারাঃ ৪৫৯","সঙ্গোপনে অনধিকার প্রবেশকালে বা সিঁধ কাটিয়া গৃহে প্রবেশকালে মারাত্মকভাবে আহত করা");
        dataholder_35.add(k19);
        datamodel_One k20 = new datamodel_One("ধারাঃ ৪৬০","রাত্রে সঙ্গোপনে গৃহে অনধিকার প্রবেশ বা সিঁধ কাটিয়া গৃহে প্রবেশের সহিত সম্মিলিতভাবে সংশ্লিষ্ট ব্যক্তিদের মধ্যে কোন একজন কাহারও মৃত্যু বা মারাত্মক আঘাত ঘটাইলে সকলেই দন্ডনীয় হইবে");
        dataholder_35.add(k20);

        datamodel_One k21 = new datamodel_One("ধারাঃ ৪৬১","অসাধুভাবে সম্পত্তি সম্বলিত আধার ভাঙ্গিয়া উন্মুক্ত করা");
        dataholder_35.add(k21);
        datamodel_One k22 = new datamodel_One("ধারাঃ ৪৬২","হেফাজতের ভারপ্রাপ্ত ব্যক্তি কর্তৃক উক্ত অপরাধ সংঘটিত হইল তাহার শাস্তি");
        dataholder_35.add(k22);


MyAdpater_35 m = new MyAdpater_35(dataholder_35);
recyclerView_35.setAdapter(m);

        return view;
    }

    public static class MyAdpater_35 extends RecyclerView.Adapter<MyAdpater_35.MyViewHolder_35>{
        protected static class MyViewHolder_35 extends RecyclerView.ViewHolder{


            MaterialCardView materialCardView_35;
            MaterialTextView materialTextView_Header_35, materialTextView_Desc_35;

            public MyViewHolder_35(@NonNull View itemView) {
                super(itemView);

                materialCardView_35 = itemView.findViewById(R.id.recycler_CardView);
                materialTextView_Header_35 = itemView.findViewById(R.id.recycler_TextViewHeader);
                materialTextView_Desc_35 = itemView.findViewById(R.id.recycler_TextViewDesc);
            }
        }

        ArrayList<datamodel_One> dataholder_35 ;


        public MyAdpater_35(ArrayList<datamodel_One> dataholder_35) {
            this.dataholder_35 = dataholder_35;
        }

        @NonNull
        @Override
        public MyViewHolder_35 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

            View view =LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_xml_design_one,parent,false);

            return new MyViewHolder_35(view);
        }

        @Override
        public void onBindViewHolder(@NonNull MyViewHolder_35 holder, int position) {

            holder.materialTextView_Desc_35.setText(dataholder_35.get(position).getDesc());
            holder.materialTextView_Header_35.setText(dataholder_35.get(position).getHeader());
            holder.materialCardView_35.setOnClickListener(v -> {

                if (position == 0) {

                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_One_Fragment_ThirtyFive()).addToBackStack(null).commit();


                } else if (position==1) {
                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Two_Fragment_ThirtyFive()).addToBackStack(null).commit();


                }else if (position==2) {
                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Three_Fragment_ThirtyFive()).addToBackStack(null).commit();


                }else if (position==3) {
                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Four_Fragment_ThirtyFive()).addToBackStack(null).commit();


                }else if (position==4) {
                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Five_Fragment_ThirtyFive()).addToBackStack(null).commit();


                }else if (position==5) {
                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Six_Fragment_ThirtyFive()).addToBackStack(null).commit();


                }else if (position==6) {
                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Seven_Fragment_ThirtyFive()).addToBackStack(null).commit();


                }else if (position==7) {
                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Eight_Fragment_ThirtyFive()).addToBackStack(null).commit();


                }else if (position==8) {
                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Nine_Fragment_ThirtyFive()).addToBackStack(null).commit();


                }else if (position==9) {
                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Ten_Fragment_ThirtyFive()).addToBackStack(null).commit();


                }else if (position==10) {
                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Eleven_Fragment_ThirtyFive()).addToBackStack(null).commit();


                }else if (position==11) {
                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Twelve_Fragment_ThirtyFive()).addToBackStack(null).commit();


                }else if (position==12) {
                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Thirteen_Fragment_ThirtyFive()).addToBackStack(null).commit();


                }else if (position==13) {
                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Fourteen_Fragment_ThirtyFive()).addToBackStack(null).commit();


                }else if (position==14) {
                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Fifteen_Fragment_ThirtyFive()).addToBackStack(null).commit();


                }else if (position==15) {
                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Sixteen_Fragment_ThirtyFive()).addToBackStack(null).commit();


                }else if (position==16) {
                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Seventeen_Fragment_ThirtyFive()).addToBackStack(null).commit();


                }else if (position==17) {
                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Eighteen_Fragment_ThirtyFive()).addToBackStack(null).commit();


                }else if (position==18) {
                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Nineteen_Fragment_ThirtyFive()).addToBackStack(null).commit();


                }else if (position==19) {
                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_Twenty_Fragment_ThirtyFive()).addToBackStack(null).commit();


                }else if (position==20) {
                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_TwentyOne_Fragment_ThirtyFive()).addToBackStack(null).commit();


                }else  {
                    AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
                    appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.Main_Container,new Sub_TwentyTwo_Fragment_ThirtyFive()).addToBackStack(null).commit();

                }

            });
        }

        @Override
        public int getItemCount() {
            return 22;
        }
    }
}